__author__ = 'g8y3e'

import sys
sys.path.append("../../../")

from qualipy.common.libs.driver_builder_wrapper import DriverFunction
from qualipy.common.libs.driver_builder_wrapper import base_resource_driver

from qualipy.common.cisco.cisco_handler_factory import *

import json

class c220_resource_driver(base_resource_driver):
    @DriverFunction(extraMatrixRows={'resource': ['CIMC User', 'CIMC Password', 'CIMC IP']})
    def Connect(self, json_str):
        json_dict = json.loads(json_str)

        host = json_dict['resource']['CIMC IP']
        username = json_dict['resource']['CIMC User']
        password = json_dict['resource']['CIMC Password']

        self._cimc_handler = CiscoHandlerFactory.createHandler('cimc', host,
                                                               username, password, 'ssh', 22, 60)
        return self._cimc_handler.connect() 

    @DriverFunction                 #(extraMatrixRows={'resource': ['Trap Destination']})
    def ConfigureSNMP(self, json_str, acces_community, trap_version, trap_destination):
        trap_version_list = trap_version.split(',')
        trap_destination_list = trap_destination.split(',')

        return self._cimc_handler.configureSNMP(acces_community, trap_version_list,
                                            trap_destination_list)

    @DriverFunction
    def ConfigureSyslog(self, json_str, sys_log_server, sys_log_enabled):
        sys_log_server_list = sys_log_server.split(',')
        sys_log_enabled_list = sys_log_enabled.split(',')

        return self._cimc_handler.configureSyslog(sys_log_server_list, sys_log_enabled_list)
    
    @DriverFunction
    def CreateVirtualDrive(self, json_str, drive_name, drive_raid_type, storage_slot, drive_using_percent):
        drive_using_percent = float(drive_using_percent)

        return self._cimc_handler.createVirtualDrive(drive_name, drive_raid_type, storage_slot, drive_using_percent)

    @DriverFunction
    def DeleteVirtualDrives(self, json_str, storage_slot):
        return self._cimc_handler.deleteVirtualDrives(storage_slot)

    @DriverFunction
    def EnableFlashFlexDrive(self, json_str, virtual_drives_enabled):
        return self._cimc_handler.enableFlashFlexDrive(virtual_drives_enabled)

    @DriverFunction
    def EnableHTTP(self, json_str, scope_setting):
        return self._cimc_handler.enableHTTP(scope_setting)

    @DriverFunction
    def EnableSSH(self, json_str, scope_setting):
        return self._cimc_handler.enableSSH(scope_setting)

    @DriverFunction
    def EnableXmlAPI(self, json_str, scope_setting):
        return self._cimc_handler.enableXmlAPI(scope_setting)

    @DriverFunction
    def RebootCIMC(self, json_str):        
        return self._cimc_handler.rebootCIMC()

    @DriverFunction
    def RebootChassis(self, json_str):
        json_dict = json.loads(json_str)

        resource_name = json_dict['resource']['ResourceName']
        
        return self._cimc_handler.rebootChassis(resource_name)

    @DriverFunction
    def SetBootOrder(self, json_str, boot_order):
        return self._cimc_handler.setBootOrder(boot_order)
   
    @DriverFunction
    def SetDNS(self, json_str, dns_server, alternate_server):
        return self._cimc_handler.setDNS(dns_server, alternate_server)

    @DriverFunction
    def SetEventFilter(self, json_str, enable_platform_events, filter_setting, 
                    single, event_filter_start, event_filter_end):

        if single != '':
            single = int(single)
        else:
            single = -1

        if event_filter_start != '':
            event_filter_start = int(event_filter_start)
        else:
            event_filter_start = 1

        if event_filter_end != '':
            event_filter_end = int(event_filter_end)
        else:
            event_filter_end = 1

        return self._cimc_handler.setEventFilter(enable_platform_events, 
                    filter_setting, single, event_filter_start, event_filter_end)

    @DriverFunction
    def SetHostname(self, json_str, hostname):
        return self._cimc_handler.setHostname(hostname)

    @DriverFunction
    def SetKVM(self, json_str, enable_kvm):
        if enable_kvm == '':
            enable_kvm = 'yes'

        return self._cimc_handler.setKVM(enable_kvm)

    @DriverFunction
    def SetNTP(self, json_str, enable, args_str):

        args = args_str.split(',')
        return self._cimc_handler.setNTP(enable, args)

    @DriverFunction
    def SetProcConfig(self, json_str, proccess_config):

        proccess_list = proccess_config.split('\n')
        return self._cimc_handler.setProcConfig(proccess_list)

    @DriverFunction
    def UpdateFirmware(self, json_str, tftp_server, firmware):
        return self._cimc_handler.updateFirmware(tftp_server, firmware)

    @DriverFunction
    def ShowKVM(self, json_str):
        return self._cimc_handler.showKVM()

    @DriverFunction
    def ShowPhysicalDrives(self, json_str, storage_slot):
        return self._cimc_handler.showPhysicalDrives(storage_slot)

    @DriverFunction
    def ShowProcessorDetail(self, json_str):
        return self._cimc_handler.showProcessorDetail()

    @DriverFunction
    def ShowSLOTs(self, json_str):
        return self._cimc_handler.showSLOTs()

    @DriverFunction
    def ShowSNMPDetails(self, json_str):
        return self._cimc_handler.showSNMPDetails()

    @DriverFunction
    def GetMacs(self, json_str):
       return self._cimc_handler.getMacs()