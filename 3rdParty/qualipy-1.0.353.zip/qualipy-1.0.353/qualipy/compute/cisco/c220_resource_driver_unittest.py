__author__ = 'g8y3e'

from c220_resource_driver import *

from datetime import datetime

import unittest

class logTime:
    def __init__(self):
        self._start_time = 0

    def start(self):
        self._start_time = self._getCurrentTime()

    def printElapsedTime(self, method_name):
        current_time = self._getCurrentTime() - self._start_time
        print method_name + ' method elapsed time: ' + str(current_time)

    def _getCurrentTime(self):
        return datetime.now()


def setUpModule():
    print 'Cisco C220 unittest start!'

def tearDownModule():
    print '\nCisco C220 unittest end!'

class TestC220ResourceDriver(unittest.TestCase):
    @staticmethod
    def setUpClass():
        print 'Cisco C220 Test start'

    @staticmethod
    def tearDownClass():
        print 'Cisco C220 Test end'

    def setUp(self):
        self._log_time = logTime()

        self._c220_driver = c220_resource_driver("test", "")

        self._json_str = """
        {
            "resource" : {
                "CIMC IP": "10.11.34.75",
                "CIMC User": "admin",
                "CIMC Password": "@Vantage123",
                "ResourceName": "G8y3e"
            }
        }"""

        self._connect()

    def tearDown(self):
        pass

    # 1 - 0:00:05.973
    # 2 - 0:00:06.192
    # 3 - 0:00:10.271
    # 4 - 0:00:06.791
    # 5 - 0:00:06.017
    # 6 - 0:00:06.769
    # 7 - 0:00:16.755
    # 8 - 0:00:06.502
    # 9 - 0:00:05.997
    # 10 - 0:00:06.103
    # 11 - 0:00:06.697
    # 12 - 0:00:06.065
    # 13 - 0:00:06.691
    # 14 - 0:00:09.396
    # 15 - 0:00:05.924
    # 16 - 0:00:05.791
    # 17 - 0:00:05.994
    # 18 - 0:00:12.007
    # 19 - 0:00:05.852
    # 20 - 0:00:09.750
    # 21 - 0:00:12.250
    # 22 - 0:00:06.248
    # 23 - 0:00:05.787
    # 24 - 0:00:26.853
    # 25 - 0:00:05.597
    # 26 - 0:00:06.085
    # 27 - 0:00:06.230
    # 28 - 0:00:06.645
    # 29 - 0:00:13.399
    # 30 - 0:00:05.625
    # 31 - 0:00:11.356
    # 32 - 0:00:06.857
    # 33 - 0:00:05.883
    # 34 - 0:00:05.888
    # 35 - 0:00:05.900
    def _connect(self):
        self._log_time.start()
        self._c220_driver.Connect(self._json_str)
        self._log_time.printElapsedTime('Connect')

    # 1 - 0:03:20.928
    # 2 - 0:03:07.644
    # 3 - 0:03:21.650
    @unittest.skip('')
    def testConfigureSNMP(self):
        self._log_time.start()
        self._c220_driver.ConfigureSNMP(self._json_str, 'test2www!', '1,2', '10.0.0.42,10.0.0.43')
        self._log_time.printElapsedTime('ConfigureSNMP')

    # 1 - 0:00:45.718
    @unittest.skip('')
    def testConfigureSyslog(self):
        self._log_time.start()
        self._c220_driver.ConfigureSyslog(self._json_str, 'test42', 'yes')
        self._log_time.printElapsedTime('ConfigureSyslog')

    # 1 - 0:00:34.312
    # 2 - 0:00:27.312
    @unittest.skip('')
    def testCreateVirtualDrive(self):
        self._log_time.start()
        self._c220_driver.CreateVirtualDrive(self._json_str, 'test1', '0', 'SLOT-2', '0.6')
        self._log_time.printElapsedTime('CreateVirtualDrive')

    # 1 - 0:00:39.246
    # 2 - 0:00:19.333000
    @unittest.skip('')
    def testDeleteVirtualDrives(self):
        self._log_time.start()
        self._c220_driver.DeleteVirtualDrives(self._json_str, 'SLOT-2')
        self._log_time.printElapsedTime('DeleteVirtualDrives')

    # 1 - 0:00:13.624
    @unittest.skip('')
    def testEnableFlashFlexDrive(self):
        self._log_time.start()
        self._c220_driver.EnableFlashFlexDrive(self._json_str, 'one,two')
        self._log_time.printElapsedTime('EnableFlashFlexDrive')

    # 1 - 0:00:12.156
    @unittest.skip('')
    def testEnableHTTP(self):
        self._log_time.start()
        self._c220_driver.EnableHTTP(self._json_str, 'YES')
        self._log_time.printElapsedTime('EnableHTTP')

    # 1 - 0:00:13.284
    @unittest.skip('')
    def testEnableSSH(self):
        self._log_time.start()
        self._c220_driver.EnableSSH(self._json_str, 'YES')
        self._log_time.printElapsedTime('EnableSSH')

    # 1 - 0:00:12.209
    @unittest.skip('')
    def testEnableXmlAPI(self):
        self._log_time.start()
        self._c220_driver.EnableXmlAPI(self._json_str, 'YES')
        self._log_time.printElapsedTime('EnableXmlAPI')

    @unittest.skip('')
    def testRebootCIMC(self):
        self._log_time.start()
        self._c220_driver.RebootCIMC(self._json_str)
        self._log_time.printElapsedTime('RebootCIMC')

    @unittest.skip('')
    def testRebootChassis(self):
        self._log_time.start()
        self._c220_driver.RebootChassis(self._json_str)
        self._log_time.printElapsedTime('RebootChassis')

    @unittest.skip('')
    def testSetBootOrder(self):
        self._log_time.start()
        self._c220_driver.SetBootOrder(self._json_str, 'one,two')
        self._log_time.printElapsedTime('SetBootOrder')

    # 1 - 0:00:47.768
    # 2 - 0:00:47.497
    @unittest.skip('')
    def testSetDNS(self):
        self._log_time.start()
        self._c220_driver.SetDNS(self._json_str, '10.11.34.217', '10.11.34.217')
        self._log_time.printElapsedTime('SetDNS')

    # 1 - 0:00:24.317
    @unittest.skip('')
    def testSetEventFilter(self):
        self._log_time.start()
        self._c220_driver.SetEventFilter(self._json_str, 'yes', 'alert Heloo', '', '1', '2')
        self._log_time.printElapsedTime('SetEventFilter')

    # 1 - 0:00:19.051
    # 2 - 0:00:24.014
    @unittest.skip('')
    def testSetHostname(self):
        self._log_time.start()
        self._c220_driver.SetHostname(self._json_str, 'g8y3e-test-2')
        self._log_time.printElapsedTime('SetHostname')

    # 1 - 0:00:12.148
    @unittest.skip('')
    def testSetKVM(self):
        self._log_time.start()
        self._c220_driver.SetKVM(self._json_str, 'yes')
        self._log_time.printElapsedTime('SetKVM')

    # 1 - 0:00:23.306000
    @unittest.skip('')
    def testSetNTP(self):
        self._log_time.start()
        self._c220_driver.SetNTP(self._json_str, 'yes', '')
        self._log_time.printElapsedTime('SetNTP')

    # 1 -
    @unittest.skip('')
    def testSetProcConfig(self):
        self._log_time.start()
        self._c220_driver.SetProcConfig(self._json_str, 'test yes')
        self._log_time.printElapsedTime('SetProcConfig')

    # 1 -
    @unittest.skip('')
    def testUpdateFirmware(self):
        self._log_time.start()
        self._c220_driver.UpdateFirmware(self._json_str, 'test.com', 'test')
        self._log_time.printElapsedTime('UpdateFirmware')

    # 1 - 0:00:01.172
    @unittest.skip('')
    def testShowKVM(self):
        self._log_time.start()
        self._c220_driver.ShowKVM(self._json_str)
        self._log_time.printElapsedTime('ShowKVM')

    # 1 - 0:00:03.179000
    @unittest.skip('')
    def testShowPhysicalDrives(self):
        self._log_time.start()
        self._c220_driver.ShowPhysicalDrives(self._json_str, 'SLOT-2')
        self._log_time.printElapsedTime('ShowPhysicalDrives')

    # 1 - 0:00:19.065
    @unittest.skip('')
    def testShowProcessorDetail(self):
        self._log_time.start()
        self._c220_driver.ShowProcessorDetail(self._json_str)
        self._log_time.printElapsedTime('ShowProcessorDetail')

    # 1 - 0:00:02.746
    @unittest.skip('')
    def testShowSLOTs(self):
        self._log_time.start()
        self._c220_driver.ShowSLOTs(self._json_str)
        self._log_time.printElapsedTime('ShowSLOTs')

    # 1 - 0:00:02.156
    @unittest.skip('')
    def testShowSNMPDetails(self):
        self._log_time.start()
        self._c220_driver.ShowSNMPDetails(self._json_str)
        self._log_time.printElapsedTime('ShowSNMPDetails')

    # 1 - 0:00:09.320
    @unittest.skip('')
    def testGetMacs(self):
        self._log_time.start()
        self._c220_driver.GetMacs(self._json_str)
        self._log_time.printElapsedTime('GetMacs')

def suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestC220ResourceDriver))

    return suite

if (__name__ == '__main__'):
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass