from ssh_manager import SSHManager

class C3048:
    def __init__(self, username='ucspe', password='ucspe', host='127.0.0.1', port=25):
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.ssh = SSHManager(self.username, self.password, self.host, self.port)
        self.ssh.connect()
        self.resource = {
            "ResourceAddress" : "",
            "ResourceFullAddress" : "",
            "ResourceName" : "",
            "ResourceFullName" : "",
            "ResourceFamily" : "",
            "ResourceModel" : "",
            "ResourceDescription" : "",
            "ReservationId" : "",
            "User" : "",
            "Password" : "",
            "Trap Destination" : "",
            "Trap Version" : "",
            "Trap Community" : "",
            "Access Community" : "",
            "Syslog Server" : ""
        }
    # Auxillary commands
    #def buildCommand(self):
    #    pass
    #def checkExpectedValue(self):
    #    pass
    #def cliCommands(self):
    #    pass
    #def cliCommandsConsole(self):
    #    pass
    #def cliCommandsParse(self):
    #    pass
    # def cliSingleCommand(self): #?
    #    pass                    #?
    #def consoleLoginBugWA(self):
    #    pass
    #def createOutput(self):
    #    pass
    #def createOutputString(self):
    #    pass
    #def exitConfigurationModeError(self):
    #    pass
    #def parseCLI(self):
    #    pass
    def saveToFile(self, file_name, content):
        f = open(file_name, 'w')
        f.write(content)
        f.close()

    # Manage device commands
    def enterConfigurationMode(self, configurationMethod = "t"):
        self.ssh.sendCommand('conf ' + configurationMethod)

    def configureLine(self, deviceVersion): # Move to child classes Cisco IOS and NxOS
        self.ssh.sendCommand('conf t')
        self.ssh.sendCommand('line')
        self.ssh.sendCommand('exec-timeout')
        if(deviceVersion == 'ios'):
            self.ssh.sendCommand('session-limit')
        else:
            self.ssh.sendCommand('privilege')
            self.ssh.sendCommand('level')
            self.ssh.sendCommand('transport')
            self.ssh.sendCommand('input')
            self.ssh.sendCommand('login')
            self.ssh.sendCommand('password')
    def manageDomain(self): #?
        self.ssh.sendCommand('conf t')
        self.ssh.sendCommand('ip')
        self.ssh.sendCommand('domain-name')
        self.ssh.sendCommand('domain-lookup')
    def manageLogging(self, deviceVersion): #?
        self.ssh.sendCommand('conf t')
        self.ssh.sendCommand('logging')
        if(deviceVersion == 'ios'):
            self.ssh.sendCommand('logging')
            self.ssh.sendCommand('$word')
            self.ssh.sendCommand('buffered')
            self.ssh.sendCommand('trap')
            self.ssh.sendCommand('facility')
            self.ssh.sendCommand('file')
        else:
            self.ssh.sendCommand('server')
            self.ssh.sendCommand('logfile')
            self.ssh.sendCommand('$word')
            self.ssh.sendCommand('size')
            self.ssh.sendCommand('level')
            self.ssh.sendCommand('level')
            self.ssh.sendCommand('timestamp')
    def manageSNMPServer(self): #?
        self.ssh.sendCommand('conf t')
        self.ssh.sendCommand('snmp-server')
        self.ssh.sendCommand('host')
        self.ssh.sendCommand('traps')
        self.ssh.sendCommand('version')
        self.ssh.sendCommand('$WORD')
        self.ssh.sendCommand('udp-port')
        self.ssh.sendCommand('enable')
        self.ssh.sendCommand('traps')
        self.ssh.sendCommand('community')
    def manageSSH(self, deviceVersion): # Move to child classes Cisco IOS and NxOS
        pass
        if (deviceVersion == "ios"):
            self.ssh.sendCommand("conf t	$yes")
            self.ssh.sendCommand("ip	$yes")
            self.ssh.sendCommand("ssh	$yes")
            self.ssh.sendCommand("time-out	")
            self.ssh.sendCommand("authentication-retries	")
            self.ssh.sendCommand("version	")
            self.ssh.sendCommand("crypto	$yes")
            self.ssh.sendCommand("key	$yes")
            self.ssh.sendCommand("generate	$yes")
            self.ssh.sendCommand("rsa	$yes")
            self.ssh.sendCommand("general-key	$yes")
            self.ssh.sendCommand("mod	2048")
        else:
            self.ssh.sendCommand("conf t	$yes")
            self.ssh.sendCommand("no	$yes")
            self.ssh.sendCommand("feature	$yes")
            self.ssh.sendCommand("ssh	$yes")
            self.ssh.sendCommand("ssh")
            self.ssh.sendCommand("login-attempts")
            self.ssh.sendCommand("key")
            self.ssh.sendCommand("force")
            self.ssh.sendCommand("feature")
            self.ssh.sendCommand("ssh")
        
    def setBanner(self): #?
        self.ssh.sendCommand('conf t')
        self.ssh.sendCommand('banner')
        self.ssh.sendCommand('login')
        self.ssh.sendCommand('motd')
    def setClock(self): #?
        self.ssh.sendCommand('clock')
        self.ssh.sendCommand('set')
        self.ssh.sendCommand('conf t')
        self.ssh.sendCommand('clock')
        self.ssh.sendCommand('summer-time')
        self.ssh.sendCommand('date')
        self.ssh.sendCommand('recurring')
        self.ssh.sendCommand('timezone')
        self.ssh.sendCommand('ntp')
        self.ssh.sendCommand('server')

    # Manage port commands
    #def getInterfacesTable(self):
    #    #TODO: implement command
    #    pass
    def condigureInterface(self, interface_name, blade_number, interface_number):
        self.enterConfigurationMode()
        self.ssh.sendCommand('interface ' + interface_name + " " + blade_number + "/" + interface_number)

    def manageInterfaceState(self, interface_name, blade_number, interface_number, administrative_status):
        self.manageInterface(interface_name,blade_number,interface_number)
        if (administrative_status == 'no shutdown'):
            self.ssh.sendCommand('no shutdown')
        else:
            self.ssh.sendCommand('shutdown')
    
    def manageInterfaceVlans(self, interface_name, blade_number, interface_number, vlan_id, assign = True, switchport_mode = "trunk"):
        self.manageInterface(interface_name, blade_number, interface_number)
        if (switchport_mode == "trunk"):
            if (assign):
                self.ssh.sendCommand(


    def manageInterfaceDescription(self, action, description, interface_name, blade_number, interface_number):
        self.manageInterface(interface_name, blade_number, interface_number)
        if(action == 'remove'):
            self.ssh.sendCommand('no description')
        else:
            self.ssh.sendCommand('description '+ description)
        #save configureation should be done in child classes due to the syntax difference

    def manageProtocolSTP(self):
        #TODO: implement command
        pass
    def AddVlan(self):
        #TODO: implement command
        pass
    def RemoveVlan(self):
        #TODO: implement command
        pass
    # Manage protocol commands
    def manageSTP(self):
        self.ssh.sendCommand('conf t')
        self.ssh.sendCommand('spanning-tree')
        self.ssh.sendCommand('extend')
        self.ssh.sendCommand('system-id')
        self.ssh.sendCommand('mode')
        self.ssh.sendCommand('portfast')
        self.ssh.sendCommand('bpdufilter')
        self.ssh.sendCommand('bpduguard')
        self.ssh.sendCommand('vlan')
        self.ssh.sendCommand('priority')
    #def manageSwitchVlans(self):
    #    pass

    # Setup commands
    def _assignFileSysProtocol(self, filesystem_protocol, alternative_server): # Should be a part of FileSave method described above
        if('bs' in filesystem_protocol):
            filesystem_protocol = "bs:"
        elif('bootflash' in filesystem_protocol):
            filesystem_protocol = "bootflash://"
        elif('core' in filesystem_protocol):
            filesystem_protocol = "core://"
        elif('cns' in filesystem_protocol):
            filesystem_protocol = "cns://"
        elif('debug' in filesystem_protocol):
            filesystem_protocol = "debug://"
        elif('flash' in filesystem_protocol):
            filesystem_protocol = "flash:"
        elif('ftp' in filesystem_protocol):
            filesystem_protocol = "ftp://"
            alternative_server += '/'
        elif('log' in filesystem_protocol):
            filesystem_protocol = "log://"
        elif('modflash' in filesystem_protocol):
            filesystem_protocol = "modflash://"
            alternative_server += '/'
        elif('nvram' in filesystem_protocol):
            filesystem_protocol = "nvram:/"
        elif('rcp' in filesystem_protocol):
            filesystem_protocol = "rcp://"
            alternative_server += '/'
        elif('scp' in filesystem_protocol):
            filesystem_protocol = "scp://"
            alternative_server += '/'
        elif('sftp' in filesystem_protocol):
            filesystem_protocol = "sftp://"
            alternative_server += '/'
        elif('system' in filesystem_protocol):
            filesystem_protocol = "system:/"
        elif('tftp' in filesystem_protocol):
            filesystem_protocol = "tftp://"
            alternative_server += '/'
        elif('usb1' in filesystem_protocol):
            filesystem_protocol = "usb1:"
        elif('xmodem' in filesystem_protocol):
            filesystem_protocol = "tftp://"
            alternative_server += '/'
        elif('ymodem' in filesystem_protocol):
            filesystem_protocol = "flash:"

        return filesystem_protocol, alternative_server
    def consoleScriptPattern(self): #? To be verified in future
        pass
    def backUpRestoreConfiguration(self, filesystem_protocol, alternative_server, backup_restore_flag, copy_full_path):
        filesystem_protocol, alternative_server = _assignFileSysProtocol(filesystem_protocol, alternative_server)
        if (backup_restore_flag == 'Backup'):
            if not copy_full_path:
                copy_full_path = 'Cisco_' + datetime.date.today().strftime("yy.MM.dd_HH.mm.ss") + '.cfg'
            file_path = filesystem_protocol + alternative_server + copy_full_path
            file_path = file_path.strip()
            self.ssh.sendCommand('copy running-config ' + file_path)
        else:
            file_path = filesystem_protocol + alternative_server + copy_full_path
            self.ssh.sendCommand('copy ' + file_path + ' running-config ')
        pass
    def init(self):
        # TODO: implement command
        pass
    def installLicense(self):
        # TODO: implement command
        pass
    #def login(self):
    #    pass
    #def login_PatternSet(self):
    #    pass
    #def loginThroughConsoleServer(self):
    #    pass
    def loginThroughConsoleServerCiscoPatternSet(self):
        # TODO: implement command
        pass
    def logout(self):
        # TODO: implement command
        pass
    def manageUser(self, deviceVersion): # Move to child classes Cisco IOS and NxOS
        if(deviceVersion == "ios"):
            self.ssh.sendCommand("conf t")
            self.ssh.sendCommand("username")
            self.ssh.sendCommand("privilege")
            self.ssh.sendCommand("secret")
            self.ssh.sendCommand("password")
        else:
            self.ssh.sendCommand("conf t")
            self.ssh.sendCommand("username")
            self.ssh.sendCommand("password")
            self.ssh.sendCommand("role")
        pass
    def saveRunningConfigurationToStartup(self):
        # TODO: implement command
        pass
    def setHostName(self, hostname):
        self.ssh.sendCommand("configure terminal")
        self.ssh.sendCommand("hostname " + hostname)
        
    # Statistics commands
    #def matToString(self):
    #    pass
    #def stringToMat(self):
    #    pass
    def showConfiguration(self):
        pass
    def showHosts(self):
        pass
    def showInterfaces(self):
        pass
    def showInterfacesCounters(self):
        pass
    def showInterfacesSummary(self):
        pass
    def showMatrix(self):
        pass
    def showText(self):
        pass
    def showVersion(self):
        pass
   
    # Utilities commands
    #def customCommand(self):
    #    pass
    #def externalCustomCommand(self):
    #    pass
    #def genericSet(self):
    #    pass
    #def matrixCommand(self):
    #    pass
    #def parseCliCaller(self):
    #    pass

