__author__ = 'g8y3e'

from qualipy.networking.cisco.interfaces.interface_base import *

class Level2(InterfaceBase):
    __metaclass__ = ABCMeta
