__author__ = 'g8y3e'

from abc import ABCMeta
from abc import abstractmethod

from qualipy.common.libs.parameters_service.parameters_service import *
from qualipy.common.libs.parameters_service.command_template import *


class InterfaceBase:
    __metaclass__ = ABCMeta

    COMMANDS_TEMPLATE = {
        'configure_interface': CommandTemplate('interface {0} {1}', [r'\w+', r'[0-9/]+'],
                                               ['Interface name incorrect!', 'Interface id incorrect!'])
    }

    @abstractmethod
    def getCommandsList(self, **kwargs):
        prepared_commands = []

        if not 'configure_interface' in kwargs:
            raise Exception('Need to set configure_interface parameter!')

        command_template = InterfaceBase.COMMANDS_TEMPLATE['configure_interface']
        prepared_commands.append(ParametersService.getValidateList(command_template, kwargs['configure_interface']))

        return prepared_commands
