import sys
import json
sys.path.append("../../../../")

from qualipy.common.cisco.cisco_handler_factory import CiscoHandlerFactory
from qualipy.common.libs.driver_builder_wrapper import DriverFunction
from qualipy.common.libs.driver_builder_wrapper import base_resource_driver
import cell_router

#comment

class cell_router_resource_driver(base_resource_driver):

    @DriverFunction(extraMatrixRows={"resource": ["User","Password"]})
    def Connect(self, matrixJson, timeout = 60):

        o=json.loads(matrixJson)
        ip=o['resource']['ResourceAddress']
        user=o['resource']['User']
        password=o['resource']['Password']
        self._cell_router =  CiscoHandlerFactory.createHandler('CELLROUTER', ip, user, password)
        if not self._cell_router is None:
            return 'Handler successfully created'
        else:
            return 'Failed to create \'CELLROUTER\' handler.'

    @DriverFunction(extraMatrixRows={"resource": ["User","Password"]})
    def ConnectToFile(self, matrixJson, file_name ='', timeout = 60):

        o=json.loads(matrixJson)
        ip=o['resource']['ResourceAddress']
        user=o['resource']['User']
        password=o['resource']['Password']

        self._cell_router =  CiscoHandlerFactory.createHandler('CELLROUTER', ip, user, password, 'file')
        if not file_name == '':
            self._cell_router.setConnectionProperty(file_name)

        if not self._cell_router is None:
            return 'Handler successfully created, log file {0}'.format(file_name)
        else:
            return 'Failed to create \'CELLROUTER\' handler.'


    @DriverFunction
    def ConfigureTerminal(self, matrixJson):
        if self._cell_router.enterConfigurationMode():
            return '---- Configure terminal activated ---'
        else:
            return '---- Failed to activate configuration terminal! ----'


    @DriverFunction
    def EnableService(self, matrixJson, service_name, args):
        #o=json.loads(matrixJson)
        out = self._cell_router.enableService(service_name, args)
        return out

    @DriverFunction
    def SetDefaults(self, matrixJson):
        return self._cell_router.setDefaults()


    @DriverFunction
    def SetLoggingBuffered(self, matrixJson,bufferSize):
        return self._cell_router.setLoggingBuffered(bufferSize)

    @DriverFunction
    def EnableSecret(self, matrixJson, secret):
        return self._cell_router.enableSecret(secret)

    @DriverFunction
    def ConfigureHostName(self, matrixJson, hostName):
        return self._cell_router.configureHostName(hostName)

    @DriverFunction
    def SetIpDomain(self, matrixJson, domain):
        return self._cell_router.setIpDomain(domain)


    @DriverFunction
    def SetIpHost(self, matrixJson, host, port, gateway):
        return self._cell_router.setIpHost(host, port, gateway)

    @DriverFunction
    def EnableBootPriority(self, matrixJson):
        return self._cell_router.setBootP(mode='enable')

    @DriverFunction
    def DisableBootPriority(self, matrixJson):
        return self._cell_router.setBootP(mode='disable')

    @DriverFunction
    def SetIpDomainName(self, matrixJson, domainName):
        return self._cell_router.setIpDomainName(domainName)

    @DriverFunction
    def EnableIpDomainLookup(self, matrixJson):
        return self._cell_router.setIpDomainLookup(mode='enable')

    @DriverFunction
    def DisableIpDomainLookup(self, matrixJson):
        return self._cell_router.setIpDomainLookup(mode='disable')

    @DriverFunction
    def ConfigureSSHServer(self, matrixJson, username, password, privilege):
        if privilege=='':
            privilege=15
        return self._cell_router.enableSSH(username, password, privilege)

    @DriverFunction
    def ConfigureInterface(self, matrixJson, interfaceName, ipAddress, mask='', ipNat='', description=''):

        if mask=='': mask='255.255.255.0'
        if description == '': description=None

        return self._cell_router.configureInterface(interfaceName, ip=ipAddress, mask=mask, ip_nat=ipNat, description=description)

    @DriverFunction
    def AddStaticRoute(self, matrixJson, destAddress, destMask, gateway, interface, dhcp='', distance='',
                             name='', permanent='', trackNumber='', tag=''):
        if destAddress=='' or destMask=='' or gateway == '':
            msg = 'Following parameters can not be empty: destAddress, destMask, gateway.'
            raise Exception('Cisco Cell-Router:AddStaticRoute ', msg)

        return self._cell_router.configureStaticRoute(destAddress, destMask, gateway, interface, dhcp=dhcp, distance=distance,
                             name=name, permanent=permanent, track_number=trackNumber, tag=tag, mode='enable')

    @DriverFunction
    def RemoveStaticRoute(self, matrixJson, destAddress, destMask, gateway, interface, dhcp='', distance='',
                             name='', permanent='', trackNumber='', tag=''):

        return self._cell_router.configureStaticRoute(destAddress, destMask, gateway, interface, dhcp=dhcp, distance=distance,
                     name=name, permanent=permanent, track_number=trackNumber, tag=tag, mode='disable')


    @DriverFunction
    def GenerateRSA(self, matrixJson, type='', keyLabel='', exportable='', modulusSize='',
                    storageDeviceName='', redundancy='', deviceName=''):

        if type == '': type = 'general-keys'
        return self._cell_router.generateRSA(type, keyLabel, exportable, modulusSize,
                    storageDeviceName, redundancy, deviceName)

    @DriverFunction
    def ConfigureLine(self, matrixJson, line, startIndex, endIndex='', exeTimeoutMins='', execTimeoutSecs='',
                      privilegeLevel='', password='', noExec='', logging='', transportInput='',
                      transportOutput='', stopbits=''):


        """Set line configuration, receive list of commands to send to device

        :param matrixJson:
        :param line:
        :param startIndex:
        :param endIndex:
        :param commands:
        :return:
        """

        res = self._cell_router.configureLine(line, startIndex, endIndex, exeTimeoutMins, execTimeoutSecs,
                      privilegeLevel, password, noExec, logging, transportInput, transportOutput, stopbits)

        #retry to send configuration comands
        if not res:
            self._cell_router.enterConfigurationMode()
            res = self._cell_router.configureLine(line, startIndex, endIndex, exeTimeoutMins, execTimeoutSecs,
                      privilegeLevel, password, noExec, logging, transportInput, transportOutput, stopbits)

        return res

    @DriverFunction
    def ConfigureStaticNat(self, matrixJson, direction, mode, protocol, local_address, global_address, local_port='',
                           global_port=''):
        out = self._cell_router.configureStaticNAT(direction, mode, protocol, local_address, global_address, local_port, global_port)
        return out

    @DriverFunction
    def ConfigureBootSettings(self, matrixJson):
        return self._cell_router.configureBootSettings(ip_boot_server='DISABLE')

    @DriverFunction
    def DisableAAA(self, matrixJson):
        return self._cell_router.configureAAA(mode='DISABLE')

    @DriverFunction
    def ShowRun(self, matrixJson):
        out = self._cell_router.showRun()
        return out

    @DriverFunction
    def ConfigureDynamicNAT(self, matrixJson, interface, accessListName, action, srcNetwork='', srcWildCard='',
                            destNetwork='', destWildCard='', protocol='', aclType=''):
        '''Create Access list for NAT rule and assign it to provided interface
        :param accessListName: name for access list
        :param action: [permit|deny]
        :param srcNetwork: source network address [ANY|a.b.c.d|host|object_group]
        :param srcWildCard: source wild card mask
        :param destNetwork: destination network address [ANY|a.b.c.d|host|object_group]
        :param destWildCard: destination wild card mask
        :param protocol: protocol for access list [tcp, udp, ospf, icmp, etc.]
        :param aclType: [extended, log-update, logging, resequence, standard]
        :return: 1 if configured
        '''

        #--- init defaults -------
        if protocol == '': protocol='ip'
        if srcNetwork == '': srcNetwork='any'
        if destNetwork == '': destNetwork='any'
        if aclType == '': aclType='standard'

        out = self._cell_router.configureIpAccessList(accessListName, action, protocol, srcNetwork, srcWildCard,
                                                      destNetwork, destWildCard, aclType)
        out += '\n'
        out += self._cell_router.configureNatOnInterface(interface, accessListName)
        return out

    @DriverFunction
    def ConfigureVoiceCard(self, matrixJson, cardIndex, dfsfarm=''):
        if cardIndex == '':
            raise Exception('Cisco Cell-Router', 'CardIndex can not be empty')

        return  self._cell_router.configureVoiceCard(cardIndex, dfsfarm)

    @DriverFunction
    def SaveActiveConfig(self, matrixJson):
        return self._cell_router.saveActiveConfig()

    @DriverFunction
    def ResetConfig(self, matrixJson):
        return self._cell_router.resetConfig()

    @DriverFunction
    def SetAutoReload(self, matrixJson, minutes):
        return self._cell_router.setAutoReload(minutes)



if __name__ == '__main__':

    data_json = """{
        "resource" : {
                "ResourceAddress": "10.11.2.101",
                "User": "admin",
                "Password": "@Vantage123"
            }
    }"""


    router = cell_router_resource_driver('18', data_json, )
    #router.ConnectToFile(data_json, 'C:\Temp\execution-output.log')

    router.Connect(data_json)
    router.ConfigureDynamicNAT(data_json, 'GigabitEthernet0/0', 'InternetPAT', 'permit', srcNetwork='10.0.0.0',
                               srcWildCard='0.0.0.255', destNetwork='any', protocol='ip', aclType='extended')
    sys.exit()

    router.SetDefaults(data_json)


    router.EnableService(data_json, 'tcp-keepalives-in')
    router.EnableService(data_json, 'tcp-keepalives-out')
    router.EnableService(data_json, 'timestamps debug datetime msec localtime show-timezone')
    router.EnableService(data_json, 'timestamps log datetime msec localtime show-timezone')
    router.EnableService(data_json, 'password-encryption')

    router.DisableAAA(data_json)
    router.ConfigureHostName(data_json, 'sysID')


    router.ConfigureBootSettings(data_json)
    router.SetLoggingBuffered(data_json, '51200')
    router.EnableSecret(data_json, '@Vantage123')
    router.EnableBootPriority(data_json)

    router.EnableIpDomainLookup(data_json)
    router.SetIpDomainName(data_json, 'my-domain_name')


    router.setIpHost('hostname', '555', '10.0.0.10')
    router.SetIpHost(data_json, 'hostname', '555', '10.0.0.10')



    out = router.ConfigureDynamicNAT(data_json, 'GigabitEthernet0/0','InternetPAT','permit','10.0.0.0','0.0.0.255','any','','','extended')
    print "------------\n\n"+out