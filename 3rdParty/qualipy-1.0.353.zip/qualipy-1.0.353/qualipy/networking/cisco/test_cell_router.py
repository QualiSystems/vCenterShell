__author__ = 'oei'

import unittest

from qualipy.common.libs.utils import isSameListCommandInFile
from qualipy.common.cisco.cisco_handler_factory import CiscoHandlerFactory

class TestCellRouter(unittest.TestCase):
    def setUp(self):
        host = ''
        username = ''
        password = ''

        self._log_folder = 'Logs'
        self._log_filename = self._log_folder + '/cell_router_unittest.log'

        self._cell_router = CiscoHandlerFactory.createHandler('CELLROUTER', host, username, password, 'file',
                                                              filename=self._log_filename)

    def tearDown(self):
        self._cell_router.disconnect()

    def test_configureStaticRoutes(self):
        self._cell_router.configureStaticRoute('0.0.0.0', '0.0.0.0', '10.0.0.0', 'test')

        expect_list = ['ip route 0.0.0.0 0.0.0.0 10.0.0.0 test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setDefaults(self):
        self._cell_router.setDefaults()

        expect_list = ['scheduler allocate 20000 1000', 'resource policy', 'clock timezone GMT 0',
                       'ip subnet-zero', 'ip cef']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureHostName(self):
        self._cell_router.configureHostName('test')

        expect_list = ['hostname test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureServices(self):
        self._cell_router.configureServices()

        expect_list = ['service tcp-keepalives-in', 'service tcp-keepalives-out',
                       'service timestamps debug datetime msec localtime show-timezone',
                       'service timestamps log datetime msec localtime show-timezone', 'service password-encryption']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_enableService(self):
        self._cell_router.enableService('test')

        expect_list = ['service test ']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setLoggingBuffered(self):
        self._cell_router.setLoggingBuffered('1200')

        expect_list = ['logging buffered 1200 informational']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_enableSecret(self):
        self._cell_router.enableSecret('test')

        expect_list = ['enable secret test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setIpDomain(self):
        self._cell_router.setIpDomain('test')

        expect_list = ['ip domain name test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setIpHost(self):
        self._cell_router.setIpHost('test', '22')

        expect_list = ['ip host test 22 10.10.10.1']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setBootP(self):
        self._cell_router.setBootP()

        expect_list = ['no ip bootp server']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setIpDomainName(self):
        self._cell_router.setIpDomainName('test')

        expect_list = ['ip domain name test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setIpDomainLookup(self):
        self._cell_router.setIpDomainLookup()

        expect_list = ['no ip domain lookup']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_enableSSH(self):
        self._cell_router.enableSSH('test', 'test_pass')

        expect_list = ['ip ssh version 2', 'username test privilege 15 password test_pass']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureInterface(self):
        self._cell_router.configureInterface('test', '127.0.0.1')

        expect_list = ['interface test', 'ip address 127.0.0.1 255.255.255.0', 'ip virtual-reassembly']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureStaticRoute(self):
        self._cell_router.configureStaticRoute('127.0.0.1', '255.255.255.0', '127.0.0.1', 'test')

        expect_list = ['ip route 127.0.0.1 255.255.255.0 127.0.0.1 test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_generateRSA(self):
        self._cell_router.generateRSA()

        expect_list = ['crypto key generate rsa general-keys ']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureIpAccessList(self):
        self._cell_router.configureIpAccessList('test', 'make')

        expect_list = ['ip access-list standard test', 'make ip any any']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureNatOnInterface(self):
        self._cell_router.configureNatOnInterface('test', 'make')

        expect_list = ['ip nat source list make interface test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureLine(self):
        self._cell_router.configureLine('aux', '22')

        expect_list = ['ip access-list standard test', 'make ip any any']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureBootSettings(self):
        self._cell_router.configureBootSettings()

        expect_list = ['boot-start-marker', 'boot-end-marker']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureAAA(self):
        self._cell_router.configureAAA()

        expect_list = ['no aaa new-model']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureVoiceCard(self):
        self._cell_router.configureVoiceCard('13')

        expect_list = ['ip route 0.0.0.0 0.0.0.0 10.0.0.0 test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_saveActiveConfig(self):
        self._cell_router.saveActiveConfig()

        expect_list = ['copy running-config startup-config', ' ', ' ']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_resetConfig(self):
        self._cell_router.resetConfig()

        expect_list = ['copy startup-config running-config', ' ', ' ']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_showRun(self):
        self._cell_router.showRun()

        expect_list = ['show running']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setAutoReload(self):
        self._cell_router.setAutoReload('22')

        expect_list = ['reload in 22', ' ']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

if __name__ == '__main__':
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass
