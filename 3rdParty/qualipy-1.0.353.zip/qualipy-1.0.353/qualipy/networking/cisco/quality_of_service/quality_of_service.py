__author__ = 'g8y3e'

from qualipy.common.libs.parameters_service.parameters_service import *
from qualipy.common.libs.parameters_service.command_template import *

class QualityOfService:
    COMMANDS_TEMPLATE = {
        'match': CommandTemplate('match {0} {1}', [r'\w+', r'[0-9]+'],
                                ['Wrong match type!', 'Wrong match value!']),
        'class_map': CommandTemplate('class-map type {0} {1}', [r'[\w-]+',r'[\w-]+'],
                                     ['Wrong class-map type!', 'Wrong class-map name!']),
        'class': CommandTemplate('class {0}', [r'[\w_-]+'], ['Wrong class name!']),
        'class_type': CommandTemplate('class type {0} {1}', [r'[\w_-]+', r'[\w_-]+'],
                                      ['Wrong class-type type!', 'Wrong class-type name!']),
        'bandwidth': CommandTemplate('bandwidth {0} {1}', [r'percent', '[0-9]+'],
                                     ['Wrong bandwidth type!', 'Wrong bandwidth value!']),
        'policy_map': CommandTemplate('policy-map type {0} {1}', [r'[\w_-]+', r'[\w_-]+'],
                                      ['Wrong policy-map type!', 'Wrong policy-map name!']),
        'set': CommandTemplate('set {0} {1}', [r'[\w_-]+', r'[\w_-]+'],
                                      ['Wrong set type!', 'Wrong set name!']),
        'service_policy': CommandTemplate('service-policy type {0} {1} {2}', [r'[\w-]+', r'input$|output$| ', r'[\w-]+'],
                                          ['Wrong service-policy type!', 'Wrong service-policy value!']),
        'system': CommandTemplate('system {0}', 'qos', 'Wrong system name!')
    }

    def getMatch(self, match_map):
        command_template = QualityOfService.COMMANDS_TEMPLATE['match']

        if not ('name' in match_map) or not ('value' in match_map):
            raise Exception('Incorrect match map (not found value or name)!')

        return ParametersService.getValidateList(command_template,
                                                 [match_map['name'], match_map['value']])

    def getClassMap(self, class_type, class_name):
        command_template = QualityOfService.COMMANDS_TEMPLATE['class_map']

        return ParametersService.getValidateList(command_template, [class_type, class_name])

    def getClassMapCommands(self, class_map):
        prepared_commands = []
        for value in class_map:
            if (not 'type' in value) or (not 'name' in value):
                raise Exception("Class map item doesn't contain 'type' or 'name' field!")

            prepared_commands.append(self.getClassMap(value['type'], value['name']))

            if ('method' in value) and ('method_params' in value):
                if 'match' == value['method']:
                    prepared_commands.append(self.getMatch(value['method_params']))
                else:
                    raise Exception('Unknown class-map method!')

        return prepared_commands

    def getSet(self, params_list):
        if (not 'name' in params_list) or (not 'value' in params_list):
            raise Exception("Set item doesn't contain 'name' or 'value' field!")

        command_template = QualityOfService.COMMANDS_TEMPLATE['set']

        return ParametersService.getValidateList(command_template, [params_list['name'], params_list['value']])

    def getClass(self, class_map):
        prepared_commands = []
        for value in class_map:
            if not 'name' in value:
                raise Exception("Class item doesn't contain 'name' field!")

            command_template = QualityOfService.COMMANDS_TEMPLATE['class']
            prepared_commands.append(ParametersService.getValidateList(command_template, [value['name']]))

            if ('method' in value) and ('method_params' in value):
                if 'set' == value['method']:
                    prepared_commands.append(self.getSet(value['method_params']))
                else:
                    raise Exception('Unknown class method!')

        return prepared_commands

    def getBandwidth(self, bandwidth_map):
        if (not 'name' in bandwidth_map) or (not 'value' in bandwidth_map):
            raise Exception("Bandwidth item doesn't contain 'name' or 'value' field!")

        command_template = QualityOfService.COMMANDS_TEMPLATE['bandwidth']

        return ParametersService.getValidateList(command_template, [bandwidth_map['name'], bandwidth_map['value']])

    def getClassType(self, class_type_map):
        prepared_commands = []
        for value in class_type_map:
            if (not 'name' in value) or (not 'type' in value):
                raise Exception("Class-type item doesn't contain 'name' or 'type' field!")

            command_template = QualityOfService.COMMANDS_TEMPLATE['class_type']
            prepared_commands.append(ParametersService.getValidateList(command_template, [value['name'], value['type']]))

            if ('method' in value) and ('method_params' in value):
                if 'bandwidth' in value['method']:
                    prepared_commands.append(self.getBandwidth(value['method_params']))
                else:
                    raise Exception('Unknown class-type method!')

        return prepared_commands

    def getPolicyMap(self, policy_type, policy_name):
        command_template = QualityOfService.COMMANDS_TEMPLATE['policy_map']

        return ParametersService.getValidateList(command_template, [policy_type, policy_name])

    def getPolicyMapCommands(self, policy_map):
        prepared_commands = []
        for value in policy_map:
            if (not 'type' in value) or (not 'name' in value):
                raise Exception("Policy map item doesn't contain 'type' or 'name' field!")

            prepared_commands.append(self.getPolicyMap(value['type'], value['name']))

            if ('method' in value) and ('method_params' in value):
                if 'class' == value['method']:
                    prepared_commands += self.getClass(value['method_params'])
                elif 'class_type' == value['method']:
                    prepared_commands += self.getClassType(value['method_params'])
                else:
                    raise Exception('Unknown class-map method!')

        return prepared_commands

    def getServicePolicyMapCommands(self, service_policy_map):
        prepared_commands = []

        if (not 'name' in service_policy_map) or (not 'services' in service_policy_map):
            raise Exception("Policy map item doesn't contain 'name' or 'services' field!")

        command_template = QualityOfService.COMMANDS_TEMPLATE['system']
        prepared_commands.append(ParametersService.getValidateList(command_template, [service_policy_map['name']]))

        for value in service_policy_map['services']:
            if (not 'type' in value) or (not 'value' in value):
                raise Exception("Policy map item doesn't contain 'type' or 'value' field!")

            if  not 'direction' in value:
                value['direction'] = ' '

            command_template = QualityOfService.COMMANDS_TEMPLATE['service_policy']
            prepared_commands.append(ParametersService.getValidateList(command_template, [value['type'],
                                                                        value['direction'], value['value']]))

        return prepared_commands

    def getCommands(self, **kwargs):
        prepared_commands = []

        if 'class_map' in kwargs:
            prepared_commands += self.getClassMapCommands(kwargs['class_map'])

        if 'policy_map' in kwargs:
                prepared_commands += self.getPolicyMapCommands(kwargs['policy_map'])

        if 'service_policy' in kwargs:
            prepared_commands += self.getServicePolicyMapCommands(kwargs['service_policy'])

        return prepared_commands

if __name__ == '__main__':
    qos = QualityOfService()

    class_map = [
        {
            'type': 'qos',
            'name': 'class-gold',
            'method': 'match',
            'method_params':  {
                'name': 'cos',
                'value': '4'
            }
        },
        {
            'type': 'qos',
            'name': 'class-platinum',
            'method': 'match',
            'method_params': {
                'name': 'cos',
                'value': '4'
            }
        },
        {
            'type': 'queuing',
            'name': 'class-gold',
            'method': 'match',
            'method_params': {
                'name': 'cos',
                'value': '4'
            }
        },
        {
            'type': 'queuing',
            'name': 'class-platinum',
            'method': 'match',
            'method_params': {
                'name': 'cos',
                'value': '4'}
        },
        {
            'type': 'network-qos',
            'name': 'class-gold',
            'method': 'match',
            'method_params': {
                'name': 'qos-group',
                'value': '3'}
        },
        {
            'type': 'network-qos',
            'name': 'class-platinum',
            'method': 'match',
            'method_params': {
                'name': 'qos-group',
                'value': '2'}
        }
    ]

    policy_map = [
        {
            'type': 'qos',
            'name': 'system_qos_policy',
            'method': 'class',
            'method_params': [
                {
                    'name': 'class-platinum',
                    'method': 'set',
                    'method_params': {
                        'name': 'qos-group',
                        'value': '2'
                    }
                },
                {
                    'name': 'class-gold',
                    'method': 'set',
                    'method_params': {
                        'name': 'qos-group',
                        'value': '3'
                    }
                }
            ]
        },
        {
            'type': 'network-qos',
            'name': 'system_nq_policy',
            'method': 'class',
            'method_params': [
                {
                    'type': 'network-qos',
                    'name': 'class-default',
                },
                {
                    'type': 'network-qos',
                    'name': 'class-platinum',
                },
                {
                    'type': 'network-qos',
                    'name': 'class-gold',
                },
                {
                    'type': 'network-qos',
                    'name': 'class-fcoe',
                }
            ]
        },
        {
            'type': 'queuing',
            'name': 'system_q_in_policy',
            'method': 'class_type',
            'method_params': [
                {
                    'type': 'queuing',
                    'name': 'class-platinum',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '5'
                    }
                },
                {
                    'type': 'queuing',
                    'name': 'cclass-gold',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '10'
                    }
                },
                {
                    'type': 'queuing',
                    'name': 'class-fcoe',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '0'
                    }
                },
                {
                    'type': 'queuing',
                    'name': 'class-default',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '85'
                    }
                }

            ]
        },
        {
            'type': 'queuing',
            'name': 'system_q_out_policy',
            'method': 'class_type',
            'method_params': [
                {
                    'type': 'queuing',
                    'name': 'class-platinum',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '5'
                    }
                },
                {
                    'type': 'queuing',
                    'name': 'cclass-gold',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '10'
                    }
                },
                {
                    'type': 'queuing',
                    'name': 'class-fcoe',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '0'
                    }
                },
                {
                    'type': 'queuing',
                    'name': 'class-default',
                    'method': 'bandwidth',
                    'method_params': {
                        'name': 'percent',
                        'value': '85'
                    }
                }

            ]
        }
    ]

    service_policy = {
        'name': 'qos',
        'services': [
            {
                'type': 'qos',
                'value': 'system_qos_policy',
            },
            {
                'type': 'queuing',
                'value': 'system_q_in_policy',
            },
            {
                'type': 'queuing',
                'value': 'system_q_out_policy',
            },
            {
                'type': 'network-qos',
                'value': 'system_nq_policy',
            }
        ]
    }

    # fixme need to finish policies map
    prepared_commands = qos.getCommands(class_map=class_map, policy_map=policy_map,
                                        service_policy=service_policy)

    print 'tt'