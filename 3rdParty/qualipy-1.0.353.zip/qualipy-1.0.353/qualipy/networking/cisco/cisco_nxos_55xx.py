__author__ = 'oei'

from qualipy.common.cisco.cisco_nxos import *

class CiscoNXOS55xx(CiscoNxOS):
    def __init__(self, connection_manager, logger):
        CiscoNxOS.__init__(self, connection_manager, logger)
