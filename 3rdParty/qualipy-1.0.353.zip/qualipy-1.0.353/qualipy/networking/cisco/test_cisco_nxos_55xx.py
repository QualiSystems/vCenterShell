from qualipy.common.cisco.test_cisco_nxos import *
from qualipy.common.cisco.cisco_handler_factory import CiscoHandlerFactory
import shutil

class TestCisco55XX(TestCiscoNxos):
    def setUp(self):
        host = ''
        username = ''
        password = ''

        self._log_folder = 'Logs'
        self._log_filename = self._log_folder + '/nxos_55xx.log'
        self._cisco_nxos = CiscoHandlerFactory.createHandler('nxos_55xx', host, username, password, 'file',
                                                                  filename=self._log_filename)

    def tearDown(self):
        self._cisco_nxos.disconnect()

    def test_configureSpanningTreePortType(self):
        self._cisco_nxos.configureSpanningTreePortType('edge')

        expect_list = ['spanning-tree port type edge default']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)


    def test_setSpanningTreeVlanPriority(self):
        self._cisco_nxos.setSpanningTreeVlanPriority('1-10', 'test')

        expect_list = ['spanning-tree vlan 1-10 priority test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

if __name__ == '__main__':
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass

