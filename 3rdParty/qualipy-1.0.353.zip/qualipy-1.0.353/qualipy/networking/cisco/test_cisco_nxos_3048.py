__author__ = 'g8y3e'

from qualipy.common.cisco.cisco_handler_factory import *
from qualipy.common.cisco.test_cisco_nxos import *

import unittest
import json
import collections
from qualipy.common.libs.utils import isSameListCommandInFile

def setUpModule():
    print 'Cisco Nxos 3048 unittest start!'

def tearDownModule():
    print '\nCisco Nxos 3048 unittest end!'

class TestCiscoNxOS3048(TestCiscoNxos):
    @staticmethod
    def setUpClass():
        print 'Cisco Nxos 3048 Test start'

    @staticmethod
    def tearDownClass():
        print 'Cisco Nxos 3048 Test end'

    def setUp(self):
        host = ''
        username = ''
        password = ''

        self._log_filename = 'Logs/nx_os_3048_unittest.log'

        self._cisco_nxos = CiscoHandlerFactory.createHandler('nxos_3048', host, username, password, 'file', filename=self._log_filename)

    def tearDown(self):
        self._cisco_nxos.disconnect()

    def test_SnmpServer(self):
        params_map = {}
        params_map['snmp server host custom port'] = [ '10.11.12.13', '2c', '162']
        params_map['snmp server host'] = [ '10.11.12.13', '3']
        params_map['snmp server community'] = ['test', 'group']
        params_map['enable traps'] = []
        self._cisco_nxos.configureSnmpServer(**params_map)
        expect_list = ['snmp-server host 10.11.12.13 traps version 3',
                       'snmp server community test group group',
                       'snmp-server enable traps',
                       'snmp-server host 10.11.12.13 traps version 2c udp-port 162']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_NtpServer(self):
        self._cisco_nxos.configureNtpServer('127.0.0.2')
        expect_list = ['ntp server 127.0.0.2']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

def suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestCiscoNxOS3048))

    return suite

if (__name__ == '__main__'):
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass