#import json
from qualipy.networking.cisco.cisco_nxos_3048_resource_driver import CiscoNXOS3048ResourceDriver
#from qualipy.networking.cisco.cisco_nxos_3048_resource_driver import CiscoNXOS3048ResourceDriver
#from qualipy.common.cisco.cisco_handler_factory import CiscoHandlerFactory
if __name__ == '__main__':
    data_json = str("""{
            "resource" : {
                    "ResourceAddress": "10.11.169.187",
                    "User": "admin",
                    "Password": "@Vantage123",
                    "ConsoleUser": "admin",
                    "ConsolePassword": "@Vantage123",
                    "ConsolePort": "3048-3-A",
                    "ConsoleServerIpAddress" :"10.11.169.187",
                    "Filename": "debug",
                    "Output": ""
                }
            }""")

    # data_json = str("""{
    #         "resource" : {
    #                 "ResourceAddress": "10.11.169.187",
    #                 "User": "admin",
    #                 "Password": "@Vantage123",
    #                 "ConsoleUser": "admin",
    #                 "ConsolePassword": "@Vantage123",
    #                 "ConsolePort": "3048-3-A",
    #                 "ConsoleServerIpAddress" :"10.11.169.187",
    #                 "Output": ""
    #             }
    #         }""")

    nxos3048_handler = CiscoNXOS3048ResourceDriver(1, data_json)
    print nxos3048_handler.ClockTimezone("{}", "PST", "-7", "00")
    print nxos3048_handler.DisableLogging("{}", "monitor")
    print nxos3048_handler.ConfigureLogging("{}", "monitor")
    print nxos3048_handler.ConfigureSSH('{}', 'rsa')
    print nxos3048_handler.ConfigureTelnet('{}', 'disable')
    print nxos3048_handler.ConfigureCFS('{}', 'enable')
    print nxos3048_handler.ConfigureLacp('{}', 'enable')
    print nxos3048_handler.ConfigureVPC('{}', 'enable')
    # print nxos3048_handler.ConfigureInterfaceVlan('{}', 'enable')
    print nxos3048_handler.ConfigureHsrp('{}', 'enable')
    print nxos3048_handler.ConfigureDefaultRole('{}')
    print nxos3048_handler.AddUser('{}', 'admin2', 'cisco', 'network-admin')
    print nxos3048_handler.AddBanner('{}', 'this is a banner')
    print nxos3048_handler.ConfigureIpDomainLookup('{}', 'disable')
    print nxos3048_handler.SetHostName('{}', 'test-hostname')

    # print nxos3048_handler.SetSpanningTreePortEdge('{}')
    # print nxos3048_handler.SetSpanningTreePortNetwork('{}')
    # print nxos3048_handler.SetSpanningTreePort('{}', 'edge trunk')
    # print nxos3048_handler.SetSpanningTreeBridgeAssurance('{}')
    # print nxos3048_handler.SetSpanningTreePseudoInformation('{}')
    # print nxos3048_handler.SetSpanningTreeDomain('{}', 6)
    # print nxos3048_handler.SetSpanningTreeLoopguard('{}')
    # print nxos3048_handler.SetSpanningTreeMode('{}', 'mst')
    # print nxos3048_handler.SetSpanningTreePathcost('{}', 'long')
    # print nxos3048_handler.SetSpanningTreeMstRange('{}', '1-3568')
    # print nxos3048_handler.SetSpanningTreeMstForwardTime('{}', '10')
    # print nxos3048_handler.SetSpanningTreeMstHelloTime('{}', '10')
    # print nxos3048_handler.SetSpanningTreeMstMaxAge('{}', '20')
    # print nxos3048_handler.SetSpanningTreeMstMaxHops('{}', '30')
    # print nxos3048_handler.SetSpanningTreeMstSimulate('{}')
    # print nxos3048_handler.SetSpanningTreeVlanForwardTime('{}', '1-456', '20')
    # print nxos3048_handler.SetSpanningTreeVlanHelloTime('{}', '1-456', '10')
    # print nxos3048_handler.SetSpanningTreeVlanMaxAge('{}', '1-456', '40')
    # print nxos3048_handler.SetSpanningTreeVlanPriority('{}', "1-3967,4048-4093","49152")
    # print nxos3048_handler.SetSpanningTreeVlanRoot('{}', '1-456', 'primary', "7")
    print nxos3048_handler.AddVpcDomain('{}', "10", "10.1.1.2", "management", "8192", "8192", 'yes', 'yes')
    print nxos3048_handler.ConfigureSNMPService('{}', '', 'community_description', '', 'network operator','','')
    print nxos3048_handler.ConfigureSNMPService('{}', '10.11.12.13', '', '', '', '2c', 'yes')
    print nxos3048_handler.ConfigureSNMPService('{}', '10.11.12.13', '', '162', '', '2c', 'yes')
    print nxos3048_handler.ConfigureNtpService('{}', '127.0.0.2')
    # print nxos3048_handler.ConfigureVlanInterface('{}', "101", "10.1.1.2", "255.255.255.0", "101", "Vce12345", "10.0.0.1")
    # print nxos3048_handler.SetInterfaceEthernet('{}', '10')
    # print nxos3048_handler.SetInterfaceEthernetRegex('{}', '.*')
    # print nxos3048_handler.SetInterfaceLoopback('{}', '11')
    # print nxos3048_handler.SetInterfaceLoopbackRegex('{}', '.*')
    # print nxos3048_handler.SetInterfaceMgmt('{}', '12')
    # print nxos3048_handler.SetInterfaceMgmtRegex('{}', '.*')
    # print nxos3048_handler.SetInterfacePortChannel('{}', '13')
    # print nxos3048_handler.SetInterfacePortChannelRegex('{}', '.*')
    # print nxos3048_handler.SetInterfaceVlan('{}', '14')
    # print nxos3048_handler.SetInterfaceVlanRegex('{}', '.*')
    # print nxos3048_handler.SetSwitchportMode('{}', 'trunk')
    # print nxos3048_handler.SetSwitchportAccess('{}', '15')
    # print nxos3048_handler.SetSwitchportAutostateExclude('{}')
    # print nxos3048_handler.SetSwitchportBlock('{}', 'unicast')
    # print nxos3048_handler.SetSwitchportDescription('{}', 'description')
    # print nxos3048_handler.SetSwitchportDot1q('{}', '', '', 0)
    # print nxos3048_handler.SetSwitchportTrunk('{}', 'allowed', 0, 'all')
    # print nxos3048_handler.SetVpc('{}', '10')




