
import unittest
import sys
sys.path.append('../../')
from qualipy.common.libs.ssh_manager import SSHManager
#from teamcity import is_running_under_teamcity
#from teamcity.unittestpy import TeamcityTestRunner
from qualipy.networking.cisco.cisco_nxos_3048_resource_driver import CiscoNXOS3048ResourceDriver
#from common.cisco.cisco_nxos import CiscoNxOS
from qualipy.networking.cisco.cisco_nxos_3048_resource_driver import CiscoNXOS3048ResourceDriver
from qualipy.common.libs.utils import isSameListCommandInFile
from qualipy.common.cisco.cisco_handler_factory import *

class NXOS3048Test(unittest.TestCase):
    def setUp(self):
        self._log_filename = 'nxos3048_unittest.log'
        data_json = """{
            "resource" : {
                    "ResourceAddress": "10.11.34.68",
                    "User": "admin",
                    "Password": "@Vantage123",
                    "Output": "file",
                    "Filename": \"""" +self._log_filename + """\"
                }
        }"""
        # data_json = """{
        #     "resource" : {
        #             "ResourceAddress": "10.11.242.8",
        #             "User": "admin",
        #             "Password": "@Vantage123",
        #             "ConsoleUser": "admin",
        #             "ConsolePassword": "@Vantage123",
        #             "ConsolePort": "3048-3-A",
        #             "ConsoleServerIpAddress" :"10.11.242.8"
        #
        #         }
        #     }"""
        self._nxos3048_handler = CiscoNXOS3048ResourceDriver(1, data_json)
    def tearDown(self):
        #self._ssh_handler.disconnect()
        pass 

    def testConfigureSSH(self):
        self._nxos3048_handler.ConfigureSSH('{}', 'enable')
        expect_list = ['no feature ssh', 'ssh key rsa 2048 force', 'feature ssh']   
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testConfigureTelnet(self):
        self._nxos3048_handler.ConfigureTelnet('{}','disable')
        expect_list = [ 'no feature telnet', 'no telnet server enable']  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testEnableCFS(self):
        self._nxos3048_handler.ConfigureCFS('{}', 'enable')
        expect_list = [ 'cfs eth distribute']  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testEnableLacp(self):
        self._nxos3048_handler.ConfigureLacp('{}', 'enable')
        expect_list = [ 'feature lacp']  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testEnableVPC(self):
        self._nxos3048_handler.ConfigureVPC('{}','enable')
        expect_list = [ 'feature vpc']  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testEnableInterfaceVlan(self):
        self._nxos3048_handler.ConfigureInterfaceVlan('{}', 'enable')
        expect_list = [ 'feature interface-vlan']  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testEnableHsrp(self):
        self._nxos3048_handler.ConfigureHsrp('{}', 'enable')
        expect_list = [ 'feature hsrp']  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)
        
    def testConfigureDefaultRole(self):
        self._nxos3048_handler.ConfigureDefaultRole('{}')
        expect_list = ['role name default-role', 'description This is a system defined role and applies to all users.']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testAddUser(self):
        self._nxos3048_handler.AddUser('{}', 'admin2', 'cisco', 'network-admin')
        expect_list = [ 'username admin2 password cisco role network-admin' ]  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testAddBanner(self):
        self._nxos3048_handler.AddBanner('{}', 'this is a banner')
        expect_list = [ 'banner motd #this is a banner\n#' ]
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testIpDomainLookup(self):
        self._nxos3048_handler.ConfigureIpDomainLookup('{}', 'disable')
        expect_list = [ 'no ip domain-lookup' ]  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testSetHostname(self):
        self._nxos3048_handler.SetHostName('{}','test-hostname')
        expect_list = [ 'hostname test-hostname' ]  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testAddSpanningTreePortTEdge(self):
        self._nxos3048_handler.AddSpanningTreePortTEdge('{}',"test-name")
        expect_list = [ 'spanning-tree port type edge test-name default' ]  # doesn't work on device
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testAddSpanningTreeVlan(self):
        self._nxos3048_handler.AddSpanningTreeVlan('{}',"1-3967,4048-4093","49152")
        expect_list = [ 'spanning-tree vlan 1-3967,4048-4093 priority 49152' ]  
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def testAddVpcDomain(self):
        self._nxos3048_handler.AddVpcDomain('{}',10, "10.1.1.2", "8192", "8192")
        expect_list = [ 'vpc domain 10', 'system-priority 8192', 'role priority 8192', 'peer-keepalive destination 10.1.1.2 vrf management', 'auto-recovery' , 'exit'] # requires confirmation in prompt
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    #def testConfigureInterfaceVlan(self):
    #    self._nxos3048_handler.configureInterfaceVlan("10","192.168.10.10", "255.255.255.0", "101", "105", "Vce12345", "51", "20", "mgmt ip")

    #def testInterfacePortChannel(self):
    #    self._nxos3048_handler.interfacePortChannel("5", 'To Customer Management Switch A', "5", "45", 'normal')
    #    self._nxos3048_handler.interfacePortChannel("6", 'To Customer Management Switch B', "6", "46", 'normal')

    #def testInterfaceEthernet(self):
    #    self._nxos3048_handler.interfaceEthernet('1/49', '3048-B 1/49', "149", '', "10")

    #def testInterfaceMgmt(self):
    #    self._nxos3048_handler.interfaceMgmt("0", 'vPC peer keepalive link to 3048-B mgmt0', "10.1.1.1", "255.255.255.252")

    #def testConfigureLine(self):
    #    self._nxos3048_handler.configureLine(5,5)

if (__name__ == '__main__'):
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass