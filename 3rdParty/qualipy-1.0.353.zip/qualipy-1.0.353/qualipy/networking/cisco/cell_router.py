__author__ = 'oei'
import re
import time

from qualipy.common.cisco.cisco_ios import CiscoIOS

class CellRouter(CiscoIOS):
    DEFAULT_PROMPT = '.*#'
    CONFIG_MODE_PROMPT = '\(config.*\)#'
    DEFAULT_PASSWORD = 'DefaultPassword'
    DEFAULT_GW_IP = '10.10.10.1'
    CELL_ID = '#TBD'
    ERR_STR = 'Invalid input detected|Incomplete command.'

    def __init__(self, connection_manager, logger):
        CiscoIOS.__init__(self, connection_manager, logger)
        self._logger = logger.getChild('CellRouter')
        self._prompt = CellRouter.DEFAULT_PROMPT
        self._session = None

    def setDefaults(self):
        '''
        resource policy
        clock timezone GMT 0
        ip subnet-zero
        ip cef  - enable Cisco Express Forwarding on the route processor card
        '''

        out = self._sendConfigCommand('scheduler allocate 20000 1000')
        out += self._sendConfigCommand('resource policy')
        out += self._sendConfigCommand('clock timezone GMT 0')
        out += self._sendConfigCommand('ip subnet-zero')
        out += self._sendConfigCommand('ip cef')

        return 'Configure Defaults - completed successfully.'

    def setConnectionProperty(self, file_name):
        if self._getSessionHandler().__class__.__name__  == 'FileManager':
            self._getSessionHandler().setFilename(file_name)
        return ''

    def configureHostName(self, sys_id):
        out = self._sendConfigCommand('hostname {0}'.format(sys_id))
        return "Configure HostName '{0}' - completed successfully.".format(sys_id)

    def configureServices(self):
        self._sendConfigCommand('service tcp-keepalives-in')
        self._sendConfigCommand('service tcp-keepalives-out')
        self._sendConfigCommand('service timestamps debug datetime msec localtime show-timezone')
        self._sendConfigCommand('service timestamps log datetime msec localtime show-timezone')
        self._sendConfigCommand('service password-encryption')

        return 'Service configuration - completed successfully.'

    def enableService(self, service_name, args=''):
        out = self._sendConfigCommand('service {0} {1}'.format(service_name, args))
        #res = re.search(CellRouter.ERR_STR, out)
        #if res:
        #    return out
        return "Service '{0}' configuration - completed successfully.".format(service_name)

    def setLoggingBuffered(self, buffer_size):
        out = self._sendConfigCommand('logging buffered {} informational'.format(buffer_size))
        #res = re.search(CellRouter.ERR_STR, out)
        #if res:
        #    return out
        return 'Set Logging Buffered - completed successfully.'

    def enableSecret(self, password):
        out = self._sendConfigCommand('enable secret {0}'.format(password))
        #res = re.search(CellRouter.ERR_STR, out)
        #if res:
        #    return out
        return 'Enable Secret - completed successfully.'

    def setIpDomain(self, domain):
        '''To define a default domain name that the Cisco IOS software uses to complete unqualified hostnames (names without a dotted-decimal domain name),
        use the ip domain name command in global configuration mode. To disable use of the Domain Name System (DNS),
        use the noform of this command.
        ip domain name [ vrf vrf-name ] name
        no ip domain name [ vrf vrf-name ] name
        :param domain:
        :return:
        '''

        out = self._sendConfigCommand('ip domain name {}'.format(domain))
        return "Set Ip Domain for '{0}' - completed successfully.".format(domain)

    def setIpHost(self, hostname, port):

        self._sendConfigCommand('ip host {0} {1} {2}'.format(hostname, port, self.DEFAULT_GW_IP))
        return "Set Ip Host for '{0}' - completed successfully.".format(hostname)

    def setBootP(self, mode='disable'):

        modeStr = ''

        if not mode.upper() == 'ENABLE':
            modeStr += 'no '
        out = self._sendConfigCommand('{0}ip bootp server'.format(modeStr))
        #res = re.search(CellRouter.ERR_STR, out)
        #if res:
        #    return out
        return "BootP configuration mode '{0}' - completed successfully.".format(mode.upper())

    def setIpDomainName(self, domain_name):
        '''Configure default domain name

        :param domain_name:
        :return:
        '''

        self._sendConfigCommand('ip domain name {0}'.format(domain_name))
        return "Set Ip Domain Name for '{0}' - completed successfully.".format(domain_name)

    def setIpDomainLookup(self, mode='disable'):
        '''Enable or Disable ip domain lookup

        :param mode: enable / disable
        :return:
        '''

        modeStr = ''

        if not mode.upper() == 'ENABLE':
            modeStr += 'no'

        out = self._sendConfigCommand('{0} ip domain lookup'.format(modeStr))

        return 'Set Ip Domain Lookup mode \'{0}\' - completed successfully'.format(mode.upper())

    def enableSSH(self, user, password, privilege='15'):
        '''Enable SSH Version 2
        enable
        configure terminal
        ip ssh rsa keypair-name keypair-name
        ip ssh [time-out seconds | authentication-retries integer]
        ip ssh version 2
        :return:
        '''

        out = self._sendConfigCommand('ip ssh version 2')
        time.sleep(0.5)
        out += self._sendConfigCommand('')
        out += self._sendConfigCommand('username {0} privilege {1} password {2}'.format(user, privilege, password))

        return 'Enable SSH - completed successfully.'

    def configureInterface(self, iface_name, ip, mask='255.255.255.0', ip_nat='', description=None):
        '''Uses interface configuration mode to set interface parameters,
        method will set default attributes for non Loopback interfaces

        :param iface_name: name of interface to configure [Loopback0/FastEthernet0/0/etc.]
        :param ip: ip address to set on interface
        :param mask: subnet mask for the interface
        :param description: description for the interface
        :return:
        '''

        int_type = 'LOOPBACK'
        int_num = None

        res = re.search('(.*)([\d\/]+)', iface_name)
        if res:
            int_type = res.group(1).upper()
            int_num = res.group(2)

        self._getLogger().info('---------------------------------------------------------------')
        self._getLogger().info('Enter interface \'{0}\'configuration mode:'.format(iface_name))
        out = self._sendConfigCommand('interface {0}'.format(iface_name))
        res = re.search(CellRouter.ERR_STR, out)
        if res:
            err_msg = 'Failed to enter interface \'{0}\' configuration mode'.format(iface_name)
            self._getLogger().error(err_msg)
            return err_msg

        ##------------------------ set specifics ----------------------------
        if description:
            out = self._sendConfigCommand('description {0}'.format(description))
        out += self._sendConfigCommand('ip address {0} {1}'.format(ip, mask))

        if not ip_nat == '':
            if not re.search('INSIDE|OUTSIDE', ip_nat.upper()):
                raise ('configureInterface ', 'Invalid value provided for ipNat parameter, use [inside|outside]')
            else:
                out += self._sendConfigCommand('ip nat {0}'.format(ip_nat.lower()))

        out += self._sendConfigCommand('ip virtual-reassembly')
        #------------------------ set defaults ----------------------------
        if not int_type == 'LOOPBACK':
            out += self._sendConfigCommand('no ip redirects')
            out += self._sendConfigCommand('no ip unreachables')
            out += self._sendConfigCommand('no ip proxy-arp')
            out += self._sendConfigCommand('duplex auto')
            out += self._sendConfigCommand('speed auto')
            out += self._sendConfigCommand('no shutdown')

        #out += self.exitConfigurationMode()
        self._getLogger().info('Configuration completed.')
        self._getLogger().info('---------------------------------------------------------------')
        return '{0}: Interface configuration - completed successfully.'.format(iface_name)

    def configureStaticRoute(self, dest_address, dest_mask, gw_ip_address, interface, dhcp=None, distance=None,
                             name=None, permanent=None, track_number=None, tag=None, mode='enable'):

        """To establish static routes, use the ip route command in global configuration mode. To remove static routes, use the no form of this command.
        ip route prefix mask {ip-address | interface-type interface-number [ip-address]} [dhcp] [distance] [name next-hop-name] [permanent | track number] [tag tag]
        no ip route prefix mask {ip-address | interface-type interface-number [ip-address]} [dhcp] [distance] [name next-hop-name] [permanent | track number] [tag tag]

        :param dest_address:    IP route prefix for the destination.
        :param dest_mask:       Prefix mask for the destination.
        :param gw_ip_address:   IP address of the next hop that can be used to reach that network.
        :param interface:       Network interface type and interface number.
        :param dhcp:(Optional) Enables a Dynamic Host Configuration Protocol (DHCP) server to assign a static route to a default gateway (option 3).
                Note Specify the dhcp keyword for each routing protocol.
        :param distance:(Optional) An administrative distance. The default administrative distance for a static route is 1.
                name next-hop-name
        :param name:    (Optional) Associates a name with the next hop.
        :param permanent: (Optional) Specifies that the route will not be removed, even if the interface shuts down.
        :param track_number: (Optional) Associates a track object with this route. Valid values for the number argument range from 1 to 500.
        :param tag: (Optional) Tag value that can be used as a "match" value for controlling redistribution via route maps.
        :param mode: 'enable' - default, for 'disable' mode 'no comand' will be issued
        :return:
        """

        if len(dest_address) == 0:
            status_msg = 'No destination provided for configuration. Static route will not be configured.'
            self._getLogger().info(status_msg)
            raise ('configureStaticRoute', status_msg)

        cmd = 'ip route {0} {1} {2} {3}'.format(dest_address, dest_mask, gw_ip_address, interface)

        if mode.upper() == 'DISABLE':
            cmd = 'no {0}'.format(cmd)

        if dhcp:
            cmd += ' {0}'.format(dhcp)

        if distance:
            cmd += ' {0}'.format(distance)

        if name:
            cmd += ' {0}'.format(name)

        if permanent:
            cmd += ' permanent'
        elif track_number:
            cmd += ' track {0}'.format(track_number)

        if tag:
            cmd += ' tag{0}'.format(tag)

        out = self._sendConfigCommand(cmd)
        return 'Static router configuration - completed successfully for {0} {1}'.format(dest_address, dest_mask)

    def generateRSA(self, type='general-keys', key_label=None, exportable=None, modulus_size=None,
                    storage_device_name=None, redundancy=None, device_name=None):
        '''
        crypto key generate rsa [ general-keys | usage-keys | signature | encryption ] [ label key-label ]
        [exportable] [ modulus modulus-size ] [ storage devicename : ] [redundancy] [ on devicename : ]

        :param type: (Optional) [ general-keys | usage-keys | signature | encryption ] specify generated key type
        :param key_label: (Optional) Specifies the name that is used for an RSA key pair when they are being exported.
        :param exportable: (Optional) Specifies that the RSA key pair can be exported to another Cisco device, such as a router.
        :param modulus_size: (Optional) Specifies the IP size of the key modulus.
        :param storage_device_name: (Optional) Specifies the key storage location.
        :param redundancy: (Optional) Specifies that the key should be synchronized to the standby CA.
        :param device_name: (Optional) Specifies that the RSA key pair will be created on the specified device
        :return:
        '''

        cmd = 'crypto key generate rsa {0} '.format(type)
        if key_label:
            cmd += ' label {0}'.format(key_label)

        if exportable:
            cmd += ' exportable'

        if modulus_size:
            cmd += ' modulus {0}'.format(modulus_size)

        if storage_device_name:
            cmd += ' storage {0}'.format(storage_device_name)

        if redundancy:
            cmd += ' redundancy'

        if device_name:
            cmd += ' on {0}'.format(device_name)

        cmd = re.sub(' +', ' ', cmd)

        self._sendConfigCommand(cmd)
        return 'Generate RSA - completed successfully.'

    def configureIpAccessList(self, acl_name, action, protocol='ip', src_network_address=None, src_wcard=None,
                              dest_network_addr=None, dest_wcard=None, acl_type='standard'):
        """Configure IP Access list
        access-list access-list-number
        [dynamic dynamic-name [timeout minutes]]
        {deny|permit} protocol source source-wildcard
        destination destination-wildcard [precedence precedence]
        [tos tos] [log|log-input] [time-range time-range-name]

        :param acl_name: name for access list
        :param action: [permit|deny]
        :param src_network_address: source network address [ANY|a.b.c.d|host|object_group]
        :param src_wcard: source wild card mask
        :param dest_network_addr: destination network address [ANY|a.b.c.d|host|object_group]
        :param dest_wcard: destination wild card mask
        :param protocol: protocol for access list [tcp, udp, ospf, icmp, etc.]
        :param acl_type: [extended, log-update, logging, resequence, standard]
        :return: 1 if configured
        """

        cmd = '{0} {1}'.format(action, protocol)
        if src_network_address is None and src_wcard is None or src_network_address.upper() == 'ANY':
            cmd += ' any'
        elif src_wcard is None:
            cmd += 'host {0}'.format(src_network_address)
        else:
            cmd += ' {0} {1}'.format(src_network_address, src_wcard)

        if dest_network_addr is None and dest_wcard is None or dest_network_addr.upper() == 'ANY':
            cmd += ' any'

        elif dest_wcard is None:
            cmd += 'host {0}'.format(dest_network_addr)
        else:
            cmd += ' {0} {1}'.format(dest_network_addr, dest_wcard)

        #
        out = self._sendConfigCommand('ip access-list {0} {1}'.format(acl_type, acl_name))
        out += self._sendConfigCommand(cmd)

        return "Configure Ip Access List '{0}' - completed successfully.".format(acl_name)

    def configureNatOnInterface(self, interface_name, acl_name, mode='source', direction='outside'):
        '''Configure access list for dynamic NAT , assign it to specified interface

        :param access_list: access-list-number | access-list-name
        :param interface_name: interface type number
        :return:
        '''

        #enable NAT on interface
        out = ''
        out += self._sendConfigCommand('ip nat {0} list {1} interface {2}'.format(mode, acl_name, interface_name))

        return 'Configure Nat {0} on {1} - completed successfully.'.format(direction, interface_name)

    def configureStaticNAT(self, direction, mode, protocol, local_address, global_address, local_port='', global_port=''):
        '''Enable NAT of the inside source address.
        ip nat inside source static [ tcp | udp ] <localaddr> <localport> <globaladdr> <globalport>

        :param direction: rule direction [ inside | outside ]
        :param mode: destination - Enables NAT of the inside destination address.
                     source - Enables NAT of the inside source address.
        :param protocol: [tcp | udp]
        :param local_address:
        :param local_port:
        :param global_address:
        :param global_port:
        :return:
        '''
        #- init default -------
        if direction == '':
            direction = 'inside'

        if mode == '':
            mode = 'source'

        if protocol == '':
            protocol = 'ip'

        return self._sendConfigCommand('{0} nat {1} {2} static {3} {4} {5} {6}'.format(protocol, direction,
                                                       mode, local_address, local_port, global_address, global_port))

    def configureLine(self, line, start_index, end_index='', exec_timeout_mins='', exec_timeout_secs='',
                      privilege_level='', password='', no_exec='', logging='', transport_input='',
                      transport_output='', stopbits=''):
        '''Enter line configuration collection mode

        :param line:  line-name  [aux, con, vty, tty]
        :param start_index: relative number of the terminal line
        :param end_index: relative number of the last line in a contiguous group
        :param commands: one string or list of commands to be set as line configuration
        :return:
        '''

        commands = []
        line_config_output = ''

        if exec_timeout_mins:
            cmd_str = 'exec-timeout {0} '.format(exec_timeout_mins)
            if exec_timeout_secs:
                cmd_str += exec_timeout_secs
            commands.append(cmd_str)

        if no_exec:
            commands.append('no exec')

        if privilege_level:
            commands.append('privilege level {0}'.format(privilege_level))

        if logging:
            commands.append('logging synchronous')

        if password:
            commands.append('password {0}'.format(password))
            commands.append('login local')

        if transport_input:
            commands.append('transport input {0}'.format(transport_input))

        if transport_output:
            commands.append('transport output {0}'.format(transport_output))

        if stopbits:
            commands.append('stopbits {0}'.format(stopbits))

        if len(commands) == 0:
            self._getLogger().info('No parameters provided for configuration. Exit.')
            return 'No parameters provided for configuration.'

        output = self._sendConfigCommand('line {0} {1} {2}'.format(line, start_index, end_index))
        res = re.search('(No physical hardware support for line .*)', output)
        if res:
            self._getLogger().warning('Device returned error message.')
            self._getLogger().warning(res.group(1))
            return 'Device returned error message: {0}'.format(res.group(1))

        res = re.search(CellRouter.ERR_STR, output)
        if res:
            self._getLogger().error('Failed to send configuration command to device.')
            return 'Device returned error message: {0}'.format(res.group(1))
        line_config_output += output
#
        for cmd in commands:
            out = self._sendConfigCommand(cmd)
            res = re.search(CellRouter.ERR_STR, output)
            if res:
                errMsg = 'Failed to send command to device.\n\'cmd:{0}\''.format(cmd)
                self._getLogger().error(errMsg)
                return errMsg

            line_config_output+=out

        ##exit from line configuration mode if we're in it
        #if re.search('config-line', out):
        #    self.exitConfigurationMode()

        status_msg = line_config_output
        status_msg += '\n----- Line {0} {1} {2} configuration - completed successfully. ----'.format(line,
                                                                                    start_index, end_index)

        return 'Configure Line {0} {1} {2} - completed successfully.'.format(line, start_index, end_index)

    def configureBootSettings(self):
        out = self._sendConfigCommand('boot-start-marker')
        out += self._sendConfigCommand('boot-end-marker')

        return 'Configure Boot Settings - completed successfully.'

    def configureAAA(self, mode='DISABLE'):
        out = ''
        if not mode.upper() == 'ENABLE':
            out += self._sendConfigCommand('no aaa new-model')
        else:
            #configure AAA Access Control Security
            #TBD
            pass

        return "Configure AAA mode '{0}' - completed successfully.".format(mode.upper())

    def configureVoiceCard(self, card_index, dfsfarm=None):
        commands = []
        out = ''

        if not dfsfarm is None:
            if re.search('NO|FALSE|DISABLE', dfsfarm.upper()):
                commands.append('no dfsfarm')

        if len(commands) == 0:
            info_msg = 'No parameters to configure for voice card.'
            self._getLogger().info(info_msg )
            return info_msg

        ret_msg = 'Configure Voice Card index {0} - completed successfully.'.format(card_index)
        voice_card_index_str = 'voice-card {0}'.format(card_index)

        out += self._sendConfigCommand(voice_card_index_str)
        for cmd in commands:
            out += self._sendConfigCommand(cmd)

        if re.search(self.ERR_STR, out):
            ret_msg = "Voice card configuration failed. Check if device supports '{0}'.".format(voice_card_index_str)

        return ret_msg

    def saveActiveConfig(self):
        out = self._sendCommand('copy running-config startup-config', expected_str='Destination')
        out += self._sendCommand(' ', 'copied')
        out += self._sendCommand(' ')
        return 'Configuration saved.'

    def resetConfig(self):
        out = self._sendCommand('copy startup-config running-config', expected_str='Destination')
        out += self._sendCommand(' ', 'copied')
        out += self._sendCommand(' ')

        return 'Reset configuration - completed successfully.'

    def showRun(self):
        return self._sendCommand('show running')

    def setAutoReload(self, reload_minutes):
        out = self._sendCommand('reload in {0}'.format(reload_minutes), 'commit')
        out += self._sendCommand(' ')
        return out


if __name__ == '__main__':
    import sys
    import json
    from qualipy.common.cisco.cisco_handler_factory import CiscoHandlerFactory
    data_json = """{
    "resource" : {
            "ResourceAddress": "10.11.2.101",
            "User": "admin",
            "Password": "@Vantage123"
        }
    }"""
    json_dict = json.loads(data_json)
    host = json_dict['resource']['ResourceAddress']
    username = json_dict['resource']['User']
    password = json_dict['resource']['Password']
#
#
    handler = CiscoHandlerFactory.createHandler('CELLROUTER', host, username, password)
    handler.enterConfigurationMode()

    handler.configureInterface( 'Loopback0', '10.10.10.1', '255.255.255.255')
    handler.configureInterface( 'GigabitEthernet0/0', '9.9.9.9', '255.255.255.255', 'Some description')
    handler.configureIpAccessList(acl_name='InternetPAT', action='permit', protocol='ip', src_network_address='10.0.0.0', src_wcard='0.0.0.255',
                           acl_type='extended')
#
    handler.configureNatOnInterface('GigabitEthernet0/0', 'InternetPAT')