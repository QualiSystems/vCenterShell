from qualipy.common.cisco.cisco_nxos import *

class CiscoNXOS3048(CiscoNxOS):
    def __init__(self, ssh_handler, logger=None):
        CiscoNxOS.__init__(self, ssh_handler, logger)


