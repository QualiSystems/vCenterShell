import sys, json, collections

sys.path.append('../../')
# from qualipy.common.cisco.cisco_nxos import CiscoNxOS
from qualipy.common.libs.driver_builder_wrapper import DriverFunction
from qualipy.common.libs.driver_builder_wrapper import base_resource_driver
from qualipy.common.cisco.cisco_handler_factory import CiscoHandlerFactory


class CiscoNXOS3048ResourceDriver(base_resource_driver):
    def Init(self, data_json):

        # self._nxos3048_handler = CiscoHandlerFactory.createHandler('nxos_3048', '', '', '', 'file')
        _json = json.loads(data_json)
        if ('Filename' in _json['resource'] and _json['resource']['Filename']):
            host = _json['resource']['ResourceAddress']
            username = _json['resource']['User']
            password = _json['resource']['Password']
            filename = _json['resource']['Filename']
            output = _json['resource']['Output']
            self._nxos3048_handler = CiscoHandlerFactory.createHandler('nxos_3048', host, username, password, 'file', filename=filename)
            # self._nxos3048_handler._session_handler.setFilename(filename)
        else:
            host = _json['resource']['ResourceAddress'].encode('ascii', errors='backslashreplace')
            username = _json['resource']['User'].encode('ascii', errors='backslashreplace')
            password = _json['resource']['Password'].encode('ascii', errors='backslashreplace')
            console_server_ip = _json['resource']['ConsoleServerIpAddress'].encode('ascii', errors='backslashreplace')
            console_server_user = _json['resource']['ConsoleUser'].encode('ascii', errors='backslashreplace')
            console_server_password = _json['resource']['ConsolePassword'].encode('ascii', errors='backslashreplace')
            console_port = _json['resource']['ConsolePort'].encode('ascii', errors='backslashreplace')

            # self._nxos3048_handler = CiscoHandlerFactory.createHandler('NXOS_3048', host, username, password, 'console')
            # self._nxos3048_handler.setConsoleCredentials(console_server_ip, console_server_user, console_server_password , console_port)
            self._nxos3048_handler = CiscoHandlerFactory.createHandler('NXOS_3048', host, username, password, 'console',
                                                                       console_server_ip=console_server_ip,
                                                                       console_server_user=console_server_user,
                                                                       console_server_password=console_server_password,
                                                                       console_port=console_port,
                                                                       )
            self._nxos3048_handler.connect()

    @DriverFunction
    def EnableFeature(self, matrixJSON, featureName):
        return self._nxos3048_handler.feature(featureName)

    @DriverFunction
    def CreateRole(self, matrixJSON, param):
        return self._nxos3048_handler.role(param)

    @DriverFunction
    def ConfigureSSH(self, matrixJSON, mode):
        return self._nxos3048_handler.configureSSH(mode)

    @DriverFunction
    def ConfigureTelnet(self, matrixJSON, mode):
        return self._nxos3048_handler.configureTelnet(mode)

    @DriverFunction
    def ConfigureCFS(self, matrixJSON, mode):
        return self._nxos3048_handler.configureCFS(mode)

    @DriverFunction
    def ConfigureLacp(self, matrixJSON, mode):
        return self._nxos3048_handler.configureLacp(mode)

    @DriverFunction
    def ConfigureVPC(self, matrixJSON, mode):
        return self._nxos3048_handler.configureVpc(mode)

    @DriverFunction
    def ConfigureInterfaceVlan(self, matrixJSON, mode):
        return self._nxos3048_handler.configureInterfaceVlan(mode)

    @DriverFunction
    def ConfigureHsrp(self, matrixJSON, mode):
        return self._nxos3048_handler.configureHsrp(mode)

    @DriverFunction
    def ConfigureSNMPService(self, matrixJSON, snmp_server_host, snmp_server_community, udp_port,
                             community_group, snmp_server_version, set_enable_traps):
        params_map = {}
        if len(snmp_server_host) and len(udp_port) and len(snmp_server_version) > 0:
            params_map['snmp server host custom port'] = [snmp_server_host, snmp_server_version, udp_port]
        # example: ['127.0.0.1','2c',162]
        elif len(snmp_server_host) > 0 and snmp_server_version:
            params_map['snmp server host'] = [snmp_server_host, snmp_server_version]
        # example: ['127.0.0.1','2c']
        if len(snmp_server_community) and len(community_group) > 0:
            params_map['snmp server community'] = [snmp_server_community, community_group]
        # example: ['test','network operator']
        if set_enable_traps.lower() == 'yes':
            params_map['enable traps'] = []
            # example: ['yes']
        return self._nxos3048_handler.configureSnmpServer(**params_map)

    @DriverFunction
    def ConfigureNtpService(self, matrixJSON, ntpServer):
        if len(ntpServer) > 0:
            return self._nxos3048_handler.configureNtpServer(ntpServer)
        return 'Error, Ntp Server configuration is empty'

    @DriverFunction
    def ConfigureDefaultRole(self, matrixJSON):
        return self._nxos3048_handler.configureDefaultRole()

    @DriverFunction
    def AddUser(self, matrixJSON, username, password, role):
        return self._nxos3048_handler.addUser(username, password, role)

    @DriverFunction
    def AddBanner(self, matrixJSON, text):
        return self._nxos3048_handler.addBanner(text)

    @DriverFunction
    def ConfigureIpDomainLookup(self, matrixJSON, mode):
        return self._nxos3048_handler.configureIpDomainLookup(mode)

    @DriverFunction
    def SetHostName(self, matrixJSON, hostname):
        return self._nxos3048_handler.setHostName(hostname)

    @DriverFunction
    def ConfigureSpanningTreePortTypeEdge(self, matrixJSON, type, mode, action):
        return self._nxos3048_handler.configureSpanningTreePortType(type, mode, action)

    @DriverFunction
    def AddSpanningTreeVlan(self, matrixJSON, range, priority):
        return self._nxos3048_handler.addSpanningTreeVlan(range, priority)

    @DriverFunction
    def AddVpcDomain(self, matrixJSON, id, ip, vrf, system_priority, role_priority, set_auto_recovery='no',
                     set_peer_switch='no'):
        params_map = collections.OrderedDict({})
        if len(id) > 0:
            params_map['vpc domain'] = [id]
        if len(ip) > 0 and len(vrf) > 0:
            params_map['peer keep alive vrf'] = [ip, vrf]
        if len(system_priority) > 0:
            params_map['system priority'] = [system_priority]
        if len(role_priority) > 0:
            params_map['role priority'] = [role_priority]
        if set_auto_recovery.lower() == 'yes':
            params_map['auto recovery'] = []
        if set_peer_switch.lower() == 'yes':
            params_map['peer switch'] = []
        return self._nxos3048_handler.addVpcDomain(params_map)

    @DriverFunction
    def ConfigureInterfaceVlan(self, matrixJSON, interface_name, ip_address, ip_address_mask, hsrp, authentication,
                               priority, track, track_decrement,
                               ip, set_no_shut='no', set_preempt='no'):
        params_map = {}
        # example: ['vlan', '1']
        configure_interface = ['vlan']

        if len(interface_name) > 0:
            configure_interface.append(interface_name)
            params_map['configure_interface'] = configure_interface

        # example: ['10.0.0.1', '255.255.255.0']
        if len(ip_address) > 0 and len(ip_address_mask) > 0:
            params_map['ip_address'] = [ip_address, ip_address_mask]
        # example: ['111']
        if len(hsrp) > 0:
            params_map['hsrp'] = [hsrp]
        # example: ['test']
        if len(authentication) > 0:
            params_map['authentication'] = [authentication]
        # example: ['10']
        if len(priority) > 0:
            params_map['priority'] = [priority]
        # example: ['1', '20']
        if len(track) > 0 and len(track_decrement) > 0:
            params_map['track'] = [track, track_decrement]
        # example: ['127.0.0.ww']
        if len(ip) > 0:
            params_map['ip'] = [ip]

        if set_preempt.lower() == 'yes':
            params_map['preempt'] = []
        if set_no_shut.lower() == 'yes':
            params_map['no_shut'] = []

        return self._nxos3048_handler.configureInterfaceVlan(**params_map)

    @DriverFunction
    def ConfigureInterfacePortChannel(self, matrixJSON, interface_name, description, switchport_mode, vpc,
                                      allow_trunk_vlan, spanning_tree_type, spanning_tree_name, speed,
                                      untagged_type, untagged_name):
        params_map = {}
        # example: ['port-channel', '1']
        configure_interface = ['port-channel']
        if len(interface_name) > 0:
            configure_interface.append(interface_name)
            params_map['configure_interface'] = configure_interface
        # example: ['To Customer Management Switch A].
        if len(description) > 0:
            params_map['description'] = [description]
        # example: ['trunk']
        if len(switchport_mode) > 0:
            params_map['switchport_mode'] = [switchport_mode]
        # example: ['5']
        if len(vpc) > 0:
            params_map['vpc'] = [vpc]
        # example: ['1']
        if len(allow_trunk_vlan) > 0:
            params_map['allow_trunk_vlan'] = [allow_trunk_vlan]
        # example: ['port type', 'edge trunk']
        if len(spanning_tree_type) > 0 and len(spanning_tree_name) > 0:
            params_map['spanning_tree'] = [spanning_tree_type, spanning_tree_name]
        # example: ['111']
        if len(speed) > 0:
            params_map['speed'] = [speed]
        # example: ['cos', '2']
        if len(untagged_type) > 0 and len(untagged_name) > 0:
            params_map['untagged'] = [untagged_type, untagged_name]

        return self._nxos3048_handler.configureInterfacePortChannel(**params_map)

    @DriverFunction
    def ConfigureInterfaceEthernet(self, matrixJSON, interface_name, description, ip_address, ip_address_mask,
                                   trunk_allow_vlan,
                                   channel_group_mode, channel_group_mode_state, spanning_tree_type,
                                   spanning_tree_type_name,
                                   set_switchport_mode_trunk='no', set_mode_trunk='no',
                                   set_no_switchport='no', set_no_shut='no'):
        params_map = {}
        # example: ['ethernet', '1/24']
        configure_interface = ['ethernet']

        if len(interface_name) > 0:
            configure_interface.append(interface_name)
            params_map['configure_interface'] = interface_name
        # example: ['To Customer Management Switch A].
        if len(description) > 0:
            params_map['description'] = [description]
        # example: ['10.0.0.1', '255.255.255.0']
        if len(ip_address) > 0 and len(ip_address_mask) > 0:
            params_map['ip_address'] = [ip_address, ip_address_mask]
        # example: ['1']
        if len(trunk_allow_vlan) > 0:
            params_map['trunk_allow_vlan'] = [trunk_allow_vlan]
        # example: ['10', 'active']
        if len(channel_group_mode) > 0 and len(channel_group_mode_state) > 0:
            params_map['channel_group_mode'] = [channel_group_mode, channel_group_mode_state]
        # example: ['port', 'network']
        if len(spanning_tree_type) > 0 and len(spanning_tree_type_name) > 0:
            params_map['spanning_tree_type'] = [spanning_tree_type, spanning_tree_type_name]

        if set_switchport_mode_trunk.lower() == 'yes':
            params_map['switchport_mode_trunk'] = []

        if set_no_shut.lower() == 'yes':
            params_map['no_shut'] = []

        if set_mode_trunk.lower() == 'yes':
            params_map['mode_trunk'] = []

        if set_no_switchport.lower() == 'yes':
            params_map['no_switchport'] = []

        return self._nxos3048_handler.configureInterfaceEthernet(**params_map)

    @DriverFunction
    def ConfigureInterfaceMgmt(self, matrixJSON, interface_name, description, vrf_member, ip_address, ip_address_mask,
                               set_no_shut='no'):
        params_map = {}
        # example: ['mgmt', '2']
        configure_interface = ['mgmt']

        if len(interface_name) > 0:
            configure_interface.append(interface_name)
            params_map['configure_interface'] = configure_interface
        # example: ['To Customer Management Switch A].
        if len(description) > 0:
            params_map['description'] = [description]
        # example: ['management']
        if len(vrf_member) > 0:
            params_map['vrf_member'] = [vrf_member]
        # example: ['10.1.1.1', '255.255.255.252']
        if len(ip_address) > 0 and len(ip_address_mask) > 0:
            params_map['ip_address'] = [ip_address, ip_address_mask]

        if set_no_shut.lower() == 'yes':
            params_map['no_shut'] = []

        return self._nxos3048_handler.configureInterfaceEthernet(**params_map)

    @DriverFunction
    def ConfigureQosClass(self, matrixJSON, type, name, match_type, match_name):
        class_map_list = [{}]
        class_map = class_map_list[0]

        if len(type) > 0:
            class_map['type'] = type

        if len(name) > 0:
            class_map['name'] = name

        if len(match_type) > 0 and len(match_name) > 0:
            class_map['method'] = 'match'
            class_map['method_params'] = {}
            class_map['method_params']['name'] = match_type
            class_map['method_params']['value'] = match_name

        return self._nxos3048_handler.configureQos(class_map=class_map_list)

    @DriverFunction
    def ClockTimezone(self, matrixJSON, timezone, offset_hours, offset_minutes):
        self._nxos3048_handler.clockTimezone(timezone, offset_hours, offset_minutes)

    @DriverFunction
    def DisableLogging(self, matrixJSON, target):
        self._nxos3048_handler.disableLogging(target)

    @DriverFunction
    def ConfigureLogging(self, matrixJSON, target):
        self._nxos3048_handler.configureLogging(target)

    @DriverFunction
    def ConfigureQosPolicy(self, matrixJSON, type, name, class_type, class_name, class_set_type, class_set_name,
                           bandwidth_type, bandwidth_name):
        policy_map_list = [{}]
        policy_map = policy_map_list[0]

        if len(type) > 0:
            policy_map['type'] = type

        if len(name) > 0:
            policy_map['name'] = name

        if len(class_name) > 0 or len(class_type) > 0:
            policy_map['method_params'] = {}

        if len(class_name) > 0 and len(class_type) == 0:
            policy_map['method'] = 'class'
            policy_map['method_params']['name'] = class_name

            if len(class_set_type) > 0 and len(class_set_name) > 0:
                policy_map['method_params']['method'] = 'set'
                set_params_map = policy_map['method_params']['method_params'] = {}
                set_params_map['name'] = class_set_type
                set_params_map['value'] = class_set_name

        if len(class_type) > 0 and len(class_name) > 0:
            policy_map['method'] = 'class_type'
            policy_map['method_params']['type'] = class_type
            policy_map['method_params']['name'] = class_name

            if len(bandwidth_type) > 0 and len(bandwidth_name) > 0:
                policy_map['method_params']['method'] = 'bandwidth'
                bandwidth_params_map = policy_map['method_params']['method_params'] = {}
                bandwidth_params_map['name'] = bandwidth_type
                bandwidth_params_map['value'] = bandwidth_name

        return self._nxos3048_handler.configureQos(policy_map=policy_map_list)

    @DriverFunction
    def ConfigureQosServicePolicy(self, matrixJSON, name, service_policy_type, service_policy_name,
                                  service_policy_direction=' '):
        service_policy = {}

        if len(name) > 0:
            service_policy['name'] = name

        service_policy['services'] = [{}]
        services = service_policy['services'][0]
        if len(service_policy_type) > 0 and len(service_policy_name) > 0:
            services['type'] = service_policy_type
            services['value'] = service_policy_name

        if len(service_policy_direction) > 0:
            services['direction'] = service_policy_direction

        return self._nxos3048_handler.configureQos(service_policy=service_policy)


if __name__ == '__main__':
    test = CiscoNXOS3048ResourceDriver(224332, '{"resource":{}}')
    test.ConfigureQosServicePolicy('{"resource":{}}', 'qos', 'qos', 'system_qos_policy', 'input')
