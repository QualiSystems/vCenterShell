
import unittest
import sys
sys.path.append('../../')
from common.libs.ssh_manager import SSHManager
#from teamcity import is_running_under_teamcity
#from teamcity.unittestpy import TeamcityTestRunner
from networking.cisco.cisco_nxos_3048_resource_driver import CiscoNXOS3048ResourceDriver

class NXOS3048Test(unittest.TestCase):
    def setUp(self):
        data_json = """{
            "resource" : {
                    "ResourceAddress": "172.29.128.25",
                    "User": "admin",
                    "Password": "cisco"
                }
        }"""
        self._nxos3048_handler = CiscoNXOS3048ResourceDriver(data_json)

    def tearDown(self):
        #self._ssh.disconnect()
        pass
        
    def testConfigureInterfaceVlan(self):
        try:
            self._nxos3048_handler.configureInterfaceVlan("10","192.168.10.10", "255.255.255.0", "101", "105", "Vce12345", "51", "20", "mgmt ip")
        except:
            self.fail("Exception is raised unexpectedly!")

    def testInterfacePortChannel(self):
        self._nxos3048_handler.interfacePortChannel("5", 'To Customer Management Switch A', "5", "45", 'normal')
        self._nxos3048_handler.interfacePortChannel("6", 'To Customer Management Switch B', "6", "46", 'normal')

    def testInterfaceEthernet(self):
        self._nxos3048_handler.interfaceEthernet('1/49', '3048-B 1/49', "149", '', "10")

    def testInterfaceMgmt(self):
        self._nxos3048_handler.interfaceMgmt("0", 'vPC peer keepalive link to 3048-B mgmt0', "10.1.1.1", "255.255.255.252")

    def testConfigureLine(self):
        self._nxos3048_handler.configureLine(5,5)

if (__name__ == '__main__'):
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass