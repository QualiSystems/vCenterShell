__author__ = 'pava'

import json

from qualipy.common.libs.driver_builder_wrapper import DriverFunction
from qualipy.common.libs.driver_builder_wrapper import base_resource_driver
from qualipy.common.cisco.cisco_handler_factory import CiscoHandlerFactory

class CiscoNXOS55xxResourceDriver(base_resource_driver):
    def Init(self, data_json):
        _json = json.loads(data_json)
        if _json['resource']['Filename']:
            host = _json['resource']['ResourceAddress']
            username = _json['resource']['User']
            password = _json['resource']['Password']
            output = _json['resource']['Output']

            self._nxos_55xx_handler = CiscoHandlerFactory.createHandler('nxos_55xx', host, username, password, 'file')
            
            filename = _json['resource']['Filename']
            self._nxos_55xx_handler._session_handler.setFilename(filename)
        else:
            host = _json['resource']['ResourceAddress'].encode('ascii', errors='backslashreplace')
            username = _json['resource']['User'].encode('ascii', errors='backslashreplace')
            password = _json['resource']['Password'].encode('ascii', errors='backslashreplace')
            console_server_ip = _json['resource']['ConsoleServerIpAddress'].encode('ascii', errors='backslashreplace')
            console_server_user = _json['resource']['ConsoleUser'].encode('ascii', errors='backslashreplace')
            console_server_password = _json['resource']['ConsolePassword'].encode('ascii', errors='backslashreplace')
            console_port = _json['resource']['ConsolePort'].encode('ascii', errors='backslashreplace')

            self._nxos_55xx_handler = CiscoHandlerFactory.createHandler('nxos_55xx', host, username, password , 'console',
                                                                       console_server_ip=console_server_ip, console_server_user=console_server_user,
                                                                       console_server_password=console_server_password, console_port=console_port)

    @DriverFunction
    def EnableFeature(self, matrixJSON, featureName):
        return self._nxos_55xx_handler.feature(featureName)

    @DriverFunction
    def CreateRole(self, matrixJSON, param):
        return self._nxos_55xx_handler.role(param)

    @DriverFunction
    def ConfigureSSH(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureSSH(mode)

    @DriverFunction
    def ConfigureTelnet(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureTelnet(mode)

    @DriverFunction
    def ConfigureCFS(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureCFS(mode)

    @DriverFunction
    def ConfigureLacp(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureLacp(mode)

    @DriverFunction
    def ConfigureVPC(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureVpc(mode)

    @DriverFunction
    def ConfigureInterfaceVlan(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureInterfaceVlan(mode)

    @DriverFunction
    def ConfigureHsrp(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureHsrp(mode)

    @DriverFunction
    def ConfigureDefaultRole(self, matrixJSON):
        return self._nxos_55xx_handler.configureDefaultRole()

    @DriverFunction
    def AddUser(self, matrixJSON, username, password, role):
        return self._nxos_55xx_handler.addUser(username,password,role)

    @DriverFunction
    def AddBanner(self, matrixJSON, text):
        return self._nxos_55xx_handler.addBanner(text)

    @DriverFunction
    def ConfigureIpDomainLookup(self, matrixJSON, mode):
        return self._nxos_55xx_handler.configureIpDomainLookup(mode)

    @DriverFunction
    def SetHostName(self, matrixJSON, hostname):
        return self._nxos_55xx_handler.setHostName(hostname)

    @DriverFunction
    def ConfigureSpanningTreePortType(self, matrixJSON, name):
        return self._nxos_55xx_handler.configureSpanningTreePortType(name)

    @DriverFunction
    def SetSpanningTreeVlanPriority(self, matrixJSON, range, priority):
        return self._nxos_55xx_handler.setSpanningTreeVlanPriority(range, priority)

    @DriverFunction
    def AddVpcDomain(self, matrixJSON, id, ip, system_priority, role_priority):
        return self._nxos_55xx_handler.addVPCDomain(id, ip, system_priority, role_priority)

    @DriverFunction
    def ConfigureInterfaceVlan(self, matrixJSON, configure_interface, ip_address, hsrp, authentication, priority, track,
                               ip, set_no_shut='no', set_preempt='no'):
        params_map = {}
        # example: ['vlan', '1']
        if len(configure_interface) > 0:
            params_map['configure_interface'] = configure_interface.split(',')
        # example: ['10.0.0.1', '255.255.255.0']
        if len(ip_address) > 0:
            params_map['ip_address'] = ip_address.split(',')
        # example: ['111']
        if len(hsrp) > 0:
            params_map['hsrp'] = hsrp.split(',')
        # example: ['test']
        if len(authentication) > 0:
            params_map['authentication'] = authentication.split(',')
        # example: ['10']
        if len(priority) > 0:
            params_map['priority'] = priority.split(',')
        # example: ['1', '20']
        if len(track) > 0:
            params_map['track'] = track.split(',')
        # example: ['127.0.0.ww']
        if len(ip) > 0:
            params_map['ip'] = ip.split(',')

        if set_preempt.lower() == 'yes':
            params_map['preempt'] = []
        if set_no_shut.lower() == 'yes':
            params_map['no_shut'] = []

        return self._nxos_55xx_handler.configureInterfaceVlan(**params_map)

    @DriverFunction
    def ConfigureInterfacePortChannel(self, matrixJSON, configure_interface, description, switchport_mode, vpc,
                                      allow_trunk_vlan, spanning_tree, speed, untagged):
        params_map = {}
        # example: ['port-channel', '1']
        if len(configure_interface) > 0:
            params_map['configure_interface'] = configure_interface.split(',')
        # example: ['To Customer Management Switch A].
        if len(description) > 0:
            params_map['description'] = description.split(',')
        # example: ['trunk']
        if len(switchport_mode) > 0:
            params_map['switchport_mode'] = switchport_mode.split(',')
        # example: ['5']
        if len(vpc) > 0:
            params_map['vpc'] = vpc.split(',')
        # example: ['1']
        if len(allow_trunk_vlan) > 0:
            params_map['allow_trunk_vlan'] = allow_trunk_vlan.split(',')
        # example: ['port type', 'edge trunk']
        if len(spanning_tree) > 0:
            params_map['spanning_tree'] = spanning_tree.split(',')
        # example: ['111']
        if len(speed) > 0:
            params_map['speed'] = speed.split(',')
        # example: ['cos', '2']
        if len(untagged) > 0:
            params_map['untagged'] = untagged.split(',')

        return self._nxos_55xx_handler.configureInterfacePortChannel(**params_map)

    @DriverFunction
    def ConfigureInterfaceEthernet(self, matrixJSON, configure_interface, description, ip_address, trunk_allow_vlan,
                                   channel_group_mode, spanning_tree_type, set_switchport_mode_trunk='no', set_mode_trunk='no',
                                   set_no_switchport='no', set_no_shut='no'):
        params_map = {}
        # example: ['ethernet', '1/24']
        if len(configure_interface) > 0:
            params_map['configure_interface'] = configure_interface.split(',')
        # example: ['To Customer Management Switch A].
        if len(description) > 0:
            params_map['description'] = description.split(',')
        # example: ['10.0.0.1', '255.255.255.0']
        if len(ip_address) > 0:
            params_map['ip_address'] = ip_address.split(',')
        # example: ['1']
        if len(trunk_allow_vlan) > 0:
            params_map['trunk_allow_vlan'] = trunk_allow_vlan.split(',')
        # example: ['10', 'active']
        if len(channel_group_mode) > 0:
            params_map['channel_group_mode'] = channel_group_mode.split(',')
        # example: ['port', 'network']
        if len(spanning_tree_type) > 0:
            params_map['spanning_tree_type'] = spanning_tree_type.split(',')

        if set_switchport_mode_trunk.lower() == 'yes':
            params_map['switchport_mode_trunk'] = []

        if set_no_shut.lower() == 'yes':
            params_map['no_shut'] = []

        if set_mode_trunk.lower() == 'yes':
            params_map['mode_trunk'] = []

        if set_no_switchport.lower() == 'yes':
            params_map['no_switchport'] = []

        return self._nxos_55xx_handler.configureInterfaceEthernet(**params_map)

    @DriverFunction
    def ConfigureInterfaceMgmt(self, matrixJSON, configure_interface, description, vrf_member, ip_address,
                               set_no_shut='no'):
        params_map = {}
        # example: ['ethernet', '1/24']
        if len(configure_interface) > 0:
            params_map['configure_interface'] = configure_interface.split(',')
        # example: ['To Customer Management Switch A].
        if len(description) > 0:
            params_map['description'] = description.split(',')
        # example: ['management']
        if len(vrf_member) > 0:
            params_map['vrf_member'] = vrf_member.split(',')
        # example: ['10.1.1.1', '255.255.255.252']
        if len(ip_address) > 0:
            params_map['ip_address'] = ip_address.split(',')

        # example: ['12', '20', '23']
        #if len(clock_timezone) > 0:
        #    params_map['clock_timezone'] = clock_timezone.split(',')

        if set_no_shut.lower() == 'yes':
            params_map['no_shut'] = []

        return self._nxos_55xx_handler.configureInterfaceEthernet(**params_map)

    @DriverFunction
    def ConfigureQos(self, matrixJSON):
        class_map = [
            {
                'type': 'qos',
                'name': 'class-gold',
                'method': 'match',
                'method_params':  {
                    'name': 'cos',
                    'value': '4'
                }
            },
            {
                'type': 'qos',
                'name': 'class-platinum',
                'method': 'match',
                'method_params': {
                    'name': 'cos',
                    'value': '4'
                }
            },
            {
                'type': 'queuing',
                'name': 'class-gold',
                'method': 'match',
                'method_params': {
                    'name': 'cos',
                    'value': '4'
                }
            },
            {
                'type': 'queuing',
                'name': 'class-platinum',
                'method': 'match',
                'method_params': {
                    'name': 'cos',
                    'value': '4'}
            },
            {
                'type': 'network-qos',
                'name': 'class-gold',
                'method': 'match',
                'method_params': {
                    'name': 'qos-group',
                    'value': '3'}
            },
            {
                'type': 'network-qos',
                'name': 'class-platinum',
                'method': 'match',
                'method_params': {
                    'name': 'qos-group',
                    'value': '2'}
            }
        ]

        policy_map = [
            {
                'type': 'qos',
                'name': 'system_qos_policy',
                'method': 'class',
                'method_params': [
                    {
                        'name': 'class-platinum',
                        'method': 'set',
                        'method_params': {
                            'name': 'qos-group',
                            'value': '2'
                        }
                    },
                    {
                        'name': 'class-gold',
                        'method': 'set',
                        'method_params': {
                            'name': 'qos-group',
                            'value': '3'
                        }
                    }
                ]
            },
            {
                'type': 'network-qos',
                'name': 'system_nq_policy',
                'method': 'class',
                'method_params': [
                    {
                        'type': 'network-qos',
                        'name': 'class-default',
                    },
                    {
                        'type': 'network-qos',
                        'name': 'class-platinum',
                    },
                    {
                        'type': 'network-qos',
                        'name': 'class-gold',
                    },
                    {
                        'type': 'network-qos',
                        'name': 'class-fcoe',
                    }
                ]
            },
            {
                'type': 'queuing',
                'name': 'system_q_in_policy',
                'method': 'class_type',
                'method_params': [
                    {
                        'type': 'queuing',
                        'name': 'class-platinum',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '5'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'cclass-gold',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '10'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-fcoe',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '0'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-default',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '85'
                        }
                    }

                ]
            },
            {
                'type': 'queuing',
                'name': 'system_q_out_policy',
                'method': 'class_type',
                'method_params': [
                    {
                        'type': 'queuing',
                        'name': 'class-platinum',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '5'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'cclass-gold',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '10'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-fcoe',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '0'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-default',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '85'
                        }
                    }

                ]
            }
        ]

        service_policy = {
            'name': 'qos',
            'services': [
                {
                    'type': 'qos',
                    'value': 'system_qos_policy',
                },
                {
                    'type': 'queuing',
                    'value': 'system_q_in_policy',
                },
                {
                    'type': 'queuing',
                    'value': 'system_q_out_policy',
                },
                {
                    'type': 'network-qos',
                    'value': 'system_nq_policy',
                }
            ]
        }

        return self._nxos_55xx_handler.configureQos(class_map=class_map, policy_map=policy_map,
                                                   service_policy=service_policy)