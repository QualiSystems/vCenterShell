import sys
sys.path.append("../../")

import re

from common.cisco.cisco_handler_factory import *

host   = '127.0.0.1'
port   = 25
user   = 'ucspe'
passwd = 'ucspe'

data_json = """{
    "resource" : {
        "ResourceAddress": "127.0.0.1",
        "User": "ucspe",
        "Password": "ucspe"
    }
}"""


def shieldString(data_str):
    iter = re.finditer('[\{\}\(\)\[\]\|]', data_str)

    new_data_str = ''
    current_index = 0
    for match in iter:
        match_range = match.span()

        new_data_str += data_str[current_index:match_range[0]] + '\\' 
        new_data_str += data_str[match_range[0]:match_range[0] + 1]

        current_index = match_range[0] + 1

    return new_data_str

result = shieldString('[]()sdkljfdkljs{}|')

print re.findall(result, '[]()sdkljfdkljs{}|')



cisco_cimc = CiscoHandlerFactory.createHandler('cimc', data_json, 'ssh', port)
cisco_cimc.connect() 

print cisco_cimc.scope('', re_string = '> ')\
