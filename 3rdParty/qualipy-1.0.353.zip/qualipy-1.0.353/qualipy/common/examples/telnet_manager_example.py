__author__ = 'g8y3e'

import sys
sys.path.append("../../../")

from qualipy.common.libs.qs_logger import setupLogger
from qualipy.common.libs.telnet_manager import TelnetManager

logger = setupLogger('test', logFile = 'test')

host   = '172.29.128.18'
port   = 2001

user   = None
passwd = None

telnet_client = TelnetManager(user, passwd, host, port, timeout = 4, logger = logger)

telnet_client.connect('#')


print telnet_client.sendCommand('test', '#')