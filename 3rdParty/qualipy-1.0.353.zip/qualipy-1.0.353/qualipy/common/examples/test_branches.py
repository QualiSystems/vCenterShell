__author__ = 'ini'

print 'Hello world'
print 'Hello QScxc'
print 'Hello QSqw'
print 'Hello mmmm'
print 'Hello pppll'
