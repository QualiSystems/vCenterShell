import sys
sys.path.append("../../../")

from qualipy.common.libs.qs_logger import setupLogger
from qualipy.common.libs.ssh_manager import SSHManager

logger = setupLogger('test', logFile = 'test')

host   = '172.29.128.10'
port   = 22

user   = 'klop'
passwd = 'azsxdc'

ssh_client = SSHManager(user, passwd, host, port, timeout = 4, logger = logger)

ssh_client._clearColors('[7m--More--[m')

ssh_client.connect('[#$]{1}')
print ssh_client.sendCommand('ps aux | more', '[#$]{1}')

print ""