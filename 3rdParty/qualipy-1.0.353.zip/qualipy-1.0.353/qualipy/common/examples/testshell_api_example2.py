from qualipy.common.libs.testshell_api import *

server = '192.168.41.54'

api = TestShellAPISession(server, 'admin', 'admin', 'Global')

vcenterName = 'vcenter2351351t'

api.CreateResource('Cloud Provider', 'VMware vCenter Server', vcenterName, '192.168.41.5')
api.UpdateResourceDriver(vcenterName, 'vCenterResource')
api.CreateResource('Virtual Datacenter', 'vSphere Datacenter', 'datacenter1', '0', '', vcenterName)
api.CreateResource('Virtual Cluster', 'vSphere Cluster', 'cluster1', '0', '', vcenterName+'/datacenter1')

clusterFullPath = vcenterName+'/datacenter1/cluster1'

api.SetAttributesValues([
    ResourceAttributesUpdateRequest(vcenterName, [
        AttributeNameValue('PowerCLI Installation Path', '''C:\Program Files (x86)\VMware\Infrastructure\vSphere PowerCLI'''),
        AttributeNameValue('User', '''qualisystems\qauser'''),
        AttributeNameValue('Password', 'qa1234'),
        AttributeNameValue('Simulated', 'True')
    ])
])

resid = api.CreateImmediateReservation("parallel"+vcenterName, "admin", 180).Reservation.Id

print "Created reservation http://"+server+"/RM/TopologyDiagram/Index/"+resid

serviceNames = []

for i in range(1, 15):
    serviceName = "x"+str(i)
    serviceNames.append(serviceName)
    api.AddServiceToReservation(resid, 'Create VM Advanced', serviceName, [
        AttributeNameValue('Creation Mode', 'Empty'),
        AttributeNameValue('VM Destination', clusterFullPath)
    ])

api.AddServiceToReservation(resid, 'Access VLAN', 'VLAN789', [
    AttributeNameValue('Share VLAN','True'),
    AttributeNameValue('VLAN ID','789')
])

for serviceName in serviceNames:
    api.SetConnectorsInReservation(resid, [
        SetConnectorRequest(serviceName, 'VLAN789', 'bi', serviceName)
    ])

for serviceName in serviceNames:
    api.EnqueueServiceCommand(resid, serviceName, 'CreateVMs')