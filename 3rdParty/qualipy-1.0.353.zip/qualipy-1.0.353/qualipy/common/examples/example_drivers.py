__author__ = 'eric.r'

'''

from Tools.DriverBuilderGenerator.QualiDrivers import GenerateDrivers
import QualiPy.common.examples.example_drivers
GenerateDrivers('c:/temp/try187')

'''

from QualiPy.common.libs.driver_builder_wrapper import DriverFunction
from QualiPy.common.libs.driver_builder_wrapper import base_driver
from QualiPy.common.libs.driver_builder_wrapper import base_resource_driver
from QualiPy.common.libs.driver_builder_wrapper import base_topology_driver
from QualiPy.common.libs.driver_builder_wrapper import base_service_driver


# Don't mess with __init__, just override Init(self, matrixJSON)

class resourcedriver1(base_resource_driver):
    @DriverFunction
    def Init(self, matrixJSON):
        self.counter=77

    @DriverFunction
    def increment(self, matrixJSON):
        self.counter+=1
        return "New counter: "+str(self.counter)

    @DriverFunction
    def increment2(self, matrixJSON):
        self.counter+=2
        return "New counter: "+str(self.counter)

    @DriverFunction
    def crash_test(self, matrixJSON):
        print "throw test"
        raise Exception("This was an exception thrown by the code")

    @DriverFunction
    def my_function(self, matrixJSON, x,y,z):
        return 'Input was x='+x+' y='+y+' z='+z+' json='+matrixJSON


    @DriverFunction(tags="remote_schmo")
    def connected_command1(self, matrixJSON, x,y,z):
        return 'Input was x='+x+' y='+y+' z='+z+' json='+matrixJSON


    @DriverFunction(alias="My Alias")
    def function_with_alias(self, matrixJSON, x,y,z):
        return 'Input was x='+x+' y='+y+' z='+z+' json='+matrixJSON


    @DriverFunction(extraMatrixRows={"resource": ["User","Password","Joe"]})
    def function_with_extra_resource_matrix_rows(self, matrixJSON, x,y,z):
        return 'Input was x='+x+' y='+y+' z='+z+' json='+matrixJSON


    @DriverFunction(description="""Insert

    Description

    Here
    """)
    def function_with_description(self, matrixJSON, x,y,z):
        return 'Input was x='+x+' y='+y+' z='+z+' json='+matrixJSON



    @DriverFunction(description="""Insert
        Description 2
    Here""", tags="tathshhhs gab bab", alias="my alias 24", extraMatrixRows={"resource": ["User","Password","Joe"]})
    def function_with_everything(self, matrixJSON, x,y,z):
        return 'Input was x='+x+' y='+y+' z='+z+' json='+matrixJSON

class servicedriver1(base_service_driver):
    @DriverFunction
    def f(self, matrixJSON,x,y):
        return 'x='+x+' y='+y+' matrix='+matrixJSON


class topodriver1(base_topology_driver):
    @DriverFunction
    def Init(self, matrixJSON):
        self.counter=0
    @DriverFunction
    def getval(self, matrixJSON):
        return self.val
    @DriverFunction
    def setval(self, matrixJSON, val):
        self.val=val
        return self.val
    @DriverFunction
    def increment(self, matrixJSON):
        self.counter+=1
        return 'sessionid='+self.sessionid+' counter='+str(self.counter)
    @DriverFunction
    def increment2(self, matrixJSON):
        self.counter+=2
        return 'sessionid='+self.sessionid+' counter='+str(self.counter)
    @DriverFunction
    def Setup(self, matrixJSON):
        return 'Setup complete: sessionid='+self.sessionid+' json='+matrixJSON

#
# driver1('123','mat123')
# driver1('456','mat456')
# driver2('789','mat789')
# driver2('xyz','matxyz')
#
# base_driver.sessionid2instance['123'].x('a')
# base_driver.sessionid2instance['456'].x('a')
# base_driver.sessionid2instance['789'].y('a')
# base_driver.sessionid2instance['xyz'].y('a')
