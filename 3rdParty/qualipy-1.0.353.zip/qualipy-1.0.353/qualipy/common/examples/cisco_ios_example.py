import sys
sys.path.append("../../")

from common.libs import qs_logger
from common.libs.ssh_manager import SSHManager

from common.cisco.cisco_ios import CiscoIOS

username = 'klop'
password = 'azsxdc'

host = '172.29.128.10'
port = 22
timeout = 4

logger_name = ''
logger_level = qs_logger.INFO
logger_format = qs_logger.defaultFormat
logger_file_name = ''

logger = qs_logger.setupLogger(logger_name, logger_level, logger_format, logger_file_name)
ssh_handler = SSHManager(username, password, host, port, timeout = timeout, logger = logger)

cisco_ios = CiscoIOS(ssh_handler, logger)

cisco_ios.connect()

print cisco_ios.ls('-1') + '\n';
print cisco_ios._sendCommand('\n');
print cisco_ios.ls('-1');

