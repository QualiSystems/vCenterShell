__author__ = 'eric.r'

from qualipy.common.libs.testshell_api import *

server = '192.168.41.54'

api = TestShellAPISession(server, 'admin', 'admin', 'Global')

resid = api.CreateReservation('aa', 'admin', '07/01/2015 00:01', '07/01/2015 00:31').Reservation.Id



# for i in range(1, 15):
#     serviceName = 'parallel '+str(i)
#     api.AddServiceToReservation(resid, 'Create VM Advanced', serviceName, [
#         AttributeNameValue('VM Destination', 'cluster1'),
#         AttributeNameValue('Creation Mode', 'Empty')
#     ] )

api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest bad folder', [
    AttributeNameValue('VM Destination', 'ESXi Cluster'),
    AttributeNameValue('Creation Mode', 'Empty'),
    AttributeNameValue('Container Folder', 'xaxaxax'),
])

api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest bad destination', [
    AttributeNameValue('VM Destination', 'Klustenr'),
    AttributeNameValue('Creation Mode', 'Empty'),
])
api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest ram', [
    AttributeNameValue('VM Destination', 'ESXi Cluster'),
    AttributeNameValue('Creation Mode', 'Empty'),
    AttributeNameValue('Memory in GB', '100000'),
])
api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest decrease disk', [
    AttributeNameValue('VM Destination', 'ESXi Cluster'),
    AttributeNameValue('Creation Mode', 'Template'),
    AttributeNameValue('VM Source', 'ubuntu-demo-template'),
    AttributeNameValue('Disk space in GB', '1'),
])
api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest bad template', [
    AttributeNameValue('VM Destination', 'ESXi Cluster'),
    AttributeNameValue('Creation Mode', 'Template'),
    AttributeNameValue('VM Source', 'bad template'),
])
api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest bad respool', [
    AttributeNameValue('VM Destination', 'ESXi Cluster'),
    AttributeNameValue('Creation Mode', 'Empty'),
    AttributeNameValue('Resource Pool', 'xaxaxax'),
])
api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest bad network name', [
    AttributeNameValue('VM Destination', 'ESXi Cluster'),
    AttributeNameValue('Creation Mode', 'Empty'),
    AttributeNameValue('Network Name', 'xaxaxax'),
])

api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest many1', [
    AttributeNameValue('VM Destination', 'Klustenr'),
    AttributeNameValue('Creation Mode', 'Empty'),
    AttributeNameValue('Memory in GB', '100000'),
    AttributeNameValue('Container Folder', 'xaxaxax'),
    AttributeNameValue('Resource Pool', 'xaxaxax'),
    AttributeNameValue('Network Name', 'xaxaxax'),
])
api.AddServiceToReservation(resid, 'Create VM Advanced', 'errtest multi nonfatal', [
    AttributeNameValue('VM Destination', 'ESXi Cluster'),
    AttributeNameValue('Creation Mode', 'Empty'),
    AttributeNameValue('Memory in GB', '100000'),
    AttributeNameValue('Network Name', 'xaxaxax'),
])


api.SaveReservationAsTopology(resid, 'errortest5', True)

print "Created environment http://"+server+"/RM/TopologyDiagram/Index/"+resid
