from qualipy.common.libs.testshell_api import TestShellAPISession
from qualipy.common.libs.testshell_api import TestShellAPIError

api = TestShellAPISession('192.168.41.54', 'admin', 'admin', 'Global')

x=api.GetTopologyDetails('apitesttopo')
for y in x.GlobalInputs:
    print y.ParamName

def rtrav(cr, tabs):
    for x in cr:
        print tabs+x.Name
        rtrav(x.ChildResources, tabs+'    ')


# jj=api.GetTopologyDetails('Environment VLAN').GlobalInputs

count = 0
for x in api.GetFolderContent().ContentArray:
    print x.Name
    count+=1
    if count > 10:
        break
    if x.Name != 'Global VLAN Pool':
        if x.Type == 'Resource':
            rtrav(api.GetResourceDetails(x.Name).ChildResources, '')


# resid = api.CreateImmediateReservation("ericres321",'admin', 60).Reservation.Id
# print "Created reservation "+ resid

import random
newname = 'PythonCreatedResource'+str(random.random())

# test creation
print "Created "+api.CreateResource('Virtual Server', 'Generic Virtual Server', newname, '1234').Name

# test caught exception
try:
    print "Created "+api.CreateResource('Virtual Server', 'Generic Virtual Server', newname, '1234').Name
except TestShellAPIError as e:
    print "caught exception: "+str(e)

# test uncaught exception
print "Created "+api.CreateResource('Virtual Server', 'Generic Virtual Server', newname, '1234').Name


