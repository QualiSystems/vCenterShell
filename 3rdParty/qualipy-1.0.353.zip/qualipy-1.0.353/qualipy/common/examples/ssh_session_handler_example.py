import sys
sys.path.append("../../../")

from common.libs.qs_logger import setupLogger
from common.libs.ssh_session_handler import SSHSessionHandler

logger = setupLogger('test', logFile = 'test')

host   = '127.0.0.1'
port   = 25

user   = 'ucspe'
passwd = 'ucspe'

ssh_client = SSHSessionHandler(user, passwd, host, port, timeout = 4, logger = logger)

ssh_client.connect()
print ssh_client.sendCommand('c', '[#$]{1}')

print ""