import sys
sys.path.append("../../../")

from common.libs import file_helper

file_helper.appendDataToFile("test", "Hello World!\n")
file_helper.appendDataToFile("test", "Hello World!\n")

#file_helper.writefileUTF16("test16", "Hello World!\n")

data = file_helper.readDataFromFile("test")

print data