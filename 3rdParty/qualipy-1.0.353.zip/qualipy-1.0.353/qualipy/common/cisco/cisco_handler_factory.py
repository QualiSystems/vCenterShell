__author__ = 'g8y3e'

import sys

sys.path.append("../../../")

import json

from qualipy.common.libs import qs_logger
from qualipy.common.libs.ssh_manager import SSHManager
from qualipy.common.libs.telnet_manager import TelnetManager
from qualipy.common.libs.file_manager import FileManager
from qualipy.common.libs.console_manager import ConsoleManager
from qualipy.bare_metal_provisioning.cisco.cisco_cimc import CiscoCimc
from qualipy.networking.cisco.cell_router import CellRouter
from qualipy.networking.cisco.cisco_nxos_3048 import CiscoNXOS3048
from qualipy.networking.cisco.cisco_nxos_55xx import CiscoNXOS55xx
from qualipy.common.libs.connection_manager import ConnectionManager

LOG_FORMAT = '%(asctime)s [%(levelname)s]: %(name)s - %(funcName)-20s %(message)s'
TIME_FORMAT = '%d-%b-%Y--%H-%M-%S'


class CiscoHandlerFactory:
    handler_classes = {
        'CELLROUTER': CellRouter,
        'CIMC': CiscoCimc,
        'NXOS_3048': CiscoNXOS3048,
        'NXOS_55XX': CiscoNXOS55xx
    }

    session_handler_classes = {
        'SSH': SSHManager,
        'TELNET': TelnetManager,
        'FILE': FileManager,
        'CONSOLE': ConsoleManager
    }

    # logger_handler = _createLogger()

    @staticmethod
    def createHandler(handler_name, host, username, password, session_handler_name='ssh', port=None,
                      timeout=10, logger=None, **kwargs):
        logger = logger if logger != None else qs_logger.getQSLogger(handler_name=handler_name)

        # session_class_name = CiscoHandlerFactory.session_handler_classes[session_handler_name.upper()]
        connection_manager = ConnectionManager(username=username, password=password, host=host, port=port,
                                               timeout=timeout, logger=logger, connection_type=session_handler_name,
                                               **kwargs)

        return CiscoHandlerFactory.handler_classes[handler_name.upper()](connection_manager, logger)


if __name__ == '__main__':
    data_json = """{
    "resource" : {
            "ResourceAddress": "172.29.128.100",
            "User": "ini",
            "Password": "123456",
            "ConsoleUser": "ini",
            "ConsolePassword": "123456",
            "ConsolePort": "5548-5-A",
            "ConsoleServerIpAddress" :"172.29.128.100"

        }
    }"""

    # data_json = """{
    # "resource" : {
    #         "ResourceAddress": "10.11.169.187",
    #         "User": "admin",
    #         "Password": "@Vantage123",
    #         "ConsoleUser": "admin",
    #         "ConsolePassword": "@Vantage123",
    #         "ConsolePort": "3048-3-A",
    #         "ConsoleServerIpAddress" :"10.11.169.187"
    #     }
    # }"""

    # data_json = """{
    #         "resource" : {
    #                 "ResourceAddress": "10.11.34.68",
    #                 "User": "admin",
    #                 "Password": "@Vantage123",
    #                 "ConsoleUser": "admin",
    #                 "ConsolePassword": "@Vantage123",
    #                 "ConsolePort": "5548-5-A",
    #                 "ConsoleServerIpAddress" :"10.11.169.189"
    #
    #             }
    #         }"""


    json_dict = json.loads(data_json)
    host = json_dict['resource']['ResourceAddress'].encode('ascii', errors='backslashreplace')
    username = json_dict['resource']['User'].encode('ascii', errors='backslashreplace')
    password = json_dict['resource']['Password'].encode('ascii', errors='backslashreplace')
    console_server_ip = json_dict['resource']['ConsoleServerIpAddress'].encode('ascii', errors='backslashreplace')
    console_server_user = json_dict['resource']['ConsoleUser'].encode('ascii', errors='backslashreplace')
    console_server_password = json_dict['resource']['ConsolePassword'].encode('ascii', errors='backslashreplace')
    console_port = json_dict['resource']['ConsolePort'].encode('ascii', errors='backslashreplace')

    handler = CiscoHandlerFactory.createHandler('NXOS_3048', host, username, password, session_handler_name='console',
                                                console_server_ip=console_server_ip,
                                                console_server_user=console_server_user,
                                                console_server_password=console_server_password,
                                                console_port=console_port)
    # handler.connect()
    # print(handler.sendCommand('enable'))
    # print(handler._sendCommand('dmesg|more'))
    # print(handler._sendCommand('ls'))
    print(handler.sendCommand('show version'))
    # session=handler.connect()
    # print(session._prompt)
    # out = session._hwExpect('show version')
    # out = handler._sendCommand('')
    #
    # out = handler._sendCommand('')
