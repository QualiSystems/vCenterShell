__author__ = 'g8y3e'
import re
import time

from cisco_os import CiscoOS


class CiscoIOS(CiscoOS):
    DEFAULT_PROMPT = '.*> *$'
    ENABLE_PROMPT = '.*# *$'
    CONFIG_MODE_PROMPT = '\(config.*\)# *$'
    ERR_STR = 'Invalid input detected|Incomplete command.'

    def __init__(self, connection_manager, logger):
        CiscoOS.__init__(self, connection_manager, logger)

        self._prompt = "{0}|{1}|{2}".format(self.DEFAULT_PROMPT, self.ENABLE_PROMPT, self.CONFIG_MODE_PROMPT)

    def _enterConfigurationMode(self):
        """Send 'enter' to SSH console to get prompt,
        if default prompt received , send 'configure terminal' command, change _prompt to CONFIG_MODE
        else: return

        :return: True if config mode entered, else - False
        """
        if not self._getSessionHandler():
            self.connect()

        if self._session.__class__.__name__ == 'FileManager':
            return ''

        out = None
        for retry in range(3):
            out = self._sendCommand(' ')
            if not out:
                self._logger.error('Failed to get prompt, retrying ...')
                time.sleep(1)

            elif not re.search(self.CONFIG_MODE_PROMPT, out):
                out = self._sendCommand('configure terminal', self.CONFIG_MODE_PROMPT)

            else:
                break

        if not out:
            return False
        self._prompt = self.CONFIG_MODE_PROMPT
        return re.search(self._prompt, out)

    def _exitConfigurationMode(self):
        """Send 'enter' to SSH console to get prompt,
        if config prompt received , send 'exit' command, change _prompt to DEFAULT
        else: return

        :return: console output
        """

        if not self._getSessionHandler():
            self.connect()

        if self._session.__class__.__name__ == 'FileManager':
            return ''

        out = None
        for retry in range(5):
            out = self._sendCommand(' ')
            if re.search(self.CONFIG_MODE_PROMPT, out):
                self._sendCommand('exit')
            else:
                break
        self._prompt = self.ENABLE_PROMPT

        return out

    def _sendConfigCommand(self, cmd, expected_str=None, timeout=30):
        """Send command into configuration mode, enter to config mode if needed

        :param cmd: command to send
        :param expected_str: expected output string (_prompt by default)
        :param timeout: command timeout
        :return: received output buffer
        """

        self._enterConfigurationMode()

        if expected_str is None:
            expected_str = self._prompt

        out = self._sendCommand(cmd, expected_str, timeout)
        self._logger.info(out)
        return out

    def _sendCommand(self, cmd, expected_str=None, timeout=30):
        """Send command into default mode, exit config mode if needed

        :param cmd: command to send
        :param expected_str: expected output string (_prompt by default)
        :param timeout: command timeout
        :return: received output buffer
        """

        self._exitConfigurationMode()

        if expected_str is None:
            expected_str = self._prompt

        out = CiscoOS._sendCommand(self, cmd, expected_str, timeout)
        self._logger.info(out)
        return out

    def _sendCommandsList(self, commands_list):
        for command in commands_list:
            self._sendConfigCommand(command)