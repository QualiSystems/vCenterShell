__author__ = 'pava'

import unittest
import collections

from qualipy.common.libs.qs_logger import *
from qualipy.common.libs.connection_manager import *
from qualipy.common.libs.utils import isSameListCommandInFile
from cisco_nxos import *

class TestCiscoNxos(unittest.TestCase):
    def setUp(self):
        logger = getQSLogger(handler_name='nxos')
        self._log_filename = 'Logs/nxos_unittest.log'
        connection_manager = ConnectionManager(connection_type='file', filename=self._log_filename, logger=logger)

        self._cisco_nxos = CiscoNxOS(connection_manager, logger)

    def tearDown(self):
        self._cisco_nxos.disconnect()

    def test_feature(self):
        self._cisco_nxos.feature('test')

        expect_list = ['feature test']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_role(self):
        self._cisco_nxos.role('name default-role')

        expect_list = ['role name default-role']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureSSH(self):
        self._cisco_nxos.configureSSH('rsa', mode='enable')

        expect_list = ['no feature ssh', 'ssh key rsa 2048 ', 'feature ssh']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureTelnet(self):
        self._cisco_nxos.configureTelnet('disable')

        expect_list = ['no feature telnet', 'no telnet server enable']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureCFS(self):
        self._cisco_nxos.configureCFS('enable')

        expect_list = ['cfs eth distribute']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureLacp(self):
        self._cisco_nxos.configureLacp('enable')

        expect_list = ['feature lacp']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureVpc(self):
        self._cisco_nxos.configureVpc('enable')

        expect_list = ['feature vpc']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureHsrp(self):
        self._cisco_nxos.configureHsrp('enable')

        expect_list = ['feature hsrp']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureDefaultRole(self):
        self._cisco_nxos.configureDefaultRole()

        expect_list = ['role name default-role', 'description This is a system defined role and applies to all users.']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_addUser(self):
        self._cisco_nxos.addUser('admin2', 'cisco', 'network-admin')

        expect_list = ['username admin2 password cisco role network-admin']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_addBanner(self):
        self._cisco_nxos.addBanner('this is a banner')

        expect_list = ['banner motd # this is a banner', '#']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureIpDomainLookup(self):
        self._cisco_nxos.configureIpDomainLookup('disable')

        expect_list = ['no ip domain-lookup']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_setHostname(self):
        self._cisco_nxos.setHostName('test-hostname')

        expect_list = ['hostname test-hostname']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_addVpcDomain(self):
        params_map = collections.OrderedDict({})
        params_map['vpc domain'] = ["10"]
        params_map['peer keep alive vrf'] = ["10.1.1.2", "management"]
        params_map['system priority'] = ["8192"]
        params_map['role priority'] = ["8192"]
        params_map['auto recovery'] = []
        params_map['peer switch'] = []

        self._cisco_nxos.addVpcDomain(params_map)

        expect_list = ['vpc domain 10', 'peer-keepalive destination 10.1.1.2 vrf management', 'system-priority 8192',
                       'role priority 8192', 'auto-recovery', 'peer-switch', 'exit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureInterfaceVlan(self):
        params_map = dict()
        params_map['configure_interface'] = ['vlan', '1']
        params_map['ip_address'] = ['10.0.0.1', '255.255.255.0']
        params_map['hsrp'] = ['111']
        params_map['authentication'] = ['test']
        params_map['priority'] = ['10']
        params_map['track'] = ['1', '20']
        params_map['ip'] = ['127.0.0.11']
        params_map['preempt'] = []
        params_map['no_shut'] = []

        self._cisco_nxos.configureInterfaceVlan(**params_map)

        expect_list = ['interface vlan 1', 'track 1 decrement 20', 'ip 127.0.0.11', 'hsrp 111', 'priority 10',
                       'no shut', 'authentication test', 'ip address 10.0.0.1 255.255.255.0', 'preempt', 'exit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureInterfacePortChannel(self):
        params_map = dict()
        params_map['configure_interface'] = ['port-channel', '1']
        params_map['description'] = ['To Customer Management Switch A']
        params_map['switchport_mode'] = ['trunk']
        params_map['vpc'] = ['5']
        params_map['allow_trunk_vlan'] = ['1']
        params_map['spanning_tree'] = ['port type', 'edge trunk']
        params_map['speed'] = ['111']
        params_map['untagged'] = ['cos', '2']

        self._cisco_nxos.configureInterfacePortChannel(**params_map)

        expect_list = ['interface port-channel 1', 'spanning-tree port type edge trunk', 'switchport',
                       'switchport trunk allowed vlan 1', 'description To Customer Management Switch A',
                       'switchport mode trunk', 'vpc 5', 'untagged cos 2', 'speed 111', 'exit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureInterfaceEthernet(self):
        params_map = dict()
        params_map['configure_interface'] = ['ethernet', '1/24']
        params_map['ip_address'] = ['10.0.0.1', '255.255.255.0']
        params_map['trunk_allow_vlan'] = ['1']
        params_map['channel_group_mode'] = ['10', 'active']
        params_map['spanning_tree_type'] = ['port', 'network']

        params_map['switchport_mode_trunk'] = []
        params_map['no_shut'] = []
        params_map['mode_trunk'] = []
        params_map['no_switchport'] = []

        self._cisco_nxos.configureInterfaceEthernet(**params_map)

        expect_list = ['interface ethernet 1/24', 'switchport mode trunk', 'mode trunk', 'no switchport',
                       'spanning-tree port type network', 'channel-group 10 mode active',
                       'switchport trunk allowed vlan 1', 'ip address 10.0.0.1 255.255.255.0', 'exit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureInterfaceMgmt(self):
        params_map = dict()
        params_map['configure_interface'] = ['mgmt', '2']
        params_map['description'] = ['To Customer Management Switch A']
        params_map['vrf_member'] = ['management']
        params_map['ip_address'] = ['10.1.1.1', '255.255.255.252']

        params_map['no_shut'] = []

        self._cisco_nxos.configureInterfaceMgmt(**params_map)

        expect_list = ['interface mgmt 2', 'description To Customer Management Switch A',
                       'ip address 10.1.1.1 255.255.255.252', 'vrf member management', 'exit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_configureQos(self):
        class_map = [
            {
                'type': 'qos',
                'name': 'class-gold',
                'method': 'match',
                'method_params':  {
                    'name': 'cos',
                    'value': '4'
                }
            },
            {
                'type': 'qos',
                'name': 'class-platinum',
                'method': 'match',
                'method_params': {
                    'name': 'cos',
                    'value': '4'
                }
            },
            {
                'type': 'queuing',
                'name': 'class-gold',
                'method': 'match',
                'method_params': {
                    'name': 'cos',
                    'value': '4'
                }
            },
            {
                'type': 'queuing',
                'name': 'class-platinum',
                'method': 'match',
                'method_params': {
                    'name': 'cos',
                    'value': '4'}
            },
            {
                'type': 'network-qos',
                'name': 'class-gold',
                'method': 'match',
                'method_params': {
                    'name': 'qos-group',
                    'value': '3'}
            },
            {
                'type': 'network-qos',
                'name': 'class-platinum',
                'method': 'match',
                'method_params': {
                    'name': 'qos-group',
                    'value': '2'}
            }
        ]

        policy_map = [
            {
                'type': 'qos',
                'name': 'system_qos_policy',
                'method': 'class',
                'method_params': [
                    {
                        'name': 'class-platinum',
                        'method': 'set',
                        'method_params': {
                            'name': 'qos-group',
                            'value': '2'
                        }
                    },
                    {
                        'name': 'class-gold',
                        'method': 'set',
                        'method_params': {
                            'name': 'qos-group',
                            'value': '3'
                        }
                    }
                ]
            },
            {
                'type': 'network-qos',
                'name': 'system_nq_policy',
                'method': 'class',
                'method_params': [
                    {
                        'type': 'network-qos',
                        'name': 'class-default',
                    },
                    {
                        'type': 'network-qos',
                        'name': 'class-platinum',
                    },
                    {
                        'type': 'network-qos',
                        'name': 'class-gold',
                    },
                    {
                        'type': 'network-qos',
                        'name': 'class-fcoe',
                    }
                ]
            },
            {
                'type': 'queuing',
                'name': 'system_q_in_policy',
                'method': 'class_type',
                'method_params': [
                    {
                        'type': 'queuing',
                        'name': 'class-platinum',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '5'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'cclass-gold',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '10'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-fcoe',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '0'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-default',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '85'
                        }
                    }

                ]
            },
            {
                'type': 'queuing',
                'name': 'system_q_out_policy',
                'method': 'class_type',
                'method_params': [
                    {
                        'type': 'queuing',
                        'name': 'class-platinum',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '5'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'cclass-gold',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '10'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-fcoe',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '0'
                        }
                    },
                    {
                        'type': 'queuing',
                        'name': 'class-default',
                        'method': 'bandwidth',
                        'method_params': {
                            'name': 'percent',
                            'value': '85'
                        }
                    }

                ]
            }
        ]

        service_policy = {
            'name': 'qos',
            'services': [
                {
                    'type': 'qos',
                    'value': 'system_qos_policy',
                    'direction': 'input'
                },
                {
                    'type': 'queuing',
                    'value': 'system_q_in_policy',
                    'direction': 'output'
                },
                {
                    'type': 'queuing',
                    'value': 'system_q_out_policy',
                    'direction': 'input'
                },
                {
                    'type': 'network-qos',
                    'value': 'system_nq_policy',
                }
            ]
        }
        self._cisco_nxos.configureQos(class_map=class_map, policy_map=policy_map,
                                               service_policy=service_policy)

        expect_list = ['class-map type qos class-gold', 'match cos 4', 'class-map type qos class-platinum',
                       'match cos 4', 'class-map type queuing class-gold', 'match cos 4',
                       'class-map type queuing class-platinum', 'match cos 4', 'class-map type network-qos class-gold',
                       'match qos-group 3', 'class-map type network-qos class-platinum', 'match qos-group 2',
                       'policy-map type qos system_qos_policy', 'class class-platinum', 'set qos-group 2',
                       'class class-gold', 'set qos-group 3', 'policy-map type network-qos system_nq_policy',
                       'class class-default', 'class class-platinum', 'class class-gold', 'class class-fcoe',
                       'policy-map type queuing system_q_in_policy', 'class type class-platinum queuing',
                       'bandwidth percent 5', 'class type cclass-gold queuing', 'bandwidth percent 10',
                       'class type class-fcoe queuing', 'bandwidth percent 0', 'class type class-default queuing',
                       'bandwidth percent 85', 'policy-map type queuing system_q_out_policy',
                       'class type class-platinum queuing', 'bandwidth percent 5', 'class type cclass-gold queuing',
                       'bandwidth percent 10', 'class type class-fcoe queuing', 'bandwidth percent 0',
                       'class type class-default queuing', 'bandwidth percent 85', 'system qos',
                       'service-policy type qos input system_qos_policy', 'service-policy type queuing output system_q_in_policy',
                       'service-policy type queuing input system_q_out_policy', 'service-policy type network-qos   system_nq_policy']

        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

if (__name__ == '__main__'):
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass