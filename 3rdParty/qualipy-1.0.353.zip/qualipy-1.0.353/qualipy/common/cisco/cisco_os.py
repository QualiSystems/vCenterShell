__author__ = 'g8y3e'


class CiscoOS:
    def __init__(self, connection_manager, logger=None):
        self._connection_manager = connection_manager
        self._session = None
        self._logger = logger
        self._prompt = '.*[>#] *$'
        self._params_sep = ' '
        self._command_retries = 3

    def _sendCommand(self, command, expected_str=None, timeout=30):
        if not expected_str:
            expected_str = self._prompt
        if not self._session:
            self.connect()

        # self.logger.info('Command: %s, expected: %s' % (command, expected_str))
        for retry in range(self._command_retries):
            try:
                out = self._session.hwExpect(command, expected_str, timeout)
                break
            except Exception as e:
                self._logger.error(e)
                if retry == self._command_retries-1:
                    raise Exception('Can not send command')
                self.disconnect()
                self.connect()
        return out

        # return self.session.sendCommand(command, expected_str, timeout)

    def _defaultActions(self):
        pass

    def connect(self):
        self._session = self._connection_manager.getSession(self._prompt)
        self._defaultActions()

    def disconnect(self):
        if self._session:
            return self._session.disconnect()

    def _getSessionHandler(self):
        return self._session

    def _getLogger(self):
        return self._logger
