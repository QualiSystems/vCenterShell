__author__ = 'g8y3e'

import datetime

from qualipy.common.cisco.cisco_ios import CiscoIOS
from qualipy.networking.cisco.interfaces.level_2.vlan import *
from qualipy.networking.cisco.interfaces.level_2.port_channel import *
from qualipy.networking.cisco.interfaces.level_2.ethernet import *
from qualipy.networking.cisco.interfaces.level_2.mgmt import *
from qualipy.networking.cisco.quality_of_service.quality_of_service import *
from qualipy.common.libs.parameters_service.command_template import *


class CiscoNxOS(CiscoIOS):
    DEFAULT_PROMPT = '.*>'
    ENABLE_PROMPT = '.*#'
    CONFIG_MODE_PROMPT = '\(config.*\)#'
    ERR_STR = 'Invalid input detected|Incomplete command|ERROR:'

    def __init__(self, connection_manager, logger):
        CiscoIOS.__init__(self, connection_manager, logger)

        self._prompt = self.ENABLE_PROMPT

    def enableFeature(self, feature_name):
        """
        Enables arbitrary feature specified by feature_name parameter
        :param feature_name: name of arbitrary feature to be enabled. Examples: ssh, telnet, lacp, vpc
        :return: success message
        :rtype: string
        """
        self.feature(feature_name)
        return 'EnableFeature {0} Done.'.format(feature_name)

    def disableFeature(self, feature_name):
        """
        Disables arbitrary feature specified by feature_name parameter
        :param feature_name: name of arbitrary feature to be disabled. Examples: ssh, telnet, lacp, vpc
        :return: success message
        :rtype: string
        """
        self.noFeature(feature_name)
        return 'DisableFeature {0} Done.'.format(feature_name)

    def feature(self, feature_str, **kwargs):
        """
        Enables arbitrary feature specified by feature_str parameter
        :param feature_str: name of arbitrary feature to be enabled. Examples: ssh, telnet, lacp, vpc
        :param kwargs: dictionary of additional parameters
        :return: success message
        :rtype: string
        """
        command = 'feature {0}'.format(feature_str)
        return self._sendConfigCommand(command, **kwargs)

    def noFeature(self, feature_name, **kwargs):
        """
        Disables arbitrary feature specified by feature_name parameter
        :param feature_name: name of arbitrary feature to be disabled. Examples: ssh, telnet, lacp, vpc
        :param kwargs: dictionary of additional parameters
        :return: success message
        :rtype: string
        """
        command = 'no feature {0}'.format(feature_name)
        return self._sendConfigCommand(command, **kwargs)

    def no(self, args, **kwargs):
        """
        Disables arbitrary feature specified by args parameter
        :param args: list of arguments
        :param kwargs: dictionary of additional parameters
        :return: success message
        :rtype: string
        """
        command = 'no {0}'.format(args)
        return self._sendConfigCommand(command, **kwargs)

    def ssh(self, command_args, **kwargs):
        """
        Configures ssh connection according to command_args
        :param command_args: list of arguments
        :param kwargs: dictionary of additional parameters
        :return: success message
        :rtype: string
        """
        command = 'ssh {0}'.format(command_args)
        return self._sendConfigCommand(command, **kwargs)

    def role(self, args, **kwargs):
        """
        Configures role according to args parameter
        :param args: list of arguments
        :param kwargs: dictionary of additional parameters
        :return: success message
        :rtype: string
        """
        command = 'role {0}'.format(args)
        return self._sendConfigCommand(command, **kwargs)

    def description(self, args, **kwargs):
        """
        Sets description according to args parameter
        :param args: list of arguments
        :param kwargs: dictionary of additional parameters
        :return: success message
        :rtype: string
        """
        command = 'description {0}'.format(args)
        return self._sendConfigCommand(command, **kwargs)

    def exit(self):
        """
        Exits current configuration mode
        :return:
        """
        return self._sendCommand('exit')

    def configureSSH(self, key_type, key_size='2048', force=False, mode='enable'):
        """
        Configures SSH according to key_type, key_size, force and mode
        :param key_type: [RSA|DSA]
        :param key_size: size of the rsa/dsa key
        :param force: [True|False]
        :param mode: [ENABLE|DISABLE]
        :return: success message
        :rtype: string
        """
        if (mode.upper() == "DISABLE"):
            self.noFeature('ssh')
        else:

            name = self.__module__
            if not isInteger(key_size):
                raise Exception(name,
                                'Invalid parameter provided for \'size\', only number that multiples of 8 is allowed.')
            elif int(key_size) % 8:
                raise Exception(name,
                                'Invalid parameter provided for \'size\', only number that multiples of 8 is allowed.')

            force_str = ''
            if force:
                force_str = 'force'

            self.noFeature('ssh')
            self._sendConfigCommand('ssh key {0} {1} {2}'.format(key_type, key_size, force_str))
            self.feature("ssh")

        return '{0}: Service SSH mode \'{1}\' configuration done.'.format(mode.upper(), key_type)

    def configureTelnet(self, mode='enable'):
        """
        Configures telnet according to the flow
        :param mode: [ENABLE|DISABLE]
        :return: success message
        :rtype: string
        """
        if 'enable' in mode.lower():
            self.feature('telnet')
            self._sendConfigCommand('telnet server enable')
            return "Telnet has been enabled"
        else:
            self.noFeature('telnet')
            self.no('telnet server enable')
            return "Telnet has been disabled"

    def configureCFS(self, mode='enable'):
        """
        Configures CFS according to the flow
        :param mode: [ENABLE|DISABLE]
        :return: success message
        :rtype: string
        """
        if 'enable' in mode.lower():
            self._sendConfigCommand("cfs eth distribute")
            return "CFS has been enabled"
        else:
            self.no('cfs eth distribute')
            return "CFS has been disabled"

    def configureLacp(self, mode='enable'):
        """
        Configures LACP according to the flow
        :param mode: [ENABLE|DISABLE]
        :return: success message
        :rtype: string
        """
        if 'enable' in mode.lower():
            self.feature('lacp')
            return "LACP feature has been enabled"
        else:
            self.noFeature('lacp')
            return "LACP feature has been disabled"

    def configureVpc(self, mode='enable'):
        """
        Configures VPC according to the flow
        :param mode: [ENABLE|DISABLE]
        :return: success message
        :rtype: string
        """
        if 'enable' in mode.lower():
            self.feature('vpc')
            return "VPC feature has been enabled"
        else:
            self.noFeature('vpc')
            return "VPC feature has been disabled"

    def addVpcDomain(self, args):
        """
        Adds VPC domain according to the flow
        :param args: one of the commands from the commands_Template map
        :return: success message
        :rtype: string
        """
        commands_Template = {
            'vpc domain': CommandTemplate('vpc domain {0}', [r'\d+'], ['Wrong Ip!']),
            'system priority': CommandTemplate('system-priority {0}', [r'\d+'], ['Wrong System Priority Number!']),
            'role priority': CommandTemplate('role priority {0}', [r'\d+'], ['Wrong Role Priority Number!']),

            'peer keep alive vrf': CommandTemplate('peer-keepalive destination {0} vrf {1}',
                                                   [validateIP, r'\bmanagement\b|\bdefault\b'],
                                                   ['Wrong Ip!', 'Wrong Vrf']),
            'auto recovery': CommandTemplate('auto-recovery', [], []),
            'peer switch': CommandTemplate('peer-switch', [], [])}
        for command, value in args.items():
            if command in commands_Template:
                command_template = commands_Template[command]
                self._sendConfigCommand(ParametersService.getValidateList(command_template, value))
        self.exit()
        return 'VPC domain added!'

    def configureInterfaceVlan(self, **kwargs):
        """
        Configures interface VLAN according to the flow
        :param kwargs: dictionary of parameters
        :return: success message
        :rtype: string
        """
        interface_vlan = Vlan()

        commands_list = interface_vlan.getCommandsList(**kwargs)
        self._sendCommandsList(commands_list)

        self.exit()

        return 'Finished configuration of Vlan interface!'

    def configureInterfacePortChannel(self, **kwargs):
        """
        Configures interface port-channel
        :param kwargs: dictionary of parameters
        :return: success message
        :rtype: string
        """
        interface_port_channel = PortChannel()

        commands_list = interface_port_channel.getCommandsList(**kwargs)
        self._sendCommandsList(commands_list)

        self.exit()

        return 'Finished configuration of Port-channel interface!'

    def configureInterfaceEthernet(self, **kwargs):
        """
        Configures interface ethernet
        :param kwargs: dictionary of parameters
        :return: success message
        :rtype: string
        """
        interface_ethernet = Ethernet()

        commands_list = interface_ethernet.getCommandsList(**kwargs)
        self._sendCommandsList(commands_list)

        self.exit()

        return 'Finished configuration of Port-channel interface!'

    def configureInterfaceMgmt(self, **kwargs):
        """
        Configures interface management
        :param kwargs: dictionary of parameters
        :return: success message
        :rtype: string
        """
        interface_mgmt = Mgmt()

        commands_list = interface_mgmt.getCommandsList(**kwargs)
        self._sendCommandsList(commands_list)

        self.exit()

        return 'Finished configuration of Port-channel interface!'

    def configureHsrp(self, mode='enable'):
        """
        Configures HSRP according to the flow
        :param mode: [ENABLE|DISABLE]
        :return:
        """
        if 'enable' in mode.lower():
            self.feature('hsrp')
            return "HSRP feature has been enabled!"
        else:
            self.noFeature('hsrp')
            return "HSRP feature has been disabled!"

    def configureDefaultRole(self):
        """
        Configures default role according to the flow
        :return: success message
        :rtype: string
        """
        self.role('name default-role')
        self.description('This is a system defined role and applies to all users.')
        # self.exit()
        return "Default role has been created!"

    def addUser(self, username, password, role):
        """
        Adds user with username, password and role
        :param username: username
        :param password: password
        :param role: Role from the list of available roles
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("username " + username + " password " + password + " role " + role)
        return "User {0} with role {1} has been added".format(username, role)

    def setRoleForUser(self, username, role):
        """
        Sets role for user
        :param username: username
        :param role: Role from the list of available roles
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("username " + username + " role " + role)
        return "Role {1} has been assigned to user {0}".format(username, role)

    def setExpirationDateForUser(self, username, expire_date):
        """
        Sets expiration date for user
        :param username: username
        :param expire_date: expiration date in a format %Y-%m-%d
        :return: success message
        :rtype: string
        """
        try:
            datetime.datetime.strptime(expire_date, '%Y-%m-%d')
            self._sendConfigCommand("username " + username + " expire " + expire_date)
            return "Expiration date {0} has been set for user {1}".format(expire_date, username)
        except ValueError:
            raise ValueError("Incorrect data format, should be YYYY-MM-DD")

    def setKeypairExportForUser(self, username, filename=''):
        """
        Sets keypair export for user
        :param username: username
        :param filename: path to the file with keypair
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("username " + username + " keypair export " + filename)
        return "Keypair export has been set for user {0} from file {1}".format(username, filename)

    def setKeypairImportForUser(self, username, filename=''):
        """
        Sets keypair import for user
        :param username: username
        :param filename: path to the file with keypair
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("username " + username + " keypair import " + filename)
        return "Keypair import has been set for user {0} from file {1}".format(username, filename)

    def setKeypairGenerateForUser(self, username, encryptionMode='rsa'):
        """
        Sets keypair generate for user
        :param username: username
        :param encryptionMode: [DSA|RSA]
        :return: success message
        :rtype: string
        """
        if encryptionMode in ['rsa', 'dsa']:
            self._sendConfigCommand("username " + username + " keypair generate " + encryptionMode)
            return "Keypair generate has been set for user {0} with encryption mode {1}".format(username,
                                                                                                encryptionMode)
        else:
            raise ValueError("Incorrect encryption mode. Should be either rsa or dsa")

    def setSshKeyForUser(self, username, filename='', line=None):
        """
        Sets SSH key for user
        :param username: username
        :param filename: path to the file with key
        :param line: ssh key for the user
        :return:
        """
        if line != None:
            self._sendConfigCommand("username " + username + " sshkey " + line)
            return "SSH key has been set for user {0} from line {1}".format(username, line)
        else:
            self._sendConfigCommand("username " + username + " sshkey file " + filename)
            return "SSH key has been set for user {0} from file {1}".format(username, filename)

    def setSshCertDnForUser(self, username, certificate, encryptionMode='rsa'):
        """
        Sets SSH certificate for user
        :param username: username
        :param certificate: certificate string
        :param encryptionMode: [DSA|RSA]
        :return:
        """
        if encryptionMode in ['rsa', 'dsa']:
            self._sendConfigCommand("username " + username + " ssh-cert-dn " + certificate + " " + encryptionMode)
            return "SSH certifiate has been set for user {0} with encryption mode {1}".format(username, encryptionMode)
        else:
            raise ValueError("Incorrect encryption mode. Should be either rsa or dsa")

    def addBanner(self, text):
        """
        Adds banner
        :param text: banner text
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("banner motd # " + text + "\n#")
        return "Banner has been added"

    def configureIpDomainLookup(self, mode='enable'):
        """
        Configures IP domain lookup according to the flow
        :param mode: [ENABLE|DISABLE]
        :return: success message
        :rtype: string
        """
        if 'enable' in mode.lower():
            self._sendConfigCommand("ip domain-lookup")
            return "IP domain lookup has been enabled"
        else:
            self._sendConfigCommand("no ip domain-lookup")
            return "IP domain lookup has been disabled"

    def setHostName(self, hostname):
        """
        Sets hostname
        :param hostname:
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("hostname " + hostname)
        return "Hostname {0} has been set ".format(hostname)

    def configureNtpServer(self, ntp_server_host):
        """
        Configures NTP server according to the flow
        :param ntp_server_host: NTP server host
        :return: success message
        :rtype: string
        """
        ntp_command = CommandTemplate('ntp server {0}', [validateIP], ['Wrong IP!'])
        self._sendConfigCommand(ParametersService.getValidateList(ntp_command, [ntp_server_host]))
        return 'Finished Ntp Server configuration!'

    def configureSnmpServer(self, **kwargs):
        """
        Configures SNMP server according to the value from commands_Template map
        :param kwargs: dictionary of arguments
        :return: success message
        :rtype: string
        """
        commands_Template = {
            'snmp server community': CommandTemplate('snmp server community {0} group {1}', [r'[\w]+', r'[\w]+'],
                                                     ['Wrong Community String!', 'Wrong Group']),
            'snmp server host': CommandTemplate('snmp-server host {0} traps version {1}',
                                                [validateIP, r'\b1\b|\b2c\b|\b3\b'],
                                                ['Wrong Ip!', 'Wrong Version']),
            'snmp server host custom port': CommandTemplate('snmp-server host {0} traps version {1} udp-port {2}',
                                                            [validateIP, r'\b1\b|\b2c\b|\b3\b', r'\d+'],
                                                            ['Wrong Ip!', 'Wrong Version', 'Wrong Port']),
            'enable traps': CommandTemplate('snmp-server enable traps', [], [])}
        commands = []
        for command, value in kwargs.items():
            if command in commands_Template:
                command_template = commands_Template[command]
                commands.append(ParametersService.getValidateList(command_template, value))
        self._sendCommandsList(commands)
        return 'Finished Snmp Server configuration!'

    def configureSpanningTreePortType(self, type, mode='default', action='enable'):
        """
        Configures spanning tree port type
        :param type: [edge|network]
        :param mode: [bpduguard |bpdufilter |default]
        :param action: [ENABLE|DISABLE]
        :return: success message
        :rtype: string
        """

        if (mode == 'bpduguard') or (mode == 'bpdufilter'):
            mode += ' default'

        cmd = "spanning-tree port type {0} {1}".format(type, mode)
        if action.upper() == 'DISABLE':
            cmd = 'no ' + cmd

        self._sendConfigCommand(cmd)
        return "Spanning tree port type {0} {1} has been set ".format(type, mode)

    #    #def setSpanningTreePort(self, mode):
    #    if mode in ['edge trunk', 'normal', 'network']:
    #        self._sendConfigCommand("spanning-tree port type {0}".format(mode))
    #        return "Spanning tree port type {0} has been set".format(mode)
    #    else:
    #        raise ValueError('Invalid mode. Should be either edge trunk, normal or network')

    def setSpanningTreeBridgeAssurance(self):
        """
        Sets spanning tree bridge assurance according to the flow
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree bridge assurance")
        return "Spanning tree bridge assurance has been set"

    def setSpanningTreePseudoInformation(self):
        """
        Sets spanning tree pseudo information according to the flow
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree pseudo-information")
        return "Spanning tree pseudo-information has been set"

    def setSpanningTreeDomain(self, domain_id):
        """
        Sets spanning tree domain according to the flow
        :param domain_id: domain ID
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree domain {0}".format(domain_id))
        return "Spanning tree domain {0} has been set".format(domain_id)

    def setSpanningTreeLoopguard(self):
        """
        Sets spanning tree loopguard according to the flow
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree loopguard default")
        return "Spanning tree loopguard has been set"

    def setSpanningTreeMode(self, mode='mst'):
        """
        Sets spanning tree mode according to the flow
        :param mode: [MST|RAPID-PVST]
        :return: success message
        :rtype: string
        """
        if mode in ['mst', 'rapid-pvst']:
            self._sendConfigCommand("spanning-tree mode " + mode)
            return "Spanning tree mode {0} has been set".format(mode)
        else:
            raise ValueError("Incorrect mode. Should be either mst or rapid-pvst")

    def setSpanningTreePathcost(self, method='long'):
        """
        Sets spanning tree pathcost according to the flow
        :param method: [LONG|SHORT]
        :return: success message
        :rtype: string
        """
        if method in ['long', 'short']:
            self._sendConfigCommand("spanning-tree pathcost method " + method)
            return "Spanning tree pathcost has been set with method {0}".format(method)
        else:
            raise ValueError("Incorrect method. Should be either long or short")

    def setSpanningTreeMstRange(self, range):
        """
        Sets spanning tree MST range according to the flow
        :param range: MST instance range. Example: 0-3,5,7-9
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree mst " + range)
        return "Spanning tree mst range {0} has been set".format(range)

    def enterSpanningTreeMstConfigMode(self):
        """
        Enters spanning tree mst configuration mode
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree mst configuration")
        return "Entered spanning tree mst configuration mode"

    def setSpanningTreeMstForwardTime(self, time):
        """
        Sets spanning tree mst forward time
        :param time: forward time. Allowed values [4-30]
        :return: success message
        :rtype: string
        """
        if (int(time) >= 4) and (int(time) <= 30):
            self._sendConfigCommand("spanning-tree mst forward-time " + time)
            return "Spanning tree mst forward time has been set to {0}".format(time)
        else:
            raise ValueError("Incorrect time. Should be in range from 4 to 30 sec")

    def setSpanningTreeMstHelloTime(self, time):
        """
        Sets spanning tree mst hello time
        :param time: hello time. Allowed values [1-10]
        :return: success message
        :rtype: string
        """
        if (int(time) >= 1) and (int(time) <= 10):
            self._sendConfigCommand("spanning-tree mst hello-time " + time)
            return "Spanning tree mst hello time has been set to {0}".format(time)
        else:
            raise ValueError("Incorrect time. Should be in range from 1 to 10 sec")

    def setSpanningTreeMstMaxAge(self, age):
        """
        Sets spanning tree mst max age
        :param age: allowed values [6-40]
        :return: success message
        :rtype: string
        """
        if (int(age) >= 6) and (int(age) <= 40):
            self._sendConfigCommand("spanning-tree mst max-age " + age)
            return "Spanning tree mst max age has been set to {0}".format(age)
        else:
            raise ValueError("Incorrect max age. Should be in range from 6 to 40")

    def setSpanningTreeMstMaxHops(self, hops):
        """
        Sets spanning tree mst max hops
        :param hops: allowed values [1-200]
        :return: success message
        :rtype: string
        """
        if (int(hops) >= 1) and (int(hops) <= 200):
            self._sendConfigCommand("spanning-tree mst max-hops " + hops)
            return "Spanning tree mst max hops has been set to {0}".format(hops)
        else:
            raise ValueError("Incorrect max hops. Should be in range from 1 to 200")

    def setSpanningTreeMstSimulate(self):
        """
        Sets spanning tree mst simulate according to the flow
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree mst simulate pvst global")
        return "Spanning tree mst has been set to simulate pvst global"

    def setSpanningTreeVlanForwardTime(self, range, time):
        """
        Sets spanning tree VLAN forward time
        :param range: vlan range, examples: 0-3,5,7-9
        :param time: forward time. Allowed values [4-30]
        :return: success message
        :rtype: string
        """
        if (int(time) >= 4) and (int(time) <= 30):
            self._sendConfigCommand("spanning-tree vlan " + range + " forward-time " + time)
            return "Spanning tree VLAN with range {0} and forward time {1} has been set".format(range, time)
        else:
            raise ValueError("Incorrect time. Should be in range from 4 to 30 sec")

    def setSpanningTreeVlanHelloTime(self, range, time):
        """
        Sets spanning tree VLAN hello time
        :param range: vlan range, examples: 0-3,5,7-9
        :param time: hello time. Allowed values [1-10]
        :return: success message
        :rtype: string
        """
        if (int(time) >= 1) and (int(time) <= 10):
            self._sendConfigCommand("spanning-tree vlan " + range + " hello-time " + time)
            return "Spanning tree VLAN with range {0} and hello time {1} has been set".format(range, time)
        else:
            raise ValueError("Incorrect time. Should be in range from 1 to 10 sec")

    def setSpanningTreeVlanMaxAge(self, range, age):
        """
        Sets spanning tree VLAN max age
        :param range: vlan range, examples: 0-3,5,7-9
        :param age: max age. Allowed values [6-40]
        :return:
        """
        if (int(age) >= 6) and (int(age) <= 40):
            self._sendConfigCommand("spanning-tree vlan " + range + " max-age " + age)
            return "Spanning tree VLAN with range {0} and max age {1} has been set".format(range, age)
        else:
            raise ValueError("Incorrect max age. Should be in range from 6 to 40")

    def setSpanningTreeVlanPriority(self, range, priority):
        """
        Set spanning tree VLAN priority according to the flow
        :param range: vlan range, examples: 0-3,5,7-9
        :param priority: priority
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("spanning-tree vlan " + range + " priority " + priority)
        return "Spanning tree VLAN with range {0} and priority {1} has been set".format(range, priority)

    def setSpanningTreeVlanRoot(self, range, mode='primary', diameter=0):
        """
        Sets spanning tree VLAN root
        :param range: vlan range, examples: 0-3,5,7-9
        :param mode: [PRIMARY|SECONDARY]
        :param diameter: allowed values [2-7]
        :return: success message
        :rtype: string
        """
        if mode in ['primary', 'secondary']:
            if diameter == 0:
                self._sendConfigCommand("spanning-tree vlan " + range + " root " + mode)
                return "Spanning tree VLAN with range {0} and mode {1} has been set".format(range, mode)
            else:
                if (int(diameter) >= 2) and (int(diameter) <= 7):
                    self._sendConfigCommand(
                        "spanning-tree vlan " + range + " root " + mode + " diameter " + str(diameter))
                    return "Spanning tree VLAN with range {0}, mode {1} and diameter {2} has been set".format(range,
                                                                                                              mode,
                                                                                                              diameter)
                else:
                    raise ValueError("Incorrect diameter. Should be in range from 2 to 7")
        else:
            raise ValueError("Incorrect mode. Should be either primary or secondary")

        #    def addVPCDomain(self, id, ip, system_priority, role_priority):
        #        self._sendConfigCommand("vpc domain " + str(id))
        #        self._sendConfigCommand("system-priority " + str(system_priority))
        #        self._sendConfigCommand("role priority " + str(role_priority))
        #        self._sendConfigCommand("peer-keepalive destination " + ip + " vrf management")
        #        self._sendConfigCommand("auto-recovery")
        #        self.exit()
        #        return "Added VPC domain!"

    def setVpc(self, vpc):
        """
        Sets VPC
        :param vpc:
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand("vpc {0}".format(vpc))

        return "VPC has been set to {0}".format(vpc)

    def configureQos(self, class_map=list(), policy_map=list(), service_policy=list()):
        """
        Configures quality of service method
        :param class_map:
        :param policy_map:
        :param service_policy:
        :return:
        """
        qos = QualityOfService()

        prepared_commands = qos.getCommands(class_map=class_map, policy_map=policy_map,
                                            service_policy=service_policy)
        self._sendCommandsList(prepared_commands)

    def clockTimezone(self, timezone, offset_hours, offset_minutes):
        """
        Sets clock timezone
        :param timezone: example: PST
        :param offset_hours: example: -7
        :param offset_minutes: example: 00
        :return: success message
        :rtype: string
        """
        self._sendConfigCommand('clock timezone {0} {1} {2}'.format(timezone, offset_hours, offset_minutes))
        return "Clock timezone has been set!"
       
    def disableLogging(self, target):
        """
        Disables logging according to the flow
        :param target: [bootflash|console|distribute|event|ip|level|logfile|message|module|monitor|server|source-interface|timestamp]
        :return: success message
        :rtype: string
        """
        if not target in ['bootflash',
                          'console',
                          'distribute',
                          'event',
                          'ip',
                          'level',
                          'logfile',
                          'message',
                          'module',
                          'monitor',
                          'server',
                          'source-interface',
                          'timestamp']:
            raise ValueError('Target is not in the list of allowed values')
        self._sendConfigCommand('no logging {0}'.format(target))
        return "Logging has been disabled!"

    def configureLogging(self, target):
        """
        Enables logging according to the flow
        :param target: [bootflash|console|distribute|event|ip|level|logfile|message|module|monitor|server|source-interface|timestamp]
        :return: success message
        :rtype: string
        """
        if not target in ['bootflash',
                          'console',
                          'distribute',
                          'event',
                          'ip',
                          'level',
                          'logfile',
                          'message',
                          'module',
                          'monitor',
                          'server',
                          'source-interface',
                          'timestamp']:
            raise ValueError('Target is not in the list of allowed values')
        self._sendConfigCommand('logging {0}'.format(target))
        return "Logging has been enabled!"       