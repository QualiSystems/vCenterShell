__author__ = 'ini'



def doNothing(session):
    pass

def sendUsername(session):
    return session.sendCommand(session._username)


def sendPassword(session):
    return session.sendCommand('PASSWD')
