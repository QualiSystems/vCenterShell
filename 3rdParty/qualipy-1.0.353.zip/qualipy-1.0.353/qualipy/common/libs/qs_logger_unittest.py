import os
import sys
import tempfile
import shutil
import time

sys.path.append("../../")

# from qualipy.common.cisco.cisco_handler_factory import *

import unittest
# import json
from qualipy.common.libs import qs_logger

LOGGER_CONFIG_CONTENT = """
[Logging]
LOG_LEVEL='ERROR'
LOG_FORMAT= '%(asctime)s [%(levelname)s]: %(name)s %(module)s - %(funcName)-20s %(message)s'
TIME_FORMAT= '%d-%b-%Y--%H-%M-%S'
"""


class TestQSLogger(unittest.TestCase):
    @staticmethod
    def setUpClass():
        print 'QSLogger Test start'

    @staticmethod
    def tearDownClass():
        print 'QSLogger Test end'

    def setUp(self):
        self._config_file = tempfile.NamedTemporaryFile(mode="w+r")
        self._config_file.write(LOGGER_CONFIG_CONTENT)
        self._config_file.flush()
        self._log_dir = tempfile.mkdtemp()
        # print("LogDir", self._log_dir)
        self._config_file.write("LOG_PATH='%s'" % self._log_dir)
        self._config_file.flush()
        # print("ConfigFile", self._config_file.name)
        os.environ['QS_CONFIG'] = self._config_file.name

    def tearDown(self):
        # pass
        self._config_file.close()
        shutil.rmtree(self._log_dir)

    def testLogPath(self):
        file_exist = False
        file = qs_logger.getLogPath(qs_logger.getQSLogger('test', handler_name='test'))
        if os.path.isfile(file):
            file_exist = True
        self.assertTrue(file_exist)

    def testLoggerSameObject(self):
        self.assertEqual(qs_logger.getQSLogger('test'), qs_logger.getQSLogger('test'))

    def testLoggerReccord(self):
        logger = qs_logger.getQSLogger('test', handler_name='test')
        message = 'Test Message'
        logger.error(message)
        is_message = False
        file = qs_logger.getLogPath(logger)
        if file:
            f = open(file, 'r')
            for line in f.readlines():
                if message in line:
                    is_message = True
            f.close()
        self.assertTrue(is_message)


if __name__ == '__main__':
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True:  # raised by sys.exit(True) when tests failed
            pass
