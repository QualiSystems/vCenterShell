__author__ = 'yar'
import copy
import traceback

from qualipy.common.libs.ssh_manager import SSHManager
from qualipy.common.libs.console_manager import ConsoleManager
from qualipy.common.libs.telnet_manager import TelnetManager
from qualipy.common.libs.file_manager import FileManager


class ConnectionManager:
    CONNECTION_ORDER = ['console', 'ssh', 'telnet']
    CONNECTION_MAP = {'ssh': SSHManager, 'telnet': TelnetManager, 'console': ConsoleManager, 'file': FileManager}
    KEY_MAP = {'console': ['console_server_ip', 'console_server_user', 'console_server_password', 'console_port'],
               'file': ['filename'],
               'common': ['username', 'password', 'host']}
    PROMPT_RE = '.*>|.*#|\(config.*\)#'

    def __init__(self, connection_type='auto', logger=None, **kwargs):
        self._connection_type = connection_type.lower()
        self._logger = logger
        self._connection_order = copy.deepcopy(ConnectionManager.CONNECTION_ORDER)
        self._connection_map = copy.deepcopy(ConnectionManager.CONNECTION_MAP)
        self._connection_params = kwargs

    def _checkParams(self, conn_type):
        params = self._connection_params
        if conn_type in self.KEY_MAP.keys():
            keys = self.KEY_MAP[conn_type]
        else:
            keys = self.KEY_MAP['common']

        for key in keys:
            if key not in params.keys() or not params[key]:
                return False
        return True

    def _genericConnection(self, conn_type, prompt):
        self._logger.info('type - {0}'.format(conn_type))
        connection = None
        if self._checkParams(conn_type) and conn_type in self._connection_map.keys():
            session = self._connection_map[conn_type](logger=self._logger, **self._connection_params)
            try:
                session.connect(expected_str=prompt)
                # session.connect(expected_str=self.PROMPT_RE)
                connection = session
            except Exception as err:
                error_str = "Exception: " + str(err) + '\n'
                error_str += '-' * 60 + '\n'
                error_str += traceback.format_exc()
                error_str += '-' * 60
                if self._logger:
                    self._logger.error(error_str)
                raise Exception('Console Manager', error_str)
        else:
            raise Exception('Incorrect connection type')

        return connection

    def getSession(self, prompt=PROMPT_RE):
        connection = None
        connection_type = self._connection_type
        self._logger.info('Connection type - {0}'.format(self._connection_type))
        if connection_type is not 'auto':
            connection = self._genericConnection(connection_type, prompt)
        else:
            for conn_type in self._connection_order:
                session = self._genericConnection(conn_type, prompt)
                if session:
                    connection = session
                    break
        if not connection:
            self._logger.error('Connection failed')
            raise Exception('Connection failed')
        self._logger.info("Connected")
        return connection
