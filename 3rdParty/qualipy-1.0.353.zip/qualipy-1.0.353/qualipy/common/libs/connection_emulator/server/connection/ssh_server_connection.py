__author__ = 'pava'

import socket
import traceback

import threading
from binascii import hexlify
import os

import paramiko
from paramiko.py3compat import b, u, decodebytes
from paramiko.common import MSG_NAMES

from server_connection import *

class ParamikoServer(paramiko.ServerInterface):
    # 'data' is the output of base64.encodestring(str(key))
    # (using the "user_rsa_key" files)
    DATA = (b'AAAAB3NzaC1yc2EAAAABIwAAAIEAyO4it3fHlmGZWJaGrfeHOVY7RWO3P9M7hp'
            b'fAu7jJ2d7eothvfeuoRFtJwhUmZDluRdFyhFY/hFAh76PJKGAusIqIQKlkJxMC'
            b'KDqIexkgHAfID/6mqvmnSJf0b5W8v5h2pI/stOSwTQ+pxVhwJ9ctYDhRSlF0iT'
            b'UWT10hcuO4Ks8=')
    GOOD_PUB_KEY = paramiko.RSAKey(data=decodebytes(DATA))

    def __init__(self):
        self.event = threading.Event()

    def check_channel_request(self, kind, chanid):
        if kind == 'session':
            return paramiko.OPEN_SUCCEEDED
        return paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

    def check_auth_password(self, username, password):
        if (username == 'admin') and (password == 'admin'):
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def check_auth_publickey(self, username, key):
        print('Auth attempt with key: ' + u(hexlify(key.get_fingerprint())))
        if (username == 'admin') and (key == ParamikoServer.GOOD_PUB_KEY):
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def check_auth_gssapi_with_mic(self, username,
                                   gss_authenticated=paramiko.AUTH_FAILED,
                                   cc_file=None):
        """
        .. note::
            We are just checking in `AuthHandler` that the given user is a
            valid krb5 principal! We don't check if the krb5 principal is
            allowed to log in on the server, because there is no way to do that
            in python. So if you develop your own SSH server with paramiko for
            a certain platform like Linux, you should call ``krb5_kuserok()`` in
            your local kerberos library to make sure that the krb5_principal
            has an account on the server and is allowed to log in as a user.
        .. seealso::
            `krb5_kuserok() man page
            <http://www.unix.com/man-page/all/3/krb5_kuserok/>`_
        """
        if gss_authenticated == paramiko.AUTH_SUCCESSFUL:
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def check_auth_gssapi_keyex(self, username,
                                gss_authenticated=paramiko.AUTH_FAILED,
                                cc_file=None):
        if gss_authenticated == paramiko.AUTH_SUCCESSFUL:
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def enable_auth_gssapi(self):
        UseGSSAPI = True
        GSSAPICleanupCredentials = False
        return UseGSSAPI

    def get_allowed_auths(self, username):
        return 'gssapi-keyex,gssapi-with-mic,password,publickey'

    def check_channel_shell_request(self, channel):
        self.event.set()
        return True

    def check_channel_pty_request(self, channel, term, width, height, pixelwidth,
                                  pixelheight, modes):
        return True


class ServerConnectionSSH(ServerConnection):
    def __init__(self, host, port):
        self._host = host
        self._port = port

        paramiko.util.log_to_file('demo_server.log')

        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        print 'Socket create complete!'

        try:
            self._server_socket.bind((host, port))
        except socket.error as error:
            error_str =  "Exception: " + str(error) + '\n'

            error_str += '-' * 60 + '\n'
            error_str += traceback.format_exc()
            error_str += '-' * 60

            raise Exception('Connection Emulator', error_str)

        print 'Socket bind complete!'

        self._server_socket.listen(100)
        print 'Socket now listening!'

        rsa_key_path = os.path.dirname(os.path.realpath(__file__)) + r'\rsa.key'
        self._host_key = paramiko.RSAKey(filename=rsa_key_path)

    def getAcceptSocket(self):
        connection, address = self._server_socket.accept()

        try:
            transport = paramiko.Transport(connection, gss_kex=True)
            transport.set_gss_host(socket.getfqdn(""))

            try:
                transport.load_server_moduli()
            except:
                print('(Failed to load moduli -- gex will be unsupported.)')
                return None

            transport.add_server_key(self._host_key)
            server = ParamikoServer()

            try:
                transport.start_server(server=server)
            except paramiko.SSHException:
                print('*** SSH negotiation failed.')
                return None

            # wait for auth
            channel = transport.accept(200)

            if channel is None:
                print('*** No channel.')
                return None

            print('Authenticated!')

            server.event.wait(10)
            if not server.event.is_set():
                print('*** Client never asked for a shell.')
                return None

        except Exception as e:
            print('*** Caught exception: ' + str(e.__class__) + ': ' + str(e))
            traceback.print_exc()
            try:
                transport.close()
            except:
                pass

            return None

        print 'Connected with ' + address[0] + ':' + str(address[1])

        return (channel, address)