__author__ = 'pava'

from abc import ABCMeta
from abc import abstractmethod

class ServerConnection:
    __metaclass__ = ABCMeta

    @abstractmethod
    def getAcceptSocket(self):
        pass
