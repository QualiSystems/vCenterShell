__author__ = 'pava'

from qualipy.common.libs.parameters_service.command_template import *

class ServerCommand:
    def __init__(self, commands_template, commands_responses = [], need_prompt = [], need_scope = None):
        self._need_scope = need_scope

        self._commands = []
        if isinstance(commands_template, list):
            self._commands += commands_template
        elif isinstance(commands_template, CommandTemplate):
            self._commands = [commands_template]
        else:
            raise Exception('ServerCommand: wrong command template parameter in constructor!')

        self._responces = []
        if isinstance(commands_responses, list):
            self._responces += commands_responses
        elif isinstance(commands_responses, basestring):
            self._responces = [commands_responses]

        self._need_promnt = []
        if isinstance(need_prompt, list):
            self._need_promnt += need_prompt
        elif isinstance(need_prompt, bool):
            self._need_promnt = [need_prompt]

        self._current_command_index = 0

    def getCommandTemplate(self):
        return self._commands[self._current_command_index]

    def getCommandResponce(self):
        if self._current_command_index > (len(self._responces) - 1):
            return ''

        return self._responces[self._current_command_index]

    def isNeedPrompt(self):
        if self._current_command_index > (len(self._need_promnt) - 1):
            return True

        return self._need_promnt[self._current_command_index]

    def isNeedScope(self):
        return self._need_scope != None

    def getScope(self):
        return self._need_scope

    def incrementCommandIndex(self):
        self._current_command_index += 1

    def resetCommandIndex(self):
        self._current_command_index = 0

    def getCurrentIndex(self):
        return self._current_command_index

    def isCommandsLeft(self):
        return len(self._commands) > self._current_command_index
