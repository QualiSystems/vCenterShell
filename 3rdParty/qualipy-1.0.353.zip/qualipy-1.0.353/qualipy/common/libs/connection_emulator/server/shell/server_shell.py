__author__ = 'pava'

import re

from abc import ABCMeta
from abc import abstractmethod

from qualipy.common.libs.parameters_service.parameters_service import *
from qualipy.common.libs.parameters_service.command_template import *

class ServerShell:
    __metaclass__ = ABCMeta

    def __init__(self):
        self._buffer_size = 1024
        self._end_command_pattern = re.compile(r'\r|\r\n')

        self._new_line = '\r\n'
        self._prompt_name_end = '# '

    def readCommand(self, data_str):
        command_match = self._end_command_pattern.search(data_str)
        if command_match is not None:
            command = data_str[:command_match.span()[0]]

            print command
            return (True, command)

        return False, ''

    def _readingCommands(self, connection_socket):
        command_str = ''
        while True:
            command_str += connection_socket.recv(self._buffer_size)
            command_tuple = self.readCommand(command_str)
            command_str = ''

            if command_tuple[0]:
                if self._isExit(command_tuple[1]):
                    break

                output_buffer = self._evaluateCommand(command_tuple[1])
                connection_socket.sendall(output_buffer)

        connection_socket.close()

    def _evaluateCommand(self, command):
        commands_list = command.split(' ')

        if (self._current_server_command is None) and \
                (not commands_list[0] in self.COMMANDS_LIST):
            return 'Command not found!'

        if (self._current_server_command is None):
            self._current_server_command = self.COMMANDS_LIST[commands_list[0]]

        if self._current_server_command.isNeedScope():
            if not self._compareScope(self._current_server_command.getScope()):
                self._current_server_command.resetCommandIndex()
                self._current_server_command = None
                return self._getErrorWrongScope()

        responce_buffer = ''
        try:
            params_list = []
            if self._current_server_command.getCurrentIndex() == 0:
                params_list = [] if len(commands_list) == 1 else commands_list[1:]
            else:
                params_list += commands_list

            responce_buffer = ParametersService.getValidateList(self._current_server_command.getCommandTemplate(),
                                                                params_list)
        except Exception, err:
            self._current_server_command.resetCommandIndex()
            self._current_server_command = None
            return str(err) + self._promt_name

        self._changeHostname(commands_list)

        responce_buffer += self._new_line + self._current_server_command.getCommandResponce()

        if self._current_server_command.isNeedPrompt():
            responce_buffer += self._promt_name

        self._current_server_command.incrementCommandIndex()

        if not self._current_server_command.isCommandsLeft():
            self._current_server_command.resetCommandIndex()
            self._current_server_command = None

        return responce_buffer

    @abstractmethod
    def environmentLoop(self, connection_socket):
        pass

    @abstractmethod
    def _changeHostname(self, commands_list):
        pass

    @abstractmethod
    def _compareScope(self, need_scope):
        pass

    @abstractmethod
    def _getErrorWrongScope(self):
        pass

    def _isExit(self, command):
        return 'exit' == command
