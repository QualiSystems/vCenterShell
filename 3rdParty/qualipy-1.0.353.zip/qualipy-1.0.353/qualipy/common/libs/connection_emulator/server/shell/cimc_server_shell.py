__author__ = 'pava'

from server_shell import *
from server_command import *

class CimcServerShell(ServerShell):
    COMMANDS_LIST = {
        'scope': ServerCommand(CommandTemplate('scope {0}', [r'snmp$|cimc$|$chassis'], ['Invalid Command!'])),
        'top': ServerCommand(CommandTemplate('top')),
        'power': ServerCommand(CommandTemplate('power {}', [r'off$|cycle$'], ['Invalid Command!'])),
        'reboot': ServerCommand([CommandTemplate('reboot'),
                               CommandTemplate('{0}', [r'yes$|no$'], ['Wrong command (need \'yes\' | \'no\')!'])],
                              'All data on the drive will be lost.  Enter \'yes\' to confirm -->',
                              False),
        'delete-virtual-cdrive': ServerCommand([CommandTemplate('delete-virtual-cdrive'),
                                                CommandTemplate('{0}', [r'y$|n$'], ['Wrong command (need \'y\' | \'n\')!'])],
                                               'This operation will reboot the BMC.\r\n'
                                               'Continue?[y|n] ',
                                               False),
    }

    def __init__(self):
        ServerShell.__init__(self)

        self._root_hostname = 'g8y3e-test'
        self._promt_name = self._new_line + self._root_hostname + self._prompt_name_end

        self._current_server_command = None

    def _changeHostname(self, commands_list):
        if 'scope' == commands_list[0]:
            self._promt_name = self._new_line + self._root_hostname + '(' + commands_list[1] + ')' + \
                               self._prompt_name_end
        elif 'top' == commands_list[0]:
            self._promt_name = self._new_line + self._root_hostname + self._prompt_name_end

    def _compareScope(self, need_scope):
        need_scope = '(' + need_scope + ')'
        return need_scope in self._promt_name

    def environmentLoop(self, connection_socket):
        connection_socket.send('Welcome to the server. Type something and hit enter\r\n' + self._promt_name)

        self._readingCommands(connection_socket)

    def isExit(self, command):
        return 'exit' == command

    def _getErrorWrongScope(self):
        return 'Wrong scope!'