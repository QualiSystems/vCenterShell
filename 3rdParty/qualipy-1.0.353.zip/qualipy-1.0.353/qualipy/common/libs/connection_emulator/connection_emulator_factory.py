__author__ = 'pava'

from server.connection.ssh_server_connection import *

from server.shell.cimc_server_shell import *

class ConnectionEmulatorFactory:
    sessions_map = {
        'ssh': ServerConnectionSSH
    }

    shells_map = {
        'cimc': CimcServerShell
    }

    @staticmethod
    def create(shell_name, session_name):
        if (shell_name in ConnectionEmulatorFactory.shells_map) and \
                (session_name in ConnectionEmulatorFactory.sessions_map):
            pass
