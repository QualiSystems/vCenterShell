__author__ = 'pava'

import sys
sys.path.append("../../../../")

import socket, ssl
import traceback
import re

from thread import *

from server.connection.ssh_server_connection import *
from server.shell.cimc_server_shell import *

class ConnectionEmulator:
    def __init__(self, host='127.0.0.1', port=22):
        self._is_running = True
        self._server_connection = ServerConnectionSSH(host, port)
        self._server_shell = CimcServerShell()

    def startListening(self):
        while self._isRunning():
            connection_tuple = self._server_connection.getAcceptSocket()
            if not connection_tuple is None:
                connection_socket = connection_tuple[0]
                start_new_thread(self._server_shell.environmentLoop, (connection_socket,))

    def _isRunning(self):
        return self._is_running

if __name__ == '__main__':
   connection = ConnectionEmulator()
   connection.startListening()