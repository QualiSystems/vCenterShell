__author__ = 'eric.r'
import functools
import sys
import inspect
import os
import codecs

# @DriverFunction annotation
# Base classes to use when creating a class callable from Driver Builder
# See ../examples/example_drivers.py


# Based on http://blog.dscpl.com.au/2014/01/decorators-which-accept-arguments.html
# Don't delete ee!
def ee(w1):
    def d(f):
        def w2(*args2):
            return f(*args2)
        w2.qargspec=inspect.getargspec(f)
        return w2
    return d

def DriverFunction(zapped=None, tags="", alias="", description="", extraMatrixRows={}):
    if zapped is None:
        return functools.partial(DriverFunction, tags=tags, alias=alias, description=description, extraMatrixRows=extraMatrixRows)
    @ee
    def w3(wrapped, instance, args, kwargs):
        return wrapped(*args, **kwargs)
    rv=w3(zapped)
    rv.tags=tags
    rv.alias=alias
    rv.description=description
    rv.extraMatrixRows=extraMatrixRows
    return rv


class base_driver:
    sessionid2instance={}

class base_resource_driver(base_driver):
    def __init__(self, sessionid, matrixJSON):
        self.sessionid=sessionid
        base_driver.sessionid2instance[sessionid] = self
        print "base resource driver constructor: "+str(base_driver.sessionid2instance)
        self.Init(matrixJSON)

    def getSessionId(self):
        return self.sessionid

    @DriverFunction
    def Init(self, matrixJSON):
        pass

    @DriverFunction
    def ResetDriver(self, matrixJSON):
        pass

    @DriverFunction
    def EndSession(self, matrixJSON):
        pass

class base_service_driver(base_driver):
    def __init__(self, sessionid, matrixJSON):
        self.sessionid=sessionid
        base_driver.sessionid2instance[sessionid] = self
        self.Init(matrixJSON)

    @DriverFunction
    def Init(self, matrixJSON):
        pass

    @DriverFunction
    def ResetDriver(self, matrixJSON):
        pass

    @DriverFunction
    def EndSession(self, matrixJSON):
        pass

class base_topology_driver(base_driver):
    def __init__(self, sessionid, matrixJSON):
        self.sessionid=sessionid
        base_driver.sessionid2instance[sessionid] = self
        self.Init(matrixJSON)

    # Note: topology drivers don't have Init but we must generate it
    @DriverFunction
    def Init(self, matrixJSON):
        pass

    @DriverFunction
    def Setup(self, matrixJSON):
        pass

    @DriverFunction
    def Teardown(self, matrixJSON):
        pass

    @DriverFunction
    def EndSession(self, matrixJSON):
        pass

