import sys
import os
import unittest
import tempfile
sys.path.append("../../")
from qualipy.common.libs.qs_config_parser import QSConfigParser

DEFAULT_CONFIG_CONTENT="""
[TestSection1]
TEST_KEY1='Hello'
test_key2=''
[TestSection2]
TEST_KEY3='Config'
TEST_KEY4='Test'
"""

class TestQSConfigParser(unittest.TestCase):
    @staticmethod
    def setUpClass():
        print 'QSLogger Test start'

    @staticmethod
    def tearDownClass():
        print 'QSLogger Test end'

    def setUp(self):
        self._config_file=tempfile.NamedTemporaryFile(mode="w+r")
        self._config_file.write(DEFAULT_CONFIG_CONTENT)
        self._config_file.flush()
        os.environ['QS_CONFIG']=self._config_file.name

    def tearDown(self):
        self._config_file.close()

    def testConfigSection1(self):
        self.assertEqual(QSConfigParser.getSetting('TestSection1', 'TEST_KEY1'), 'Hello')

    def testConfigSection2(self):
        self.assertEqual(QSConfigParser.getSetting('TestSection2', 'TEST_KEY3'), 'Config')

    def testEmptyKey(self):
        self.assertEqual(QSConfigParser.getSetting('TestSection1', 'test_key2'), '')

    def testKeyDoesNotExist(self):
        self.assertEqual(QSConfigParser.getSetting('TestSection1', 'TEST_KEY4'), None)

    def testSectionDoesNotExist(self):
        self.assertEqual(QSConfigParser.getSetting('TestSection4', 'TEST_KEY4'), None)


if __name__ == '__main__':
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True:  # raised by sys.exit(True) when tests failed
            pass

