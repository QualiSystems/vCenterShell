__author__ = 'g8y3e'

from abc import ABCMeta
import time
import re
import sys


class SessionManager:
    TIMEOUT_ERR = 'timeout'
    __metaclass__ = ABCMeta

    def __init__(self, handler=None, username=None, password=None, host=None, port=None,
                 timeout=60, newline='\r', logger=None, **kwargs):
        self._handler = handler
        self._logger = logger
        self._prompt = '.*[>#] *$'
        self._newline = '\r'
        self._host = host
        self._port = port
        self._username = username
        self._password = password
        self._newline = newline
        self._timeout = timeout
        self._current_send_string = ''
        if 'display' in kwargs.keys():
            self._display = kwargs['display']
        else:
            self._display = False

    def __del__(self):
        self.disconnect()

    def turnOnDisplay(self):
        self._display = True

    def connect(self, expected_str=''):
        pass

    def disconnect(self):
        pass

    def _send(self, command_string):
        pass

    def _receive(self, timeout=None):
        pass

    def sendline(self, send_string):
        """Saves and sends the send string provided"""
        self._logger.info(send_string)
        if send_string == '':
            send_string = '\n'
        self._current_send_string = send_string
        self._send(self._current_send_string + self._newline)

    def reconnect(self, retries_count=5, sleep_time=15):
        self._logger.info("Reconnect, retries: {0}, sleep_time: {1}".format(retries_count, sleep_time))
        for retry in retries_count:
            try:
                self.disconnect()
                self.connect(self._prompt)
                return
            except Exception as e:
                self._logger.error(e)
                time.sleep(sleep_time)
                pass
        raise Exception('Session manager, can not connect')

    def hwExpect(self, cmd, expected_str=None, timeout=30):
        """Send 'enter' character to remote session and expect to get prompt
        send command and expect for prompt
        aggregate output buffer and return it.

        :param cmd: - command to send
        :param expected_str: - expect for specific string in session output (optional, default is self._prompt)

        :param timeout: - timeout for expect (optional)
        :return: out - channel output after command sent
        """
        self._logger.info("Command: {0}, Expected_str: {1}, timeout: {2}".format(cmd, expected_str, timeout))
        out = ''
        self._timeout = timeout
        console_expect = ['Username:|Login:',
                          self._prompt,
                          'closed by remote host',
                          'continue connecting',
                          'Got termination signal',
                          'Broken pipe',  # failed to send command, retry  'Write failed: Broken pipe'
                          '[Yy]es',  # send configurmation if yes/no provided
                          'More',
                          'Password:',
                          ]

        # self._session_handler.turnOnDisplay()
        self.sendline('\n')
        for retry in range(7):
            out_ex = self.expect(console_expect, self._timeout)
            i = out_ex[0]
            out += out_ex[1]
            if i == 0:
                self.sendline(self._username)
            elif i == 1:
                self.sendline(cmd)
                if not expected_str is None:
                    ex_out = self.expect(console_expect, self._timeout)
                else:
                    ex_out = self.expect(self._prompt, self._timeout)[1]
                if ex_out == -1:
                    out += ''
                else:
                    out += ex_out[1]
                if ex_out[0] == 1:
                    break
            elif i == 2:
                self._logger.error('Connection closed by remote host.')
                raise Exception('console_manager:_hwExpect', 'Session closed by remote host')
                self.reconnect()
                return 0

            elif i == 3:
                if retry < 5:
                    self.sendline('yes')
                else:
                    self.sendline('')

            elif i == 4:
                if retry < 3:
                    self.sendline('')
                    self._logger.error('Timeout while getting prompt. Wait 5 seconds and retry.')
                    time.sleep(5)

                elif 2 < retry < 5:
                    self._logger.info('Timeout while getting prompt on device, sending Ctrl+C ...')
                    self.sendcontrol('c')
                    self._logger.info('Wait 10 seconds and retry to get prompt')
                    time.sleep(10)
                else:
                    self.reconnect()
                    return 0

            elif i == 5:
                self.sendline(cmd)
                return None
            elif i == 6:
                self.sendline('yes')
            elif i == 7:
                self.sendline('')
            elif i == 8:
                self.sendline(self._password)

        self.sendline('')
        ex_out = self.expect(self._prompt)
        if ex_out != -1:
            out += ex_out[1]
        else:
            out += ''
            # out += self.expect(self._prompt)[1]
        # out += self._current_output_clean
        # self._logger.info(out)
        return out

    def expect(self, re_strings='', timeout=None):
        """This function takes in a regular expression (or regular expressions)
        that represent the last line of output from the server.  The function
        waits for one or more of the terms to be matched.  The regexes are
        matched using expression \n<regex>$ so you'll need to provide an
        easygoing regex such as '.*server.*' if you wish to have a fuzzy match.
        Keyword arguments:
        re_strings -- Either a regex string or list of regex strings that
                      we should expect.  If this is not specified, then
                      EOF is expected (i.e. the shell is completely closed
                      after the exit command is issued)
        timeout -- Timeout in seconds.  If this timeout is exceeded, then an
                   exception is raised.
        Returns:
        - EOF: Returns -1
        - Regex String: When matched, returns 0
        - List of Regex Strings: Returns the index of the matched string as
                                 an integer
        Raises:
            exception on timeout
        """
        # Create an empty output buffer
        current_output = ''

        # This function needs all regular expressions to be in the form of a
        # list, so if the user provided a string, let's convert it to a 1
        # item list.
        if len(re_strings) != 0 and isinstance(re_strings, str):
            re_strings = [re_strings]

        # Loop until one of the expressions is matched or loop forever if
        # nothing is expected (usually used for exit)
        retry = 0
        while (not len(re_strings) == 0 and retry < 3):
            retry += 1
            for re_string in re_strings:
                res = re.match('.*' + re_string, current_output, re.DOTALL)
                if res:
                    break
            if res:
                break
            else:
                time.sleep(0.2)

            # Read some of the output
            # try:
            buffer = self._receive(timeout)
            # except Exception, err:
            #     if str(err).find("Timeout") != -1:
            #         return self.TIMEOUT_ERR

            # If we have an empty buffer, then the SSH session has been closed
            if len(buffer) == 0:
                break

            # Strip all ugly \r (Ctrl-M making) characters from the current
            # read
            buffer = buffer.replace('\r', '')

            # Display the current buffer in realtime if requested to do so
            # (good for debugging purposes)
            if self._display:
                sys.stdout.write(buffer)
                sys.stdout.flush()

            # Add the currently read buffer to the output
            current_output += buffer

        # Grab the first pattern that was matched
        if len(re_strings) != 0:
            found_pattern = [(re_index, re_string)
                             for re_index, re_string in enumerate(re_strings)
                             if re.match('.*' + re_string,
                                         current_output, re.DOTALL)]

        # print("Cur output fdfdf   ---  "+current_output)
        # self._current_output_clean = current_output

        ## Clean the output up by removing the sent command
        # if len(self.#_string) != 0:
        #    current_output_clean = (
        #        current_output_clean.replace(
        #            self.current_send_string + '\n', ''))

        # Reset the current send string to ensure that multiple expect calls
        # don't result in bad output cleaning
        # self._current_send_string = ''

        # Clean the output up by removing the expect output from the end if
        # requested and save the details of the matched pattern
        if not len(re_strings) == 0 and not len(found_pattern) == 0:
            current_output = (
                re.sub(found_pattern[0][1] + '$', '',
                       current_output))
            # self.last_match = found_pattern[0][1]
            # return_list = [found_pattern[0][0], current_output]
            # print(return_list)
            return [found_pattern[0][0], current_output]
        else:
            # We would socket timeout before getting here, but for good
            # measure, let's send back a -1
            return -1
