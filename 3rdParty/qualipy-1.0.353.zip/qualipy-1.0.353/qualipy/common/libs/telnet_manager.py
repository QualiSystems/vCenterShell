__author__ = 'g8y3e'

import telnetlib
import re
import traceback
import time

from session_manager import SessionManager


class TelnetManager(SessionManager):
    def __init__(self, *args, **kwargs):
        SessionManager.__init__(self, telnetlib.Telnet(), *args, **kwargs)

        # self._username = username
        # self._password = password

        # self._host = host
        if self._port is None:
            self._port = 23

        # self._timeout = timeout
        # self._newline = newline
        #
        # self._more_line_re_str = '-- {0,1}[Mm]ore {0,1}--'
        # self._more_line_pattern = re.compile(self._more_line_re_str)
        #
        # self.prompt = ''

    def connect(self, expected_str=''):
        SessionManager.connect(self, expected_str)
        if expected_str:
            self._prompt = expected_str
        try:
            self._handler.open(self._host, self._port, self._timeout)

            if self._username != None:
                output = self._handler.expect(['([Ll]ogin|[Uu]sername):'], timeout=self._timeout)
                self._handler.write(self._username + self._newline)

            if self._password != None:
                output = self._handler.expect(['[Pp]assword:'], timeout=self._timeout)
                self._handler.write(self._password + self._newline)
            data = self._handler.expect([expected_str])

        except Exception, err:
            error_str = "Exception: " + str(err) + '\n'

            error_str += '-' * 60 + '\n'
            error_str += traceback.format_exc()
            error_str += '-' * 60
            if self._logger:
                self._logger.error(error_str)

            raise Exception('Telnet Manager', error_str)

    def disconnect(self):
        SessionManager.disconnect(self)
        self._handler.close()

    def _send(self, command_string):
        self._handler.write(command_string)

    def _receive(self, timeout=None):
        timeout = timeout if timeout else self._timeout
        return self._handler.read_very_eager()




# def sendCommand(self, command, re_string='', timeout=None):
    #     SessionManager.sendCommand(self, command, re_string, timeout)
    #     if command != None:
    #         self._handler.write(command + self._newline)
    #
    #     return self._readOutBuffer(re_string, timeout)

    # def _readOutBuffer(self, re_string='', timeout=None):
    #     timeout = timeout if timeout else self._timeout
    #
    #     expect_list = [re_string, self._more_line_re_str]
    #     input_buffer = ''
    #     try:
    #         if len(re_string) == 0:
    #             input_buffer = self._handler.read_very_eager()
    #         else:
    #             response_tuple = self._readRecvData(expect_list, timeout)
    #             input_buffer += response_tuple[0]
    #
    #             while response_tuple[1] != None:
    #                 response_tuple = self._readRecvData(expect_list, timeout)
    #                 input_buffer += response_tuple[0]
    #
    #     except Exception, err:
    #         error_str = "Exception: " + str(err) + '\n'
    #         import traceback, sys
    #
    #         error_str += '-' * 60 + '\n'
    #         error_str += traceback.format_exc()
    #         error_str += '-' * 60
    #         if self._logger:
    #             self._logger.error(error_str)
    #
    #     return self._normalizeBuffer(input_buffer)
    #
    # def _readRecvData(self, expect_list, timeout):
    #     response_tuple = self._handler.expect(expect_list, timeout)
    #     response = response_tuple[2]
    #
    #     more_match = self._more_line_pattern.search(response)
    #     if more_match != None:
    #         self._handler.write(self._newline)
    #         more_pos = more_match.span()
    #         response = response[0:more_pos[0]] + response[more_pos[1]:]
    #
    #     return (response, more_match)

    # def _normalizeBuffer(self, input_buffer):
    #     """
    #     Method for clear color fro input_buffer and special characters
    #     """
    #
    #     color_pattern = re.compile('\[[0-9]+;{0,1}[0-9]+m|\[[0-9]+m|\b|' + chr(27))  # 27 - ESC character
    #
    #     result_buffer = ''
    #
    #     match_iter = color_pattern.finditer(input_buffer)
    #
    #     current_index = 0
    #     for match_color in match_iter:
    #         match_range = match_color.span()
    #         result_buffer += input_buffer[current_index:match_range[0]]
    #         current_index = match_range[1]
    #
    #     result_buffer += input_buffer[current_index:]
    #
    #     return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\xff]', '', result_buffer)
    #
    # def expect(self, re_strings='', timeout=None):
    #     SessionManager.expect(self, re_strings, timeout)
    #     if isinstance(re_strings, str):
    #         re_strings = [re_strings]
    #     try:
    #         out = self._handler.expect(re_strings, timeout)
    #         self._current_output_clean = out[2]
    #         return out
    #     except EOFError:
    #         return -1
    #
    # def _send(self, command_string):
    #     self._handler.write(command_string)

