#!/usr/bin/python
import sys
import os
import logging
from datetime import datetime
from logging import FileHandler
from logging import StreamHandler

from qualipy.common.libs.qs_config_parser import QSConfigParser


# Logging Levels
LOG_LEVELS = {
    'INFO': logging.INFO,
    'WARN': logging.WARN,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL,
    'FATAL': logging.FATAL,
    'DEBUG': logging.DEBUG}

# default settings
DEFAULT_FORMAT = '%(asctime)s [%(levelname)s]: %(name)s %(module)s - %(funcName)-20s %(message)s'
DEFAULT_TIME_FORMAT = '%Y%m%d%H%M%S'
DEFAULT_LEVEL = 'DEBUG'
# DEFAULT_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../', 'Logs')
LOG_SECTION = 'Logging'


def getSettings():
    config = {}
    # Level
    log_level = QSConfigParser.getSetting(LOG_SECTION, 'LOG_LEVEL') or DEFAULT_LEVEL
    config['LOG_LEVEL'] = log_level

    # Log format
    log_format = QSConfigParser.getSetting(LOG_SECTION, 'LOG_FORMAT') or DEFAULT_FORMAT
    config['FORMAT'] = log_format

    # log_path
    log_path = QSConfigParser.getSetting(LOG_SECTION, 'LOG_PATH')
    config['LOG_PATH'] = log_path

    # Time format
    time_format = QSConfigParser.getSetting(LOG_SECTION, 'TIME_FORMAT') or DEFAULT_TIME_FORMAT
    config['TIME_FORMAT'] = time_format

    return config


# return accessable log path or None
def getAccessibleLogPath(handler='Default'):
    accessible_log_path = None
    config = getSettings()
    if not config['LOG_PATH']:
        return None
    log_path = os.path.join(config['LOG_PATH'], handler, datetime.now().strftime(config['TIME_FORMAT']))
    log_file = os.path.join(log_path, 'qualipy.log')
    # print(log_file)
    if log_path and os.path.isdir(log_path) and os.access(log_path, os.W_OK):
        accessible_log_path = log_file
    else:
        try:
            os.makedirs(log_path)
            accessible_log_path = log_file
        except:
            pass
    return accessible_log_path


def getQSLogger(name='QS', handler_name='Default'):
    # check if logger created
    logger_name = '%s.%s' % (name, handler_name)
    root_logger = logging.getLogger()
    logger_dict = root_logger.manager.loggerDict
    if logger_name in logger_dict.keys():
        return logging.getLogger(logger_name)


    # configure new logger
    config = getSettings()
    logger = logging.getLogger(logger_name)
    formatter = MultiLineFormatter(config['FORMAT'])

    if 'LOG_PATH' in os.environ:
        log_path = os.environ['LOG_PATH']
    else:
        log_path = getAccessibleLogPath(handler_name)

    if log_path:
        # print("Logger log path: %s" % log_path)
        hdlr = FileHandler(log_path, mode='w')
        print 'Logger File Handler is: {0}'.format(hdlr.baseFilename)
    else:
        hdlr = StreamHandler(sys.stdout)

    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr)
    logger.setLevel(config['LOG_LEVEL'])
    return logger


def getLogPath(logger=logging.getLogger()):
    for hdlr in logger.handlers:
        if isinstance(hdlr, logging.FileHandler):
            return hdlr.baseFilename
    return None


class MultiLineFormatter(logging.Formatter):
    """Log Formatter.

       Appends log header to each line.
       """
    MAX_SPLIT = 1

    def format(self, record):
        '''formatting for one or multi-line message

        :param record:
        :return:
        '''
        s = ''

        if record.msg == '':
            return s

        try:
            s = logging.Formatter.format(self, record)
            header, footer = s.rsplit(record.message, self.MAX_SPLIT)
            s = s.replace('\n', '\n' + header)
        except Exception, e:
            print 'logger.format: Unexpected error: ' + str(e)
            print 'record = %s<<<' % record
        return s


class Loggable(object):
    """Interface for Instances which uses Logging"""
    LOG_LEVEL = LOG_LEVELS['WARN']  # Default Level that will be reported
    LOG_INFO = LOG_LEVELS['INFO']
    LOG_WARN = LOG_LEVELS['WARN']
    LOG_ERROR = LOG_LEVELS['ERROR']
    LOG_CRITICAL = LOG_LEVELS['CRITICAL']
    LOG_FATAL = LOG_LEVELS['FATAL']
    LOG_DEBUG = LOG_LEVELS['DEBUG']

    def setupLogger(self):
        '''Setup local logger instance

        :return:
        '''
        self.logger = getQSLogger(self.__class__.__name__)
        self.logger.setLevel(self.LOG_LEVEL)
        # Logging methods aliases
        self.logDebug = self.logger.debug
        self.logInfo = self.logger.info
        self.logWarn = self.logger.warn
        self.logError = self.logger.error
