import json

__author__ = 'eric.r'
import sys
sys.path.append('../../../')

import os
from qualipy.common.libs.driver_builder_wrapper import base_resource_driver
from qualipy.common.libs.driver_builder_wrapper import DriverFunction
from qualipy.common.libs.qs_logger import getQSLogger
from qualipy.common.libs.ssh_manager import SSHManager

class LinuxResourceDriver(base_resource_driver):
    def log(self, s):
        with open(os.environ['TEMP']+'/qs_linux_driver_'+self.sessionid+'.log', 'a') as f:
            f.write(s.encode('utf-8')+'\n')
        print(s)

    @DriverFunction
    def ExecuteSSHCommand(self, matrix_json, command):
        return self.ssh_exec(command)

    @DriverFunction
    def WriteFile(self, matrix_json, filename, text):
        return self.write_file(filename, text)

    def ssh_exec(self, command):
        self.log('\n\n############################################\nExecuting '+command)
        stdio, stdout, stderr = self.ssh.execute(command)
        rv = '\n'.join(map(lambda s: s.strip(), stdout))
        self.log('stdout: '+rv)
        errs = '\n'.join(map(lambda s: s.strip(), stderr))
        self.log('stderr: '+errs)
        return rv

    def write_file(self, filename, text):
        self.ssh_exec('cat > '+filename+' <<"ZZQQSSEOFMARKER"\n'+text+'\nZZQQSSEOFMARKER')

    def append_to_file(self, filename, text):
        self.ssh_exec('cat >> '+filename+' <<"ZZQQSSEOFMARKER"\n'+text+'\nZZQQSSEOFMARKER')

    def generate_file_from_template(self, template_filename, dest_filename, key2value):
        """
        :param template_filename: full path to read-only template file that may contain placeholders in the form {param}
        :param dest_filename: full path to destination file
        :param key2value: dictionary param->value
        :return:
        """
        if len(key2value) > 0:
            sed = "sed '"
            for key in key2value:
                sed += 's#{' + key.replace('''#''', '''\#''') + '}#' + key2value[key].replace('''#''', '''\#''').replace("""'""","""'"'"'""") + '#g; '
            sed += "' " + template_filename + ' > ' + dest_filename
            self.ssh_exec(sed)
        else:
            self.ssh_exec('cp "'+template_filename+'" "'+dest_filename+'"')

    @DriverFunction(extraMatrixRows={'resource': ['User', 'Password']})
    def Init(self, matrix_json):
        """

        :param host: Linux host to connect with SSH
        :param username: Linux username
        :param password: Linux password
        :return:
        """
        o = json.loads(matrix_json)
        host = o['resource']['ResourceAddress']
        username = o['resource']['User']
        password = o['resource']['Password']

        logger = getQSLogger(name='qs_linux_manager_name', handler_name='qs_linux_manager_handler')
        # logger = setupLogger('qs_linux_manager_log', logFile='qs_linux_manager_log.txt')
        self.ssh = SSHManager(username=username, password=password, host=host, port=22, timeout=4, logger=logger)
        self.ssh.connect()
        self.ssh_exec("ls")
