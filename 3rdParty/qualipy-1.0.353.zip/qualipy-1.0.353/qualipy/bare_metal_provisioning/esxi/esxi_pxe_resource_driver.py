__author__ = 'eric.r'

import sys
sys.path.append('../../../')

from qualipy.common.libs.driver_builder_wrapper import DriverFunction
from qualipy.common.libs.driver_builder_wrapper import base_resource_driver

import esxi_pxe

import json

class esxi_pxe_resource_driver(base_resource_driver):
    @DriverFunction(extraMatrixRows={"resource": ["User","Password"]})
    def WaitForPXEBoot(self, matrixJson, csvMacs, timeoutMinutes):
        o=json.loads(matrixJson)
        pxeIP=o['resource']['ResourceAddress']
        pxeUser=o['resource']['User']
        pxePassword=o['resource']['Password']

        return esxi_pxe.wait_for_pxe_boot(pxeIP, pxeUser, pxePassword, csvMacs, timeoutMinutes)

    @DriverFunction(extraMatrixRows={"resource": ["User","Password"]})
    def SetDHCP(self, matrixJson, csvMacs, isoPathOnVtgShare, rootPassword, mgmtVlan, ip, netmask, gateway, dns1, dns2):
        o=json.loads(matrixJson)
        pxeIP=o['resource']['ResourceAddress']
        pxeUser=o['resource']['User']
        pxePassword=o['resource']['Password']

        return esxi_pxe.set_dhcp(pxeIP, pxeUser, pxePassword, csvMacs, isoPathOnVtgShare, rootPassword, mgmtVlan, ip, netmask, gateway, dns1, dns2)


# '''{"resource" : { "ResourceAddress" : "10.11.34.81", "User" : "root", "Password" : "@Vantage123" }}'''