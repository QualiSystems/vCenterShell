__author__ = 'eric.r'

import sys
sys.path.append('../../../')

from qualipy.common.libs.qs_logger import getQSLogger
from qualipy.common.libs.ssh_manager import SSHManager
import os
import time

def log(s):
    with open(os.environ['TEMP']+'/qs_esxi_pxe.log', 'a') as f:
        f.write(s+'\n')
        # print(s)

def sshexec(ssh_client, command):
    log('Executing '+command)
    stdio,stdout,stderr=ssh_client.execute(command)
    rv = '\n'.join(map(lambda s: s.strip(),stdout))
    log('Result: '+rv)
    return rv

def writefile(client, filename, text):
    sshexec(client, 'cat > '+filename+' <<"EOFMARKER"\n'+text+'\nEOFMARKER')

def wait_for_pxe_boot(pxeIP, pxeUser, pxePassword, csvMacs, timeoutMinutes):
    logger = getQSLogger('test', logFile = 'test')

    client = SSHManager(pxeUser, pxePassword, pxeIP, 22, timeout = 4, logger = logger)
    client.connect()
    
    sshexec(client, "ls")
    sshexec(client, "sleep 5")
    
    timeoutSeconds=int(timeoutMinutes)*60
    totalWaitSeconds=0
    while totalWaitSeconds < timeoutSeconds:
        ans = sshexec(client, 'egrep -q "'+csvMacs.replace(',','|')+'" /var/log/syslog && echo "y""es" || echo no')
        if "yes" in ans:
            client.disconnect()
            return "booted"
        time.sleep(5)
        totalWaitSeconds=totalWaitSeconds+5
    client.disconnect()
    return "timed out"


def set_dhcp(pxeIP, pxeUser, pxePassword, csvMacs, isoPathOnVtgShare, rootPassword, mgmtVlan, ip, netmask, gateway,
             dns1, dns2):
    logger = getQSLogger('test', logFile = 'test')
    client = SSHManager(pxeUser, pxePassword, pxeIP, 22, timeout = 4, logger = logger)
    client.connect()
    sshexec(client, "ls")
    sshexec(client, "sleep 5")

    tftproot='/tftpboot'
    apacheroot='/var/www/html'
    vtgshare='/vtgshare'
    vtgshareisopath=isoPathOnVtgShare.replace('\\','/')
    isomount=tftproot+'/esxi/'+os.path.basename(vtgshareisopath).replace(' ','_')

    ans = sshexec(client,'mkdir -m 777 -p '+isomount)

    ans = sshexec(client,'[ -f '+isomount+'/boot.cfg ] || mount "'+vtgshare+'/'+vtgshareisopath+'" -o loop,ro '+isomount)

    for mac in str.split(csvMacs,','):
        macUcaseColons=str.upper(mac.replace('-',':'))
        macLcaseColons=str.lower(mac.replace('-',':'))
        macUcaseDashes=str.upper(mac.replace(':','-'))
        macLcaseDashes=str.lower(mac.replace(':','-'))
        macUcaseUnderscores=str.upper(mac.replace(':','_').replace('-','_'))
        macLcaseUnderscores=str.lower(mac.replace(':','_').replace('-','_'))

        ans = sshexec(client,'sed -i -e /'+macLcaseUnderscores+'/d /etc/dnsmasq.conf')

        ans = sshexec(client,'grep PROTOTYPE /etc/dnsmasq.conf')

        newline=ans.replace('PROTOTYPE','j'+macLcaseUnderscores)
        ans = sshexec(client,'echo '+newline+' >> /etc/dnsmasq.conf')
        ans = sshexec(client,'echo "dhcp-mac=set:j'+macLcaseUnderscores+','+macLcaseColons+'" >> /etc/dnsmasq.conf')

        ans = sshexec(client,'rm -f '+tftproot+'/esxi/cd_'+macLcaseDashes)
        ans = sshexec(client,'ln -s '+isomount+' '+tftproot+'/esxi/cd_'+macLcaseDashes)

        ans = sshexec(client,'sed -e "s#/#/esxi/cd_'+macLcaseDashes+'/#g; s#runweasel#runweasel ks=http://'+pxeIP+'/esxi/ks_'+macLcaseDashes+'.cfg#" '+tftproot+'/esxi/cd_'+macLcaseDashes+'/boot.cfg > '+tftproot+'/esxi/boot_'+macLcaseDashes+'.cfg')

        writefile(client, tftproot+'/pxelinux.cfg/01-'+macLcaseDashes, '''TIMEOUT 1 # 3 seconds
PROMPT 1
DEFAULT vga
SAY -
SAY vga - QualiSystems_ESXi_installer
SAY -

LABEL vga
KERNEL esxi/cd_'''+macLcaseDashes+'''/mboot.c32
APPEND -c esxi/boot_'''+macLcaseDashes+'''.cfg
IPAPPEND 2
''')

        writefile(client, apacheroot+'/esxi/ks_'+macLcaseDashes+'.cfg', '''vmaccepteula

rootpw '''+rootPassword+'''

install --disk=mpx.vmhba32:C0:T0:L0 --overwritevmfs

%post  --interpreter=busybox
sleep 30
reboot

%firstboot --interpreter=busybox

vim-cmd hostsvc/enable_esx_shell
vim-cmd hostsvc/start_esx_shell

esxcli network vswitch standard uplink add -u vmnic2 -v vSwitch0
esxcli network vswitch standard uplink add -u vmnic3 -v vSwitch0

esxcli network vswitch standard uplink remove -u vmnic0 -v vSwitch0
esxcli network vswitch standard uplink remove -u vmnic1 -v vSwitch0

esxcli network vswitch standard policy failover set -v vSwitch0 -a vmnic2,vmnic3 -l iphash
esxcli network vswitch standard portgroup policy failover set -p "Management Network" -u
esxcli network vswitch standard add -v vSwitchAMP2

esxcli network vswitch standard portgroup set -p "Management Network" -v '''+str(mgmtVlan)+'''
esxcli network ip interface ipv4 set -i vmk0 --ipv4 '''+ip+''' --netmask '''+netmask+''' --type static
esxcli network ip route ipv4 add -g '''+gateway+''' -n default
esxcli network ip dns server add -s '''+dns1+'''
esxcli network ip dns server add -s '''+dns2+'''

    ''')

    ans = sshexec(client, 'cat /etc/dnsmasq.conf')
    ans = sshexec(client, 'service dnsmasq restart')
    client.disconnect()
    return 'Success'


def test(self):
    set_dhcp("10.11.34.81", "root", "@Vantage123", '90:e2:ba:79:d9:e0,90:e2:ba:79:d9:e1,50:87:89:b7:09:fe,50:87:89:b7:09:ff',
                 'software/Component/VMware/vSphere5/CustomISOs-QA/2015 April/ESXi-5.5.0-2403361-vce-4.5.12_Vb200.iso',
                 '@Vantage123', '2453', '10.11.79.15', '255.255.255.128', '10.11.79.1', '10.11.79.216', '10.11.79.217')
    wait_for_pxe_boot("10.11.34.81", "root", "@Vantage123", '90:e2:ba:79:d9:e0,90:e2:ba:79:d9:e1,50:87:89:b7:09:fe,50:87:89:b7:09:ff')



def testssh(self):
    logger = getQSLogger('test9991a', logFile='test9991b')
    client = SSHManager('qauser', 'qa1234', '192.168.28.160', 22, timeout=4, logger=logger)
    client.connect()
    print sshexec(client, "ls -l /")
    print sshexec(client, "ls -l /")
    client.disconnect()

    # testssh()