__author__ = 'g8y3e'

import sys
sys.path.append('../../../')

from qualipy.common.cisco.cisco_os import CiscoOS
from qualipy.common.libs.utils import getMatrixFromString

import re
import time
import math
import traceback

class CiscoCimc(CiscoOS):
    def __init__(self, connection_manager, logger = None):
        CiscoOS.__init__(self, connection_manager, logger)

        self.expected_str = '[#$]{1}'

    def scope(self, parameters_str, **kwargs):
        command = 'scope ' + parameters_str
        return self._sendCommand(command, **kwargs)

    def set(self, parameters_str, **kwargs):
        command = 'set ' + parameters_str
        return self._sendCommand(command, **kwargs)

    def commit(self, **kwargs):     
        timeout = 900

        command = 'commit'
        return self._sendCommand(command, timeout = timeout, **kwargs)

    def top(self):
        command = 'top'
        return self._sendCommand(command)

    def show(self, parameters_str, **kwargs):
        command = 'show ' + parameters_str
        return self._sendCommand(command, **kwargs)

    def reboot(self, **kwargs):
        command = 'reboot'
        return self._sendCommand(command, **kwargs)

    def update(self, parameters_str, **kwargs):
        command = 'update ' + parameters_str
        return self._sendCommand(command, **kwargs)
    
    def delete(self, parameters_str, **kwargs):
        command = 'delete ' + parameters_str
        return self._sendCommand(command, **kwargs)

    def power(self, parameters_str, **kwargs):
        command = 'power ' + parameters_str
        return self._sendCommand(command, **kwargs)

    def rebootCIMC(self):
        self.top()
        self.scope('cimc')
        reboot_output_str = self.reboot(expected_str = r'#|$|\[.{3}\]')

        if re.search('\[.{3}\]', reboot_output_str.lower()) != None:
            reboot_output_str = self._sendCommand('y', expected_str = '')

        if re.search('[#$]{1}', reboot_output_str.lower()) == None:
            time.sleep(60)
            self._session_handler.reconnect(10, 20)

        self.top()

        return 'Rebooted CIMC!'

    def rebootChassis(self, resource_name):
        self.top()
        self.scope('chassis')
        reboot_output_str = self.power('cycle', expected_str = r'#|>|\[.{3}\]')

        if re.search('\[.{3}\]', reboot_output_str.lower()) != None:
            self._sendCommand('y')

        return 'Rebooted Server ' + resource_name

    def configureSNMP(self, access_community, trap_version_list, trap_destination_list):
        self.top()
        self.scope('snmp')
        self.set('enabled yes')
        self.commit()

        self.set('community-str ' + access_community)
        self.commit()

        for index in range(0, len(trap_version_list)):
            self.top()
            self.scope('snmp')
            #self.set('trap-ver ' + trap_version)
            self.scope('trap-destinations ' + str(index + 1))
            self.set('version ' + trap_version_list[index])
            self.set('enabled yes')
            self.set('v4-addr ' + trap_destination_list[index])

        self.commit()

        return 'Finished configuring SNMP'

    def configureSyslog(self, sys_log_server_list, sys_log_enabled_list):
        server_list = self._getSyslogServerList()

        server_log_size = len(sys_log_server_list)

        if server_list.has_key('syslog server'):
            range_size = server_log_size if server_log_size < len(server_list['syslog server']) \
                                    else len(server_list['syslog server'])

            for index in range(0, range_size):
                self.top()
                self.scope('cimc')
                self.scope('log')

                self.scope('server ' + server_list['syslog server'][index])
                self.set('server-ip ' + sys_log_server_list[index])
                self.set('enabled ' + sys_log_enabled_list[index].lower())
                self.commit()
        
        return 'Finished configuring syslog'

    def _getSyslogServerList(self):
        self.top()
        self.scope('cimc')
        self.scope('log')

        return getMatrixFromString(self.show('server'))
    
    def createVirtualDrive(self, drive_name, drive_raid_type, storage_slot, 
                    drive_using_percent = 1.0):        
        drives = getMatrixFromString(self._showVirtualDrives(storage_slot))

        is_found_drive = False
        if drives.has_key('name'):
            for drive in drives['name']:
                if drive == drive_name:
                    is_found_drive = True
                    break

        if (is_found_drive == False) or (len(drives) == 0):
            is_drive_created = False

            try:
                self._createVirtualDrive(drive_name, drive_raid_type, storage_slot,
                                                    drive_using_percent)
                retries_count = 5
                while (retries_count > 0 and not is_drive_created):
                    drives = getMatrixFromString(self._showVirtualDrives(storage_slot))

                    if drives != None and drives.has_key('name') and len(drives['name']) != 0:
                        for drive_name_str in drives['name']:
                            if drive_name_str == drive_name:
                                is_drive_created = True
                                break

                    retries_count -= 1
                    if not is_drive_created:
                        time.sleep(5)
                        
            except Exception, err:
                error_str =  "Exception: " + str(err) + '\n'

                error_str += '-' * 60 + '\n'
                error_str += traceback.format_exc()
                error_str += '-' * 60
                if self.logger:
                    self.logger.error(error_str)

            if not is_drive_created:
                return 'Failure to create virtual drive ' + drive_name

        return 'Finished attempting to create virtual drive ' + drive_name     

    def _showVirtualDrives(self, storage_slot):
        self.top()
        self.scope('chassis')
        self.scope('storageadapter ' + str(storage_slot).upper())
        return self.show('virtual-drive')     
   
    def _createVirtualDrive(self, drive_name, drive_raid_type, storage_slot,
                            drive_using_percent):
        self.top()
        self.scope('bios')
        self.scope('advanced')

        storage_slot_transform = self._transformSlot(storage_slot)

        retries_count = 5
        is_enabled_slot = False
        while (retries_count > 0 and not is_enabled_slot):
            show_grep_data = self.show(' | grep "' + storage_slot_transform + ' OptionROM"')

            is_enabled_slot = ('enabled' in show_grep_data.lower())

            retries_count -= 1
            if not is_enabled_slot:
                time.sleep(5)
                
        if (retries_count <= 0 and not is_enabled_slot):
            raise Exception('Cisco CIMC', "Can't enable slot: " + storage_slot)       

        self.top()
        self.scope('chassis')
        self.scope('storageadapter ' + storage_slot)

        self._sendCommand('create-virtual-drive', expected_str = '-->')
        slots_list_str = self._sendCommand(str(drive_raid_type), expected_str = '-->|Invalid or unsupported')

        if re.search('Invalid or unsupported', slots_list_str) != None:
            raise Exception('Cisco CIMC', "Invalid or unsupported raid type!")

        result_parse_slots = self._parseVirtualDriveSlots(slots_list_str, drive_using_percent)

        if len(result_parse_slots[1]) == 0:
            raise Exception('Cisco CIMC', "No avaible slot left!")  #fixme misspelling

        self._sendCommand(result_parse_slots[0], expected_str = '-->')
        self._sendCommand(drive_name, expected_str = '-->')

        virtual_drive_size = result_parse_slots[1][0][0] + ' ' + (result_parse_slots[1][0][1])[:-1]
        self._sendCommand(virtual_drive_size, expected_str = '-->')

        self._sendCommand('y', expected_str = '-->')
        result_confirm =  self._sendCommand('y')

        self.commit()

        if result_confirm.find('error') != -1:
            raise Exception('Cisco CIMC', "Can't confirm finish data")  

    def _parseVirtualDriveSlots(self, slot_str, drive_using_percent):
        slot_str = slot_str[0:slot_str.find('Specify physical')]

        pattern = re.compile('[\s\w]*:')

        finded = pattern.match(slot_str)

        slot_str = slot_str[(finded.span())[1]:]

        lines = slot_str.split('\n')

        lines = filter(
            lambda value: 
                value != '', lines)

        slot_number_list = []
        slot_sizes = []

        pattern_slot = re.compile('[\d]+:')
        pattern_slot_size = re.compile(':[\sa-zA-Z]+')

        for line in lines:
            result_match = pattern_slot.search(line)
            if result_match != None:
                number_slot_str = result_match.group()
                number_slot_str = number_slot_str[0:-1]
                slot_number_list.append(number_slot_str)
        
            result_match = pattern_slot_size.search(line)    
            if result_match != None: 
                size_slot_str = line[result_match.span()[1]:]

                slot_size = size_slot_str.split(' ')
                slot_sizes.append(slot_size)

        drive_number = int(math.ceil(len(slot_number_list) * drive_using_percent))

        slot_number_str = ''
        for index in range(0, drive_number):
            slot_number_str += slot_number_list[index] + ','

        slot_number_str = slot_number_str[:-1]

        return (slot_number_str, slot_sizes)

    def _transformSlot(self, storage_slot):
        storage_slot = storage_slot.lower()

        storage_slot = storage_slot.replace('-', ':')
        storage_slot = storage_slot.replace('slot', 'Slot')
      
        return self._clearSpaces(storage_slot)

    def _clearSpaces(self,data_str):
        data_founded = re.findall('\S+', data_str)

        if len(data_founded) == 0:
            return ''

        return data_founded[0]
   
    def deleteVirtualDrives(self, storage_slot):  
        drives = getMatrixFromString(self._showVirtualDrives(storage_slot))                

        drive_names = drives.get('virtual drive')
        if drive_names != None:
            for drive_name in drive_names:
                self.top()
                self.scope('chassis')
                self.scope('storageadapter ' + storage_slot)
                self.scope('virtual-drive ' + str(drive_name))

                remove_cout = 5
                is_deleted = False
                while (remove_cout > 0 and not is_deleted):
                    self._sendCommand('delete-virtual-cdrive', expected_str = '->')
                    delete_result = self._sendCommand('yes')

                    delete_result = delete_result.lower()

                    remove_cout -= 1
                    is_deleted = (not 'failed' in delete_result) and (not 'error' in delete_result)
                    if not is_deleted:
                        time.sleep(5)

                self.commit()
                time.sleep(3)
    
        return 'Finished Deleting All Virtual-Drives'
    
    def enableFlashFlexDrive(self, virtual_drives_enabled):
        self.top()
        self.scope('chassis')
        self.scope('flexflash FlexFlash-0')
        self.scope('operational-profile')
        self.set('virtual-drives-enabled ' + virtual_drives_enabled)
        self.commit()        

        return 'Finished configuring FlexFlash'

    def enableHTTP(self, scope_setting):
        self.top()  
        self.scope('http')
        self.set('enabled ' + str(scope_setting).lower())
        self.commit()        
        
        return 'Finished configuring HTTP'    

    def enableSSH(self, scope_setting):
        self.top() 
        self.scope('ssh')
        self.set('enabled ' + str(scope_setting).lower())
        self.commit()
        
        return 'Finished configuring SSH'           

    def enableXmlAPI(self, scope_setting):
        self.top()  
        self.scope('xmlapi')
        self.set('enabled ' + str(scope_setting).lower())
        self.commit()
        
        return 'Finished configuring XML API'    
 
    def setBootOrder(self, boot_order):
        self.top()  
        self.scope('bios')

        self.set('boot-order '+ boot_order)
        self.commit()

        return 'Finished setting boot order to ' + boot_order
              
    def setDNS(self, dns_server, alternate_server):
        self.top()
        self.scope('cimc')
        self.scope('network')
        self.set('preferred-dns-server ' + dns_server)
        self.set('alternate-dns-server ' + alternate_server)
        self.commit()

        return 'Finished setting DNS Preferred Server'     

    def setEventFilter(self, enable_platform_events, filter_setting, single = -1, 
                    event_filter_start = 1, event_filter_end = 1):
        self.top() 
        self.scope('fault')
        self.set('platform-event-enabled ' + enable_platform_events)
        self.commit()          

        if single != -1:
            event_filter_start = single
            event_filter_end = single

        for i in range(event_filter_start, event_filter_end):    
            self.top()    
            self.scope('fault')     
            self.scope('pef ' + str(i))
            self.set('send-alert ' + str(filter_setting))

        self.commit()

        return 'Finished configuring Event Filters'

    def setHostname(self, hostname):
        self.top()  
        self.scope('cimc')
        self.scope('network')
        set_output_str = self.set('hostname ' + hostname, expected_str = r'#|$|\[.{3}\]')

        if re.search('\[.{3}\]', set_output_str.lower()) != None:
            self._sendCommand('y')
             
        commit_output_str = self.commit(expected_str = '')       # timeout = 20     
        
        if re.search('[#$]{1}', commit_output_str.lower()) == None:
            time.sleep(20)
            self._session_handler.reconnect(10, 20)

        print self.top()
        return 'Finished configuring HostName'

    # enable_kvm - 'yes' or 'no'
    def setKVM(self, enable_kvm):
        self.top() 
        self.scope('kvm')
        self.set('enabled ' + enable_kvm.lower())
        self.commit()        
        
        return 'Finished enabling/disabling KVM'       
    
    def setNTP(self, enable = 'yes', args = []):
        self.top()
        self.scope('cimc')
        self.scope('network')
        self.scope('ntp')
        set_output_str = self.set('enabled ' + enable.lower(), expected_str = r'#|$|\[.{3}\]')

        if re.search('\[.{3}\]', set_output_str.lower()) != None:
            self._sendCommand('y')

        self.commit()          

        servers_count = len(args)
        for index in range(0, servers_count):
            self.set('server-' + str(index + 1) + ' ' + args[index])

        self.commit()       

        return 'Finished configuring NTP'        

    def setProcConfig(self, proccess_config = []):
        self.top()
        self.scope('bios')
        self.scope('advanced')

        for config in proccess_config:
            self.set(config)
        
        set_output_str = self.commit(expected_str = r'#|$|\[.{3}\]')

        if re.search('\[.{3}\]', set_output_str.lower()) != None:
            self._sendCommand('y')

        return 'Finished setting processor configuration!'

   
    def updateFirmware(self, tftp_server, firmware):
        self.top()
        self.scope('cimc')
        self.scope('firmware')
        self.update(tftp_server + ' ' + firmware)

        details = self.show('detail')       
        # regExp Update Progress.*
        
        details = self._clearSpaces(details)
        return details
           
    def showKVM(self):
        self.top()
        return self.show('kvm')

    def showPhysicalDrives(self, storage_slot):
        self.top()
        self.scope('chassis')
        self.scope('storageadapter ' + str(storage_slot))

        return self.show('physical-drive')

    def showProcessorDetail(self):
        self.top()
        self.scope('bios')

        return self.show('advanced detail')

    def showSLOTs(self):
        self.top()        
        self.scope('chassis')  
                
        return self.show('storageadapter')

    def showSNMPDetails(self):
        self.top()
        self.scope('snmp')

        return self.show('detail')
    
    def getMacs(self):
        self.top()
        self.scope('cimc')
        self.scope('network')
        cimc_macs = self.show('detail')

        result_macs_str = ''

        if cimc_macs != None and cimc_macs != '':
            cimc_macs_lines = cimc_macs.split('\n')
            for line in cimc_macs_lines:
                if 'mac address:' in line.lower():
                    find_str = 'ddress: '
                    mac_str = line[line.find(find_str) + len(find_str):-1]
                    result_macs_str += mac_str + ','

        self.top()
        self.scope('chassis')

        adapters_str = self.show('network-adapter')

        mac_pattern = re.compile(r'(\w{2}:){5}\w{2}')

        if adapters_str != None:
            eth_devices = getMatrixFromString(adapters_str)

            if eth_devices != None and eth_devices.has_key('slot'):
                for slot in eth_devices['slot']:
                    self.top()
                    self.scope('chassis')

                    result_str = self.scope('network-adapter ' + slot)
                    retries_scope = 5
                    is_in_scope = result_str != ''
                    while retries_scope > 0 and not is_in_scope:
                        result_str = self.scope('network-adapter ' + slot)

                        is_in_scope = result_str != ''

                        retries_scope -= 1
                        if not is_in_scope:
                            time.sleep(3)
                    if is_in_scope:
                        eth_macs = getMatrixFromString(self.show('mac-list'))

                        if eth_macs != None and eth_macs.has_key('mac address'):
                            for mac_item in eth_macs['mac address']:
                                if mac_pattern.match(mac_item) != None:
                                    result_macs_str += mac_item + ','

        if result_macs_str != '':
            result_macs_str = result_macs_str[:-1]

        return result_macs_str

