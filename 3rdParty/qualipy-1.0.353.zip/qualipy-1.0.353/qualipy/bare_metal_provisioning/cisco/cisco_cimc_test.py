__author__ = 'g8y3e'

from qualipy.common.cisco.cisco_handler_factory import *

host = '10.11.34.75'
username = 'admin'
password = '@Vantage123'

cisco_cimc = CiscoHandlerFactory.createHandler('cimc', host, username, password, 'ssh')

cisco_cimc.connect()

cisco_cimc.configureSNMP('TEST-C220-6')
cisco_cimc.setHostname('TEST-C220-6')
#cisco_cimc.rebootCIMC()

print 'Macs list: ' + cisco_cimc.getMacs() + '\n'

#print 'Macs list: ' + cisco_cimc.getMacs() + '\n'

cisco_cimc.setProcConfig(['IntelHyperThread Enabled'])

print 'Macs list: ' + cisco_cimc.getMacs() + '\n'

print cisco_cimc.setProcConfig([])

slot_str = 'SLOT-2'

cisco_cimc.setNTP('no', ['2', '1'])

cisco_cimc.setHostname('test.com')

print 'Macs list: ' + cisco_cimc.getMacs() + '\n'

print 'SNMP details: ' + cisco_cimc.showSNMPDetails() + '\n'
print 'SLOTs details: ' + cisco_cimc.showSLOTs() + '\n'
#print 'Processor details: ' + cisco_cimc.showProcessorDetail() + '\n' fixme --More--
print 'Physical Drives details: ' + cisco_cimc.showPhysicalDrives(slot_str) + '\n'
print 'KVM details: ' + cisco_cimc.showKVM() + '\n'

print 'Virtual drives:\n' + cisco_cimc._showVirtualDrives(slot_str) + '\n'
print cisco_cimc.deleteVirtualDrives(slot_str)

print 'Virtual drives:\n' + cisco_cimc._showVirtualDrives(slot_str) + '\n'
print cisco_cimc.createVirtualDrive('Test-1', 1, slot_str, 0.5)

print 'Virtual drives:\n' + cisco_cimc._showVirtualDrives(slot_str) + '\n'
print cisco_cimc.createVirtualDrive('Test-2', 1, slot_str, 1.0)

print 'Virtual drives:\n' + cisco_cimc._showVirtualDrives(slot_str) + '\n'