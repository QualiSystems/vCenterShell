from qualipy.common.cisco.cisco_handler_factory import *

import unittest
import shutil
from qualipy.common.libs.utils import isSameListCommandInFile

class TestCiscoCIMC(unittest.TestCase):
    def setUp(self):
        host = ''
        username = ''
        password = ''

        self._log_folder = 'Logs'
        self._log_filename = self._log_folder + '/cimc_unittest.log'
        self._cisco_cimc = CiscoHandlerFactory.createHandler('cimc', host, username, password, 'file',
                                                             filename=self._log_filename)

    def tearDown(self):
        self._cisco_cimc.disconnect()
        shutil.rmtree(self._log_folder)

    @unittest.skip('need real test')
    def test_RebootCIMC(self):
        self._cisco_cimc.rebootCIMC()

        expect_list = ['top', 'scope cimc', 'reboot']   
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_RebootChassis(self):
        self._cisco_cimc.rebootChassis('test')

        expect_list = ['top', 'scope chassis', 'power cycle']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_ConfigureSNMP(self):
        self._cisco_cimc.configureSNMP('test', '1', '2')

        expect_list = ['top', 'scope snmp', 'set enabled yes', 'commit', 'set community-str test', 'commit', 'top',
                       'scope snmp', 'scope trap-destinations 1', 'set version 1', 'set enabled yes',
                       'set v4-addr 2', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_ConfigureSyslog(self):
        self._cisco_cimc.configureSyslog('test', 'yes')

        expect_list = ['top', 'scope cimc', 'scope log', 'show server']

        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)
  
    @unittest.skip('need real test')
    def test_CreateVirtualDrive(self):
        self._cisco_cimc.createVirtualDrive('test', '1', 'SLOT-1')

        expect_list = ['top', 'scope chassis', 'scope storageadapter SLOT-1', 'show virtual-drive', 'top', 
                       'scope bios', 'scope advanced', 'show  | grep "Slot:1 OptionROM"', 'show  | grep "Slot:1 OptionROM"', 
                       'show  | grep "Slot:1 OptionROM"', 'show  | grep "Slot:1 OptionROM"', 'show  | grep "Slot:1 OptionROM"'] 
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    @unittest.skip('need real test')
    def test_DeleteVirtualDrives(self):
        self._cisco_cimc.deleteVirtualDrives('SLOT-1')

        expect_list = ['top', 'scope chassis', 'scope storageadapter SLOT-1', 'show virtual-drive']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_EnableFlashFlexDrive(self):
        self._cisco_cimc.enableFlashFlexDrive('yes')

        expect_list = ['top', 'scope chassis', 'scope flexflash FlexFlash-0', 'scope operational-profile', 
                       'set virtual-drives-enabled yes', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_EnableselfSSH(self):
        self._cisco_cimc.enableSSH('yes')

        expect_list = ['top', 'scope ssh', 'set enabled yes', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_EnableXmlAPI(self):
        self._cisco_cimc.enableXmlAPI('yes')

        expect_list = ['top', 'scope xmlapi', 'set enabled yes', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_SetBootOrder(self):
        self._cisco_cimc.setBootOrder('one,two,three')

        expect_list = ['top', 'scope bios', 'set boot-order one,two,three', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_SetDNS(self):
        self._cisco_cimc.setDNS('test-dns', 'test-dns 2')

        expect_list = ['top', 'scope cimc', 'scope network', 'set preferred-dns-server test-dns', 
                       'set alternate-dns-server test-dns 2', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_SetEventFilter(self):
        self._cisco_cimc.setEventFilter('yes', '1', -1, 1, 2)

        expect_list = ['top', 'scope fault', 'set platform-event-enabled yes', 'commit', 'top', 'scope fault',
                       'scope pef 1', 'set send-alert 1', 'commit']

        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    @unittest.skip('need real test')
    def test_SetHostname(self):
        self._cisco_cimc.setHostname('test.com')

        expect_list = ['top', 'scope cimc', 'scope network', 'set hostname test.com', 'commit', 'top']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_SetKVM(self):
        self._cisco_cimc.setKVM('yes')

        expect_list = ['top', 'scope kvm', 'set enabled yes', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_SetNTP(self):
        self._cisco_cimc.setNTP('yes', ['1', '2'])

        expect_list = ['top', 'scope cimc', 'scope network', 'scope ntp', 'set enabled yes', 
                       'commit', 'set server-1 1', 'set server-2 2', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_SetProcConfig(self):
        self._cisco_cimc.setProcConfig(['1', '2'])

        expect_list = ['top', 'scope bios', 'scope advanced', 'set 1', 'set 2', 'commit']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_UpdateFirmware(self):
        self._cisco_cimc.updateFirmware('server.com', 'firmware_name')

        expect_list = ['top', 'scope cimc', 'scope firmware', 'update server.com firmware_name', 'show detail']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_ShowKVM(self):
        self._cisco_cimc.showKVM()

        expect_list = ['top', 'show kvm']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_ShowPhysicalDrives(self):
        self._cisco_cimc.showPhysicalDrives('SLOT-1')

        expect_list = ['top', 'scope chassis', 'scope storageadapter SLOT-1', 'show physical-drive']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_ShowProcessorDetail(self):
        self._cisco_cimc.showProcessorDetail()

        expect_list = ['top', 'scope bios', 'show advanced detail']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_ShowSLOTs(self):
        self._cisco_cimc.showSLOTs()

        expect_list = ['top', 'scope chassis', 'show storageadapter']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_ShowSNMPDetails(self):
        self._cisco_cimc.showSNMPDetails()

        expect_list = ['top', 'scope snmp', 'show detail']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

    def test_GetMacs(self):
        self._cisco_cimc.getMacs()

        expect_list = ['top', 'scope cimc', 'scope network', 'show detail', 'top', 'scope chassis', 
                       'show network-adapter']
        self.assertEqual(isSameListCommandInFile(self._log_filename, expect_list), True)

if (__name__ == '__main__'):
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            pass
