__author__ = 'eric.r'
import sys
sys.path.append('../../../')

from qualipy.bare_metal_provisioning.pxe.pxe_resource_driver import PXEResourceDriver
from qualipy.common.libs.driver_builder_wrapper import DriverFunction

import json

class WindowsPXEResourceDriver(PXEResourceDriver):
    def os_specific_global_tasks(self, matrix_json):
        self.generate_file_from_template(
            '/tftpboot/pxelinux.cfg/windows.template',
            '/tftpboot/pxelinux.cfg/default',
            {}
        )

    @DriverFunction
    def InstallWindows(self, matrix_json,
                       mac_address,
                       windows_variant,
                       product_key,
                       registered_to_name,
                       registered_to_org,
                       hostname,
                       admin_password,
                       resource_name):

        # https://technet.microsoft.com/en-us/library/jj612867.aspx?f=255&MSPPError=-2147217396

        # variant = Windows Server 2008 R2 SERVERENTERPRISE
        # product key = 489J6-VHDMP-X63PK-3K798-CPX3Y

        # variant = Windows 7 Professional
        # product key = FJ82H-XT6CR-J8D7P-XQJJ2-GPDD4

        # variant = Windows Server 2012 SERVERSTANDARD
        # product key = XC9B7-NBPP2-83J2H-RHMBY-92BT4
        mac_ucase_dashes = str.upper(mac_address.replace(':','-'))

        self.ssh_exec('rm -v -f /tftpboot/windows/wincd_'+mac_ucase_dashes)

        self.generate_file_from_template('/tftpboot/windows/answers_template.xml', '/tftpboot/windows/answers_'+mac_ucase_dashes+'.xml', {
            'QS_WINDOWS_VARIANT': windows_variant,
            'QS_PRODUCT_KEY': product_key,
            'QS_REGISTERED_TO_NAME': registered_to_name,
            'QS_REGISTERED_TO_ORGANIZATION': registered_to_org,
            'QS_HOSTNAME': hostname,
            'QS_ROOT_PASSWORD': admin_password,
            'QS_RESOURCE_NAME': resource_name
        })
        self.ssh_exec('ln -s /tftpboot/windows_iso_mount /tftpboot/windows/wincd_'+mac_ucase_dashes)