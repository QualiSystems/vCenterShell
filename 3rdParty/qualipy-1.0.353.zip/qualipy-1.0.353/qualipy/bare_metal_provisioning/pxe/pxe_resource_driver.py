import sys
sys.path.append('../../../')

from qualipy.common.libs.linux_resource_driver import LinuxResourceDriver
from qualipy.common.libs.driver_builder_wrapper import DriverFunction

import json
import ipcalc

class PXEResourceDriver(LinuxResourceDriver):
    @DriverFunction(extraMatrixRows={'resource': [
        'PXE IP',
        'PXE Mask',
        'DHCP Range Start',
        'DHCP Range End',
        'Enable MAC Filter',

        'ISO Path',
        'ISO Domain',
        'ISO User',
        'ISO Password',

        'OS Name',
    ]})
    def ConfigurePXE(self, matrix_json):
        o = json.loads(matrix_json)
        self.stop_services()
        self.unmount_iso(o['resource']['OS Name'])
        self.install_dhcpd(
            o['resource']['PXE IP'],
            o['resource']['PXE Mask'],
            o['resource']['DHCP Range Start'],
            o['resource']['DHCP Range End'],
            'ignore' if o['resource']['Enable MAC Filter'].lower() in ['true', 'yes', 'on', 'enable'] else 'allow'
        )
        self.install_tftpd()
        self.install_tftp_files(o['resource']['OS Name'])
        self.install_samba()
        self.fix_selinux()

        self.os_specific_global_tasks(matrix_json)
        self.mount_iso(
            o['resource']['ISO Path'],
            o['resource']['ISO Domain'],
            o['resource']['ISO User'],
            o['resource']['ISO Password'],
            o['resource']['OS Name']
        )
        self.start_services()

    @DriverFunction
    def EnableMAC(self, matrix_json, mac_address):
        mac_lcase_dashes = str.lower(mac_address.replace(':','-'))
        mac_lcase_colons = str.lower(mac_address.replace('-',':'))

        # self.ssh_exec('sed -i -e "s/#ANCHOR/host ' + mac_lcase_dashes + ' { hardware ethernet ' + mac_lcase_colons
        #               + ';  }\\n#ANCHOR/" /etc/dhcp/dhcpd.conf')
        self.append_to_file('/etc/dhcp/dhcpd.conf', 'host ' + mac_lcase_dashes + ' { hardware ethernet ' + mac_lcase_colons + ';  }')
        self.ssh_exec('service dhcpd restart')

    @DriverFunction
    def AssignMACStaticIP(self, matrix_json,  mac_address, static_ip):
        mac_lcase_dashes = str.lower(mac_address.replace(':','-'))
        mac_lcase_colons = str.lower(mac_address.replace('-',':'))

        # self.ssh_exec('sed -i -e "s/#ANCHOR/host ' + mac_lcase_dashes + ' { hardware ethernet ' + mac_lcase_colons
        #               + '; fixed-address '+static_ip+'  }\\n#ANCHOR/" /etc/dhcp/dhcpd.conf')
        self.append_to_file('/etc/dhcp/dhcpd.conf', 'host ' + mac_lcase_dashes + ' { hardware ethernet ' + mac_lcase_colons + ';  fixed-address '+static_ip+'; }')
        self.ssh_exec('service dhcpd restart')

    def os_specific_global_tasks(self, matrix_json):
        pass

    def fix_selinux(self):
        self.ssh_exec('semanage fcontext -a -t public_content_rw_t "/tftpboot(/.*)?"')
        self.ssh_exec('restorecon -R /tftpboot')

    def mount_iso(self, iso_samba_path, iso_samba_domain, iso_samba_user, iso_samba_password, os_name):
        isopath = iso_samba_path.replace('\\','/')
        isofolder = '/'.join(isopath.split('/')[:-1])
        isoname = isopath.split('/')[-1]

        self.ssh_exec('mount.cifs '
                      + '"' + isofolder + '" '
                      + '/tftpboot/'+os_name+'_share/ '
                      + '-o ro,'
                      + "username='" + iso_samba_user.replace("""'""", """'"'"'""") + "',"
                      + "password='" + iso_samba_password.replace("""'""", """'"'"'""") + "'"
                      + ('' if iso_samba_domain == ''
                         else ",domain='"+iso_samba_domain.replace("""'""", """'"'"'""")+"'")
                      )
        self.ssh_exec('mount '
                      '-o loop,context=unconfined_u:object_r:tftpdir_rw_t:s0 '
                      '"/tftpboot/'+os_name+'_share/' + isoname + '" '
                      '/tftpboot/'+os_name+'_iso_mount')

    def unmount_iso(self, os_name):
        self.ssh_exec('umount /tftpboot/'+os_name+'_iso_mount')
        self.ssh_exec('umount /tftpboot/'+os_name+'_share')

    def install_tftpd(self):
        self.generate_file_from_template('/etc/xinetd.d/tftp.template', '/etc/xinetd.d/tftp', {})

    def install_samba(self):
        self.generate_file_from_template('/etc/samba/smb.conf.template', '/etc/samba/smb.conf', {})
        self.ssh_exec('setsebool -P samba_export_all_rw 1')
        # self.ssh_exec('semanage fcontext -a -t samba_share_t "/tftpboot(/.*)?"')
        # self.ssh_exec('restorecon -R /tftpboot')


    def install_dhcpd(self, pxe_ip, pxe_mask, dhcp_range_start, dhcp_range_end, allow_or_ignore_unknown_clients):
        pxe_subnet = str(ipcalc.Network(ip=pxe_ip, mask=pxe_mask).network())
        self.generate_file_from_template(
            '/etc/dhcp/dhcpd.conf.template',
            '/etc/dhcp/dhcpd.conf',
            {
                'privateip': pxe_ip,
                'subnet': pxe_subnet,
                'range': dhcp_range_start + " " + dhcp_range_end,
                'mask': pxe_mask,
                'allow_or_ignore_unknown_clients': allow_or_ignore_unknown_clients
            })
        self.generate_file_from_template(
            '/etc/sysconfig/network-scripts/ifcfg-eth1.template',
            '/etc/sysconfig/network-scripts/ifcfg-eth1',
            {
                'privateip': pxe_ip,
                'mask': pxe_mask,
            })

    def restart_services(self):
        self.stop_services()
        self.start_services()

    def start_services(self):
        self.ssh_exec('ifup eth1 && '
                      'service vsftpd start && '
                      'service dhcpd start && '
                      'service xinetd start && '
                      'service httpd start && '
                      'service smb start && '
                      'service nmb start && '
                      'service nfs start')

    def stop_services(self):
        self.ssh_exec('service vsftpd stop && '
                      'service dhcpd stop && '
                      'service xinetd stop && '
                      'service httpd stop && '
                      'service smb stop && '
                      'service nmb stop && '
                      'service nfs stop && '
                      'ifdown eth1')

    def install_tftp_files(self, os_name):
        import time
        self.ssh_exec('mkdir -p /tftpboot')
        # self.ssh_exec('mkdir -p /buptftpboot')
        # self.ssh_exec('mv -v -f /tftpboot /buptftpboot/tftpboot'+str(int(time.time())))
        self.ssh_exec('cp -v -r /tftpboot.template.'+os_name+'/* /tftpboot/')
        # self.ssh_exec('chcon -Rv -t tftpdir_rw_t /tftpboot')