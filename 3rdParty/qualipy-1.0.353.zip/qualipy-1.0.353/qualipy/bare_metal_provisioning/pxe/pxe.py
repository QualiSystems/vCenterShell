import sys
sys.path.append('../../../')

from qualipy.common.libs.qs_logger import setupLogger
from qualipy.common.libs.ssh_manager import SSHManager
import os
import time

def log(s):
    with open(os.environ['TEMP']+'/qs_esxi_pxe.log', 'a') as f:
        f.write(s+'\n')
        # print(s)

def sshexec(ssh_client, command):
    log('Executing '+command)
    stdio,stdout,stderr=ssh_client.execute(command)
    rv = '\n'.join(map(lambda s: s.strip(),stdout))
    log('Result: '+rv)
    return rv

def writefile(client, filename, text):
    sshexec(client, 'cat > '+filename+' <<"EOFMARKER"\n'+text+'\nEOFMARKER')


class pxe:
    import sys

    def get_pxelinux_cfg(self):
        return "# Error - need to override get_pxelinux_cfg() in your pxe class"

    def set_dhcp(self, pxeIP, pxeUser, pxePassword, csvMacs, isoPathOnVtgShare, rootPassword, mgmtVlan, ip, netmask, gateway,
             dns1, dns2):
        logger = setupLogger('test', logFile = 'test')
        client = SSHManager(pxeUser, pxePassword, pxeIP, 22, timeout = 4, logger = logger)
        client.connect()
        sshexec(client, "ls")
        sshexec(client, "sleep 5")

        tftproot='/tftpboot'
        apacheroot='/var/www/html'
        vtgshare='/vtgshare'
        vtgshareisopath=isoPathOnVtgShare.replace('\\','/')
        isomount=tftproot+'/esxi/'+os.path.basename(vtgshareisopath).replace(' ','_')

        ans = sshexec(client,'mkdir -m 777 -p '+isomount)

        ans = sshexec(client,'[ -f '+isomount+'/boot.cfg ] || mount "'+vtgshare+'/'+vtgshareisopath+'" -o loop,ro '+isomount)

        for mac in str.split(csvMacs,','):
            macUcaseColons=str.upper(mac.replace('-',':'))
            macLcaseColons=str.lower(mac.replace('-',':'))
            macUcaseDashes=str.upper(mac.replace(':','-'))
            macLcaseDashes=str.lower(mac.replace(':','-'))
            macUcaseUnderscores=str.upper(mac.replace(':','_').replace('-','_'))
            macLcaseUnderscores=str.lower(mac.replace(':','_').replace('-','_'))

            ans = sshexec(client,'sed -i -e /'+macLcaseUnderscores+'/d /etc/dnsmasq.conf')

            ans = sshexec(client,'grep PROTOTYPE /etc/dnsmasq.conf')

            newline=ans.replace('PROTOTYPE','j'+macLcaseUnderscores)
            ans = sshexec(client,'echo '+newline+' >> /etc/dnsmasq.conf')
            ans = sshexec(client,'echo "dhcp-mac=set:j'+macLcaseUnderscores+','+macLcaseColons+'" >> /etc/dnsmasq.conf')

            ans = sshexec(client,'rm -f '+tftproot+'/files/cd_'+macLcaseDashes)
            ans = sshexec(client,'ln -s '+isomount+' '+tftproot+'/esxi/cd_'+macLcaseDashes)

            ans = sshexec(client,'sed -e "s#/#/files/cd_'+macLcaseDashes+'/#g; s#runweasel#runweasel ks=http://'+pxeIP+'/esxi/ks_'+macLcaseDashes+'.cfg#" '+tftproot+'/esxi/cd_'+macLcaseDashes+'/boot.cfg > '+tftproot+'/esxi/boot_'+macLcaseDashes+'.cfg')

            writefile(client, tftproot+'/pxelinux.cfg/01-'+macLcaseDashes, '''TIMEOUT 1 # 3 seconds
PROMPT 1
DEFAULT vga
SAY -
SAY vga - QualiSystems_ESXi_installer
SAY -

LABEL vga
KERNEL esxi/cd_'''+macLcaseDashes+'''/mboot.c32
APPEND -c esxi/boot_'''+macLcaseDashes+'''.cfg
IPAPPEND 2
''')

            writefile(client, apacheroot+'/esxi/ks_'+macLcaseDashes+'.cfg', '''vmaccepteula

rootpw '''+rootPassword+'''

install --disk=mpx.vmhba32:C0:T0:L0 --overwritevmfs

%post  --interpreter=busybox
sleep 30
reboot

%firstboot --interpreter=busybox

vim-cmd hostsvc/enable_esx_shell
vim-cmd hostsvc/start_esx_shell

esxcli network vswitch standard uplink add -u vmnic2 -v vSwitch0
esxcli network vswitch standard uplink add -u vmnic3 -v vSwitch0

esxcli network vswitch standard uplink remove -u vmnic0 -v vSwitch0
esxcli network vswitch standard uplink remove -u vmnic1 -v vSwitch0

esxcli network vswitch standard policy failover set -v vSwitch0 -a vmnic2,vmnic3 -l iphash
esxcli network vswitch standard portgroup policy failover set -p "Management Network" -u
esxcli network vswitch standard add -v vSwitchAMP2

esxcli network vswitch standard portgroup set -p "Management Network" -v '''+str(mgmtVlan)+'''
esxcli network ip interface ipv4 set -i vmk0 --ipv4 '''+ip+''' --netmask '''+netmask+''' --type static
esxcli network ip route ipv4 add -g '''+gateway+''' -n default
esxcli network ip dns server add -s '''+dns1+'''
esxcli network ip dns server add -s '''+dns2+'''

    ''')

        ans = sshexec(client, 'cat /etc/dnsmasq.conf')
        ans = sshexec(client, 'service dnsmasq restart')
        client.disconnect()
        return 'Success'
