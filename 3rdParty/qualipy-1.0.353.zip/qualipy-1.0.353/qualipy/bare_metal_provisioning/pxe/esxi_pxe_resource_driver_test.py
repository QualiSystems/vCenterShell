__author__ = 'eric.r'
import sys
sys.path.append('../../../')

from bare_metal_provisioning.pxe.esxi_pxe_resource_driver import ESXiPXEResourceDriver

matrixjson = '''{
    "resource": {
        "ResourceAddress" : "192.168.41.74",
        "User" : "root",
        "Password" : "Password1",
        "PXE IP" : "10.0.0.3",
        "PXE Mask" : "255.255.255.0",
        "DHCP Range Start" : "10.0.0.10",
        "DHCP Range End" : "10.0.0.50",

        "ISO Path" : "\\\\\\\\192.168.41.54\\\\c$\\\\VMware-VMvisor-Installer-5.5.0.update01-1623387.x86_64.iso",
        "ISO Domain" : "192.168.41.54",
        "ISO User" : "qauser",
        "ISO Password": "qa1234",

        "OS Name" : "esxi",
        "Enable MAC Filter" : "false"
    }
}'''

driver = ESXiPXEResourceDriver('a13241234123', matrixjson)

driver.ConfigurePXE(matrixjson)

driver.InstallESXi(matrixjson, '00:50:56:be:74:26', '@Vantage123', '2453',
                   '10.11.79.15', '255.255.255.128', '10.11.79.1', '10.11.79.216', '10.11.79.217')

driver.InstallESXi(matrixjson, '00:50:56:be:33:2d', '@Vantage123', '2453',
                   '10.11.79.15', '255.255.255.128', '10.11.79.1', '10.11.79.216', '10.11.79.217')


#
# set_dhcp("10.11.34.81", "root", "@Vantage123", '90:e2:ba:79:d9:e0,90:e2:ba:79:d9:e1,50:87:89:b7:09:fe,50:87:89:b7:09:ff',
#          'software/Component/VMware/vSphere5/CustomISOs-QA/2015 April/ESXi-5.5.0-2403361-vce-4.5.12_Vb200.iso',
#          '@Vantage123', '2453', '10.11.79.15', '255.255.255.128', '10.11.79.1', '10.11.79.216', '10.11.79.217')
# wait_for_pxe_boot("10.11.34.81", "root", "@Vantage123", '90:e2:ba:79:d9:e0,90:e2:ba:79:d9:e1,50:87:89:b7:09:fe,50:87:89:b7:09:ff')
