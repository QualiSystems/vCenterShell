__author__ = 'eric.r'
import sys
sys.path.append('../../../')

from bare_metal_provisioning.pxe.windows_pxe_resource_driver import WindowsPXEResourceDriver

matrixjson = '''{
    "resource": {
        "ResourceAddress" : "192.168.41.74",
        "User" : "root",
        "Password" : "Password1",
        "PXE IP" : "192.168.28.162",
        "PXE Mask" : "255.255.255.0",
        "DHCP Range Start" : "192.168.28.190",
        "DHCP Range End" : "192.168.28.220",

        "ISO Path" : "\\\\\\\\192.168.41.54\\\\c$\\\\Server 2012 HRM_SSS_X64FRE_EN-US_DV5.iso",


        "ISO Domain" : "192.168.41.54",
        "ISO User" : "qauser",
        "ISO Password": "qa1234",

        "OS Name" : "windows",
        "Enable MAC Filter" : "false"
    }
}'''

# "ISO Path" : "\\\\\\\\192.168.41.54\\\\c$\\\\en_windows_7_ultimate_with_sp1_x64_dvd_u_677332.iso",

# "ISO Path" : "\\\\\\\\192.168.41.54\\\\c$\\\\en_windows_server_2008_r2_with_sp1_x64_dvd_617601.iso",


driver = WindowsPXEResourceDriver('a13241234123', matrixjson)

driver.ConfigurePXE(matrixjson)

driver.InstallWindows(matrixjson, '00:50:56:be:5c:0d',
                      # 'Windows 7 Professional', 'FJ82H-XT6CR-J8D7P-XQJJ2-GPDD4',
                      # 'Windows Server 2008 R2 SERVERENTERPRISE', '489J6-VHDMP-X63PK-3K798-CPX3Y',

                      'Windows Server 2012 SERVERSTANDARD', 'XC9B7-NBPP2-83J2H-RHMBY-92BT4',
                      'qualitest', 'qualitestorg', 'qualixwin', 'Password1', 'be5c0d')

#
# driver.InstallESXi(matrixjson, '00:50:56:be:74:26', '@Vantage123', '2453',
#                    '10.11.79.15', '255.255.255.128', '10.11.79.1', '10.11.79.216', '10.11.79.217')
#
# driver.InstallESXi(matrixjson, '00:50:56:be:33:2d', '@Vantage123', '2453',
#                    '10.11.79.15', '255.255.255.128', '10.11.79.1', '10.11.79.216', '10.11.79.217')
#

#
# set_dhcp("10.11.34.81", "root", "@Vantage123", '90:e2:ba:79:d9:e0,90:e2:ba:79:d9:e1,50:87:89:b7:09:fe,50:87:89:b7:09:ff',
#          'software/Component/VMware/vSphere5/CustomISOs-QA/2015 April/ESXi-5.5.0-2403361-vce-4.5.12_Vb200.iso',
#          '@Vantage123', '2453', '10.11.79.15', '255.255.255.128', '10.11.79.1', '10.11.79.216', '10.11.79.217')
# wait_for_pxe_boot("10.11.34.81", "root", "@Vantage123", '90:e2:ba:79:d9:e0,90:e2:ba:79:d9:e1,50:87:89:b7:09:fe,50:87:89:b7:09:ff')
