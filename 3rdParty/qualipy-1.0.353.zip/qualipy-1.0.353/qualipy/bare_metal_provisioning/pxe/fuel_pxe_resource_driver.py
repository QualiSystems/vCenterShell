import sys
sys.path.append('../../../')

from qualipy.bare_metal_provisioning.pxe.pxe_resource_driver import PXEResourceDriver
from qualipy.common.libs.driver_builder_wrapper import DriverFunction

import json

class FuelPXEResourceDriver(PXEResourceDriver):
    @DriverFunction(extraMatrixRows={'resource': [
        'PXE IP',
        'PXE Mask',
        'DHCP Range Start',
        'DHCP Range End',
        'Enable MAC Filter',

        'ISO Path',
        'ISO Domain',
        'ISO Path',
        'ISO Password',

        'OS Name',

        'Public IP',
        'Public Mask',
        'Public Gateway',
        'FQDN',
        'DNS Servers',
    ]})
    def ConfigurePXE(self, matrix_json):
        PXEResourceDriver.ConfigurePXE(self, matrix_json)

    def os_specific_global_tasks(self, matrix_json):
        o = json.loads(matrix_json)
        self.generate_file_from_template(
            '/tftpboot/pxelinux.cfg/fuel.template',
            '/tftpboot/pxelinux.cfg/default',
            {
                'privateip': o['resource']['PXE IP'],
                'mask': o['resource']['PXE Mask'],
                'publicip': o['resource']['Public IP'],
                'publicmask': o['resource']['Public Mask'],
                'publicgateway': o['resource']['Public Gateway'],
                'targetip': o['resource']['PXE IP'],
                'fqdn': o['resource']['FQDN'],
                'dns1': o['resource']['DNS Servers'].split(',')[0].strip(),
                'dns2': o['resource']['DNS Servers'].split(',')[-1].strip(),
            })
