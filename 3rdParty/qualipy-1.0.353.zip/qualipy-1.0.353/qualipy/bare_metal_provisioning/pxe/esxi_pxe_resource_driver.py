__author__ = 'eric.r'
import sys
sys.path.append('../../../')

from qualipy.bare_metal_provisioning.pxe.pxe_resource_driver import PXEResourceDriver
from qualipy.common.libs.driver_builder_wrapper import DriverFunction

import json

class ESXiPXEResourceDriver(PXEResourceDriver):

    @DriverFunction
    def InstallESXi(self, matrix_json, csvMacs, rootPassword, mgmtVlan, ip, netmask, gateway, dns1, dns2):
        o = json.loads(matrix_json)
        pxe_ip = o['resource']['ResourceAddress']
        for mac in csvMacs.split(','):
            mac_lcase_dashes = mac.strip().lower().replace(':', '-')
            mac_ucase_dashes = mac.strip().upper().replace(':', '-')
            mac_lcase_colons = mac.strip().lower().replace('-', ':')
            mac_ucase_colons = mac.strip().upper().replace('-', ':')

            self.EnableMAC(matrix_json, mac_lcase_colons)

            pxelinuxcfg_filename = '01-'+mac_lcase_dashes
            pxelinuxcfg_path = '/tftpboot/pxelinux.cfg/'+pxelinuxcfg_filename

            bootcfg_filename = 'boot_'+mac_lcase_dashes+'.cfg'
            bootcfg_path = '/tftpboot/'+bootcfg_filename

            kscfg_filename = 'ks_'+mac_lcase_dashes+'.cfg'
            kscfg_path = '/var/www/html/esxi/'+kscfg_filename

            self.ssh_exec('mkdir -p /var/www/html/esxi/')

            self.generate_file_from_template('/tftpboot/ks.cfg.template', kscfg_path, {
                'rootPassword': rootPassword,
                'mgmtVlan': mgmtVlan,
                'mgmtIP': ip,
                'mgmtNetmask': netmask,
                'gateway': gateway,
                'dns1': dns1,
                'dns2': dns2,
            })
            self.generate_file_from_template('/tftpboot/pxelinux.cfg/esxi.template', pxelinuxcfg_path, {
                'bootCfgFilename': bootcfg_filename,
            })
            self.ssh_exec('sed -e '
                          '"s#/#/esxi_iso/#g; '
                          's#runweasel#runweasel ks=http://'+pxe_ip+':81/esxi/'+kscfg_filename+'#" '
                          '/tftpboot/esxi_iso/boot.cfg '
                          '> '+bootcfg_path)
