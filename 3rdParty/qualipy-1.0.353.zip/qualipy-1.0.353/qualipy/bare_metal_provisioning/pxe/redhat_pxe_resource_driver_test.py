__author__ = 'eric.r'
import sys
sys.path.append('../../../')

from bare_metal_provisioning.pxe.redhat_pxe_resource_driver import RedhatPXEResourceDriver

matrixjson = '''{
    "resource": {
        "ResourceAddress" : "192.168.41.74",
        "User" : "root",
        "Password" : "Password1",
        "PXE IP" : "10.0.0.3",
        "PXE Mask" : "255.255.255.0",
        "DHCP Range Start" : "10.0.0.10",
        "DHCP Range End" : "10.0.0.50",

        "ISO Path" : "\\\\\\\\192.168.41.54\\\\c$\\\\CentOS-7-x86_64-Minimal-1503-01.iso",
        "ISO Domain" : "192.168.41.54",
        "ISO User" : "qauser",
        "ISO Password": "qa1234",

        "OS Name" : "redhat",
        "Enable MAC Filter" : "false"
    }
}'''

driver = RedhatPXEResourceDriver('a132412341239', matrixjson)

driver.ConfigurePXE(matrixjson)

# driver.InstallRedhat(matrixjson, '00:50:56:be:73:37', 'drivertest1', 'quali1234')
