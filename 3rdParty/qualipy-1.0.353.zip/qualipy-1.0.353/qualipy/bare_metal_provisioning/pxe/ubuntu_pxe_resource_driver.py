__author__ = 'eric.r'
import sys
sys.path.append('../../../')

from qualipy.bare_metal_provisioning.pxe.pxe_resource_driver import PXEResourceDriver
from qualipy.common.libs.driver_builder_wrapper import DriverFunction

import json

class UbuntuPXEResourceDriver(PXEResourceDriver):
    def os_specific_global_tasks(self, matrix_json):
        o = json.loads(matrix_json)

        self.generate_file_from_template(
            '/tftpboot/pxelinux.cfg/ubuntu.template',
            '/tftpboot/pxelinux.cfg/default',
            {
                'macAddress' : 'default',
                'hostname' : 'qsdefault',
                'bootServer' : o['resource']['PXE IP']
            }
        )
        self.generate_file_from_template('/tftpboot/preseed.cfg.template','/tftpboot/preseed_default.cfg', {
            'QS_ROOT_PASSWORD': 'Password1',
            'QS_NEW_USER_FULL_NAME': 'qualiuser',
            'QS_NEW_USER_NAME': 'qualiuser',
            'QS_NEW_USER_PASSWORD': 'Password1',
            'QS_BOOT_SERVER': o['resource']['PXE IP']
        })
        self.ssh_exec('rm -v -f /var/www/html/ubuntu')
        self.ssh_exec('ln -v -s /tftpboot/ubuntu_iso_mount /var/www/html/ubuntu')

    @DriverFunction
    def InstallUbuntu(self, matrix_json, mac_address, root_password, new_user_name, new_user_password):
        o = json.loads(matrix_json)

        mac_lcase_dashes = str.lower(mac_address.replace(':','-'))
        mac_ucase_dashes = str.upper(mac_address.replace(':','-'))

        self.generate_file_from_template(
            '/tftpboot/pxelinux.cfg/ubuntu.template',
            '/tftpboot/pxelinux.cfg/01-'+mac_lcase_dashes,
            {
                'macAddress' : mac_lcase_dashes,
                'hostname' : 'qsdefault',
                'bootServer' : o['resource']['PXE IP']
            }
        )
        self.generate_file_from_template('/tftpboot/preseed.cfg.template','/var/www/html/preseed_'+mac_lcase_dashes+'.cfg', {
            'QS_ROOT_PASSWORD': root_password,
            'QS_NEW_USER_FULL_NAME': new_user_name,
            'QS_NEW_USER_NAME': new_user_name,
            'QS_NEW_USER_PASSWORD': new_user_password,
            'QS_BOOT_SERVER': o['resource']['PXE IP']
        })
