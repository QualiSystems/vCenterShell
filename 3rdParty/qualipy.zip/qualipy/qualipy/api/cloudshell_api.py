# This Python file uses the following encoding: utf-8
# Generated at 2015-09-29 13:02:18 -0400
# with jruby python_xsd_rpc.rb ApiCommandResult.xsd commands.xml ../../Packages/qualipy/api/cloudshell_api.py 
# $/QualiSystems/Branches/6.3/Setup/Output/Suite/API/TestShell API/TestShell TCL API
# $/QualiSystems/Branches/6.3/TestShell/QS.TestShell.Server/ResourceManagement/Plugins/ApiPlugin
class ResponseInfo(object):
    def __init__(self, node):
        pass

class ApiCommandResult(object):
    def __init__(self, node):
        v = ''
        for ch in node:
            if ch.tag == 'Error' or '}Error#' in ch.tag+'#':
                v = ch.text
        self.Error = v
        """:type : str"""

        v = ''
        for ch in node:
            if ch.tag == 'ErrorCode' or '}ErrorCode#' in ch.tag+'#':
                v = ch.text
        if v == '':
            v = 0
        else:
            v = int(v)
        self.ErrorCode = v
        """:type : int"""

        v = None
        for ch in node:
            if ch.tag == 'ResponseInfo' or '}ResponseInfo#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ResponseInfo(ch)
        self.ResponseInfo = v
        """:type : ResponseInfo"""

        if 'CommandName' in node.attrib:
            v = node.attrib['CommandName']
        else:
            v = ''
        self.CommandName = v
        """:type : str"""

        if 'Success' in node.attrib:
            v = node.attrib['Success']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Success = v
        """:type : boolean"""


class ResourceLockInfo(object):
    def __init__(self, node):
        if 'ReservationName' in node.attrib:
            v = node.attrib['ReservationName']
        else:
            v = ''
        self.ReservationName = v
        """:type : str"""

        if 'MachineName' in node.attrib:
            v = node.attrib['MachineName']
        else:
            v = ''
        self.MachineName = v
        """:type : str"""

        if 'Username' in node.attrib:
            v = node.attrib['Username']
        else:
            v = ''
        self.Username = v
        """:type : str"""

        if 'Created' in node.attrib:
            v = node.attrib['Created']
        else:
            v = ''
        self.Created = v
        """:type : str"""


class TopologyShortInfo(object):
    def __init__(self, node):
        v = ''
        for ch in node:
            if ch.tag == 'Type' or '}Type#' in ch.tag+'#':
                v = ch.text
        self.Type = v
        """:type : str"""

        v = ''
        for ch in node:
            if ch.tag == 'State' or '}State#' in ch.tag+'#':
                v = ch.text
        self.State = v
        """:type : str"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""


class DomainInfo(ResponseInfo):
    def __init__(self, node):
        super(DomainInfo, self).__init__(node)
        self.Groups = []
        """:type : list[Group]"""
        for ch in node:
            if ch.tag == 'Groups' or '}Groups#' in ch.tag+'#':
                for ch2 in ch:
                    self.Groups.append(Group(ch2))

        self.Topologies = []
        """:type : list[Topology]"""
        for ch in node:
            if ch.tag == 'Topologies' or '}Topologies#' in ch.tag+'#':
                for ch2 in ch:
                    self.Topologies.append(Topology(ch2))

        self.Resources = []
        """:type : list[Resource]"""
        for ch in node:
            if ch.tag == 'Resources' or '}Resources#' in ch.tag+'#':
                for ch2 in ch:
                    self.Resources.append(Resource(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'TopologiesFolder' in node.attrib:
            v = node.attrib['TopologiesFolder']
        else:
            v = ''
        self.TopologiesFolder = v
        """:type : str"""

        if 'Archived ' in node.attrib:
            v = node.attrib['Archived ']
        else:
            v = ''
        self.Archived  = v
        """:type : str"""


class Group(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'Role' in node.attrib:
            v = node.attrib['Role']
        else:
            v = ''
        self.Role = v
        """:type : str"""


class Topology(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""


class Resource(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Path' in node.attrib:
            v = node.attrib['Path']
        else:
            v = ''
        self.Path = v
        """:type : str"""


class ResourceInfo(ResponseInfo):
    def __init__(self, node):
        super(ResourceInfo, self).__init__(node)
        self.ResourceAttributes = []
        """:type : list[ResourceAttribute]"""
        for ch in node:
            if ch.tag == 'ResourceAttributes' or '}ResourceAttributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.ResourceAttributes.append(ResourceAttribute(ch2))

        self.Domains = []
        """:type : list[Domain]"""
        for ch in node:
            if ch.tag == 'Domains' or '}Domains#' in ch.tag+'#':
                for ch2 in ch:
                    self.Domains.append(Domain(ch2))

        self.ChildResources = []
        """:type : list[ResourceInfo]"""
        for ch in node:
            if ch.tag == 'ChildResources' or '}ChildResources#' in ch.tag+'#':
                for ch2 in ch:
                    self.ChildResources.append(ResourceInfo(ch2))

        v = None
        for ch in node:
            if ch.tag == 'LockInfo' or '}LockInfo#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ResourceLockInfo(ch)
        self.LockInfo = v
        """:type : ResourceLockInfo"""

        self.Connections = []
        """:type : list[Connection]"""
        for ch in node:
            if ch.tag == 'Connections' or '}Connections#' in ch.tag+'#':
                self.Connections.append(Connection(ch))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'DriverName' in node.attrib:
            v = node.attrib['DriverName']
        else:
            v = ''
        self.DriverName = v
        """:type : str"""

        if 'FolderFullPath' in node.attrib:
            v = node.attrib['FolderFullPath']
        else:
            v = ''
        self.FolderFullPath = v
        """:type : str"""

        if 'Address' in node.attrib:
            v = node.attrib['Address']
        else:
            v = ''
        self.Address = v
        """:type : str"""

        if 'FullAddress' in node.attrib:
            v = node.attrib['FullAddress']
        else:
            v = ''
        self.FullAddress = v
        """:type : str"""

        if 'RootAddress' in node.attrib:
            v = node.attrib['RootAddress']
        else:
            v = ''
        self.RootAddress = v
        """:type : str"""

        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""

        if 'Locked' in node.attrib:
            v = node.attrib['Locked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Locked = v
        """:type : boolean"""

        if 'Excluded' in node.attrib:
            v = node.attrib['Excluded']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Excluded = v
        """:type : boolean"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'Permission' in node.attrib:
            v = node.attrib['Permission']
        else:
            v = ''
        self.Permission = v
        """:type : str"""

        if 'UniqeIdentifier' in node.attrib:
            v = node.attrib['UniqeIdentifier']
        else:
            v = ''
        self.UniqeIdentifier = v
        """:type : str"""

        if 'ResourceLiveStatusName' in node.attrib:
            v = node.attrib['ResourceLiveStatusName']
        else:
            v = ''
        self.ResourceLiveStatusName = v
        """:type : str"""

        if 'ResourceLiveStatusDescription' in node.attrib:
            v = node.attrib['ResourceLiveStatusDescription']
        else:
            v = ''
        self.ResourceLiveStatusDescription = v
        """:type : str"""


class ResourceAttribute(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""


class Domain(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""


class Connection(object):
    def __init__(self, node):
        if 'FullPath' in node.attrib:
            v = node.attrib['FullPath']
        else:
            v = ''
        self.FullPath = v
        """:type : str"""

        if 'Weight' in node.attrib:
            v = node.attrib['Weight']
        else:
            v = ''
        if v == '':
            v = 0
        else:
            v = int(v)
        self.Weight = v
        """:type : int"""


class ResourceLiveStatusInfo(ResponseInfo):
    def __init__(self, node):
        super(ResourceLiveStatusInfo, self).__init__(node)
        if 'liveStatusName' in node.attrib:
            v = node.attrib['liveStatusName']
        else:
            v = ''
        self.liveStatusName = v
        """:type : str"""

        if 'liveStatusDescription' in node.attrib:
            v = node.attrib['liveStatusDescription']
        else:
            v = ''
        self.liveStatusDescription = v
        """:type : str"""


class ReservationLiveStatusInfo(ResponseInfo):
    def __init__(self, node):
        super(ReservationLiveStatusInfo, self).__init__(node)
        self.ReservationLiveStatuses = []
        """:type : list[ReservationLiveStatus]"""
        for ch in node:
            if ch.tag == 'ReservationLiveStatuses' or '}ReservationLiveStatuses#' in ch.tag+'#':
                for ch2 in ch:
                    self.ReservationLiveStatuses.append(ReservationLiveStatus(ch2))


class ReservationLiveStatus(object):
    def __init__(self, node):
        if 'ReservationId' in node.attrib:
            v = node.attrib['ReservationId']
        else:
            v = ''
        self.ReservationId = v
        """:type : str"""

        if 'ReservationLiveStatusName' in node.attrib:
            v = node.attrib['ReservationLiveStatusName']
        else:
            v = ''
        self.ReservationLiveStatusName = v
        """:type : str"""

        if 'ReservationLiveStatusDescription' in node.attrib:
            v = node.attrib['ReservationLiveStatusDescription']
        else:
            v = ''
        self.ReservationLiveStatusDescription = v
        """:type : str"""


class EndPointConnectionInfo(ResponseInfo):
    def __init__(self, node):
        super(EndPointConnectionInfo, self).__init__(node)
        self.Routes = []
        """:type : list[RouteInfo]"""
        for ch in node:
            if ch.tag == 'Routes' or '}Routes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Routes.append(RouteInfo(ch2))


class VisualConnectorsInfo(ResponseInfo):
    def __init__(self, node):
        super(VisualConnectorsInfo, self).__init__(node)
        self.Connectors = []
        """:type : list[Connector]"""
        for ch in node:
            if ch.tag == 'Connectors' or '}Connectors#' in ch.tag+'#':
                for ch2 in ch:
                    self.Connectors.append(Connector(ch2))


class TopologyResourceInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologyResourceInfo, self).__init__(node)
        self.ResourceAttributes = []
        """:type : list[ResourceAttribute2]"""
        for ch in node:
            if ch.tag == 'ResourceAttributes' or '}ResourceAttributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.ResourceAttributes.append(ResourceAttribute2(ch2))

        v = None
        for ch in node:
            if ch.tag == 'LockInfo' or '}LockInfo#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ResourceLockInfo(ch)
        self.LockInfo = v
        """:type : ResourceLockInfo"""

        self.Connections = []
        """:type : list[Connection2]"""
        for ch in node:
            if ch.tag == 'Connections' or '}Connections#' in ch.tag+'#':
                self.Connections.append(Connection2(ch))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'FolderFullPath' in node.attrib:
            v = node.attrib['FolderFullPath']
        else:
            v = ''
        self.FolderFullPath = v
        """:type : str"""

        if 'Address' in node.attrib:
            v = node.attrib['Address']
        else:
            v = ''
        self.Address = v
        """:type : str"""

        if 'FullAddress' in node.attrib:
            v = node.attrib['FullAddress']
        else:
            v = ''
        self.FullAddress = v
        """:type : str"""

        if 'RootAddress' in node.attrib:
            v = node.attrib['RootAddress']
        else:
            v = ''
        self.RootAddress = v
        """:type : str"""

        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""

        if 'Locked' in node.attrib:
            v = node.attrib['Locked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Locked = v
        """:type : boolean"""

        if 'Excluded' in node.attrib:
            v = node.attrib['Excluded']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Excluded = v
        """:type : boolean"""

        if 'WillBeLocked' in node.attrib:
            v = node.attrib['WillBeLocked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.WillBeLocked = v
        """:type : boolean"""


class ResourceAttribute2(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""


class Connection2(object):
    def __init__(self, node):
        if 'FullPath' in node.attrib:
            v = node.attrib['FullPath']
        else:
            v = ''
        self.FullPath = v
        """:type : str"""


class ActiveTopologyResourceInfo(ResponseInfo):
    def __init__(self, node):
        super(ActiveTopologyResourceInfo, self).__init__(node)
        self.ResourceAttributes = []
        """:type : list[ResourceAttribute3]"""
        for ch in node:
            if ch.tag == 'ResourceAttributes' or '}ResourceAttributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.ResourceAttributes.append(ResourceAttribute3(ch2))

        v = None
        for ch in node:
            if ch.tag == 'LockInfo' or '}LockInfo#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ResourceLockInfo(ch)
        self.LockInfo = v
        """:type : ResourceLockInfo"""

        self.Connections = []
        """:type : list[Connection3]"""
        for ch in node:
            if ch.tag == 'Connections' or '}Connections#' in ch.tag+'#':
                self.Connections.append(Connection3(ch))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'FolderFullPath' in node.attrib:
            v = node.attrib['FolderFullPath']
        else:
            v = ''
        self.FolderFullPath = v
        """:type : str"""

        if 'Address' in node.attrib:
            v = node.attrib['Address']
        else:
            v = ''
        self.Address = v
        """:type : str"""

        if 'FullAddress' in node.attrib:
            v = node.attrib['FullAddress']
        else:
            v = ''
        self.FullAddress = v
        """:type : str"""

        if 'RootAddress' in node.attrib:
            v = node.attrib['RootAddress']
        else:
            v = ''
        self.RootAddress = v
        """:type : str"""

        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""

        if 'Locked' in node.attrib:
            v = node.attrib['Locked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Locked = v
        """:type : boolean"""


class ResourceAttribute3(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""


class Connection3(object):
    def __init__(self, node):
        if 'FullPath' in node.attrib:
            v = node.attrib['FullPath']
        else:
            v = ''
        self.FullPath = v
        """:type : str"""


class TopologyAbstractResourceInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologyAbstractResourceInfo, self).__init__(node)
        self.Attributes = []
        """:type : list[AbstractResourceAttribute]"""
        for ch in node:
            if ch.tag == 'Attributes' or '}Attributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Attributes.append(AbstractResourceAttribute(ch2))

        self.RequiredAttributes = []
        """:type : list[AbstractResourceRequiredAttribute]"""
        for ch in node:
            if ch.tag == 'RequiredAttributes' or '}RequiredAttributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.RequiredAttributes.append(AbstractResourceRequiredAttribute(ch2))

        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""

        if 'WillBeLocked' in node.attrib:
            v = node.attrib['WillBeLocked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.WillBeLocked = v
        """:type : boolean"""

        if 'Valid' in node.attrib:
            v = node.attrib['Valid']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Valid = v
        """:type : boolean"""

        if 'Quantity' in node.attrib:
            v = node.attrib['Quantity']
        else:
            v = ''
        if v == '':
            v = 0
        else:
            v = int(v)
        self.Quantity = v
        """:type : int"""


class AbstractResourceAttribute(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""


class AbstractResourceRequiredAttribute(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""


class RouteSegmentInfo(object):
    def __init__(self, node):
        if 'Source' in node.attrib:
            v = node.attrib['Source']
        else:
            v = ''
        self.Source = v
        """:type : str"""

        if 'Target' in node.attrib:
            v = node.attrib['Target']
        else:
            v = ''
        self.Target = v
        """:type : str"""


class RouteInfo(object):
    def __init__(self, node):
        self.Segments = []
        """:type : list[RouteSegmentInfo]"""
        for ch in node:
            if ch.tag == 'Segments' or '}Segments#' in ch.tag+'#':
                for ch2 in ch:
                    self.Segments.append(RouteSegmentInfo(ch2))

        self.Attributes = []
        """:type : list[RouteAttributeInfo]"""
        for ch in node:
            if ch.tag == 'Attributes' or '}Attributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Attributes.append(RouteAttributeInfo(ch2))

        v = None
        for ch in node:
            if ch.tag == 'RouteConfiguration' or '}RouteConfiguration#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = RouteConfigurationInfo(ch)
        self.RouteConfiguration = v
        """:type : RouteConfigurationInfo"""

        if 'IsTap' in node.attrib:
            v = node.attrib['IsTap']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.IsTap = v
        """:type : boolean"""

        if 'Source' in node.attrib:
            v = node.attrib['Source']
        else:
            v = ''
        self.Source = v
        """:type : str"""

        if 'Target' in node.attrib:
            v = node.attrib['Target']
        else:
            v = ''
        self.Target = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""

        if 'RouteType' in node.attrib:
            v = node.attrib['RouteType']
        else:
            v = ''
        self.RouteType = v
        """:type : str"""

        if 'Shared' in node.attrib:
            v = node.attrib['Shared']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Shared = v
        """:type : boolean"""


class Connector(object):
    def __init__(self, node):
        self.Attributes = []
        """:type : list[AttributeValueInfo]"""
        for ch in node:
            if ch.tag == 'Attributes' or '}Attributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Attributes.append(AttributeValueInfo(ch2))

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""

        if 'Direction' in node.attrib:
            v = node.attrib['Direction']
        else:
            v = ''
        self.Direction = v
        """:type : str"""

        if 'Source' in node.attrib:
            v = node.attrib['Source']
        else:
            v = ''
        self.Source = v
        """:type : str"""

        if 'Target' in node.attrib:
            v = node.attrib['Target']
        else:
            v = ''
        self.Target = v
        """:type : str"""


class RouteConfigurationInfo(object):
    def __init__(self, node):
        v = None
        for ch in node:
            if ch.tag == 'Speed' or '}Speed#' in ch.tag+'#':
                v = long(ch.text if ch.text else 0)
        self.Speed = v
        """:type : long"""

        v = None
        for ch in node:
            if ch.tag == 'Interface' or '}Interface#' in ch.tag+'#':
                v = long(ch.text if ch.text else 0)
        self.Interface = v
        """:type : long"""

        v = None
        for ch in node:
            if ch.tag == 'Duplex' or '}Duplex#' in ch.tag+'#':
                v = long(ch.text if ch.text else 0)
        self.Duplex = v
        """:type : long"""

        v = ''
        for ch in node:
            if ch.tag == 'SpeedSetting' or '}SpeedSetting#' in ch.tag+'#':
                v = ch.text
        self.SpeedSetting = v
        """:type : str"""


class RouteAttributeInfo(object):
    def __init__(self, node):
        v = ''
        for ch in node:
            if ch.tag == 'AttributeName' or '}AttributeName#' in ch.tag+'#':
                v = ch.text
        self.AttributeName = v
        """:type : str"""

        v = ''
        for ch in node:
            if ch.tag == 'AttributeValue' or '}AttributeValue#' in ch.tag+'#':
                v = ch.text
        self.AttributeValue = v
        """:type : str"""


class CategoryListInfo(ResponseInfo):
    def __init__(self, node):
        super(CategoryListInfo, self).__init__(node)
        self.Categories = []
        """:type : list[str]"""
        for ch in node:
            if ch.tag == 'Categories' or '}Categories#' in ch.tag+'#':
                for ch2 in ch:
                    self.Categories.append(ch2.text)


class TopologiesByCategoryInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologiesByCategoryInfo, self).__init__(node)
        self.Topologies = []
        """:type : list[str]"""
        for ch in node:
            if ch.tag == 'Topologies' or '}Topologies#' in ch.tag+'#':
                for ch2 in ch:
                    self.Topologies.append(ch2.text)


class CategoriesOfTopologyInfo(ResponseInfo):
    def __init__(self, node):
        super(CategoriesOfTopologyInfo, self).__init__(node)
        self.Categories = []
        """:type : list[TopologyCategoryInfo]"""
        for ch in node:
            if ch.tag == 'Categories' or '}Categories#' in ch.tag+'#':
                for ch2 in ch:
                    self.Categories.append(TopologyCategoryInfo(ch2))


class TopologyCategoryInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologyCategoryInfo, self).__init__(node)
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""


class TopologyInputsInfo(object):
    def __init__(self, node):
        self.PossibleValues = []
        """:type : list[str]"""
        for ch in node:
            self.PossibleValues.append(ch.text)

        if 'ParamName' in node.attrib:
            v = node.attrib['ParamName']
        else:
            v = ''
        self.ParamName = v
        """:type : str"""

        if 'DefaultValue' in node.attrib:
            v = node.attrib['DefaultValue']
        else:
            v = ''
        self.DefaultValue = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""


class TopologyGlobalInputsInfo(TopologyInputsInfo):
    def __init__(self, node):
        super(TopologyGlobalInputsInfo, self).__init__(node)
        pass

class TopologyAdditionalInfoInputsInfo(TopologyInputsInfo):
    def __init__(self, node):
        super(TopologyAdditionalInfoInputsInfo, self).__init__(node)
        if 'ResourceName' in node.attrib:
            v = node.attrib['ResourceName']
        else:
            v = ''
        self.ResourceName = v
        """:type : str"""

        if 'LinkedToGlobal' in node.attrib:
            v = node.attrib['LinkedToGlobal']
        else:
            v = ''
        self.LinkedToGlobal = v
        """:type : str"""


class TopologyRequirementsInputsInfo(TopologyInputsInfo):
    def __init__(self, node):
        super(TopologyRequirementsInputsInfo, self).__init__(node)
        if 'ResourceName' in node.attrib:
            v = node.attrib['ResourceName']
        else:
            v = ''
        self.ResourceName = v
        """:type : str"""

        if 'InputType' in node.attrib:
            v = node.attrib['InputType']
        else:
            v = ''
        self.InputType = v
        """:type : str"""

        if 'LinkedToGlobal' in node.attrib:
            v = node.attrib['LinkedToGlobal']
        else:
            v = ''
        self.LinkedToGlobal = v
        """:type : str"""


class TopologyInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologyInfo, self).__init__(node)
        self.Resources = []
        """:type : list[TopologyResourceInfo]"""
        for ch in node:
            if ch.tag == 'Resources' or '}Resources#' in ch.tag+'#':
                for ch2 in ch:
                    self.Resources.append(TopologyResourceInfo(ch2))

        self.AbstractResources = []
        """:type : list[TopologyAbstractResourceInfo]"""
        for ch in node:
            if ch.tag == 'AbstractResources' or '}AbstractResources#' in ch.tag+'#':
                for ch2 in ch:
                    self.AbstractResources.append(TopologyAbstractResourceInfo(ch2))

        self.Routes = []
        """:type : list[RouteInfo]"""
        for ch in node:
            if ch.tag == 'Routes' or '}Routes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Routes.append(RouteInfo(ch2))

        self.Connectors = []
        """:type : list[Connector]"""
        for ch in node:
            if ch.tag == 'Connectors' or '}Connectors#' in ch.tag+'#':
                for ch2 in ch:
                    self.Connectors.append(Connector(ch2))

        self.Services = []
        """:type : list[ServiceInstance]"""
        for ch in node:
            if ch.tag == 'Services' or '}Services#' in ch.tag+'#':
                for ch2 in ch:
                    self.Services.append(ServiceInstance(ch2))

        v = ''
        for ch in node:
            if ch.tag == 'Instructions' or '}Instructions#' in ch.tag+'#':
                v = ch.text
        self.Instructions = v
        """:type : str"""

        self.GlobalInputs = []
        """:type : list[TopologyGlobalInputsInfo]"""
        for ch in node:
            if ch.tag == 'GlobalInputs' or '}GlobalInputs#' in ch.tag+'#':
                self.GlobalInputs.append(TopologyGlobalInputsInfo(ch))

        self.RequirementsInputs = []
        """:type : list[TopologyRequirementsInputsInfo]"""
        for ch in node:
            if ch.tag == 'RequirementsInputs' or '}RequirementsInputs#' in ch.tag+'#':
                self.RequirementsInputs.append(TopologyRequirementsInputsInfo(ch))

        self.AdditionalInfoInputs = []
        """:type : list[TopologyAdditionalInfoInputsInfo]"""
        for ch in node:
            if ch.tag == 'AdditionalInfoInputs' or '}AdditionalInfoInputs#' in ch.tag+'#':
                self.AdditionalInfoInputs.append(TopologyAdditionalInfoInputsInfo(ch))

        v = None
        for ch in node:
            if ch.tag == 'ParentTopology' or '}ParentTopology#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = TopologyShortInfo(ch)
        self.ParentTopology = v
        """:type : TopologyShortInfo"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Owner' in node.attrib:
            v = node.attrib['Owner']
        else:
            v = ''
        self.Owner = v
        """:type : str"""

        if 'Driver' in node.attrib:
            v = node.attrib['Driver']
        else:
            v = ''
        self.Driver = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""

        if 'State' in node.attrib:
            v = node.attrib['State']
        else:
            v = ''
        self.State = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""


class ActiveTopologyInfo(ResponseInfo):
    def __init__(self, node):
        super(ActiveTopologyInfo, self).__init__(node)
        self.Resources = []
        """:type : list[ActiveTopologyResourceInfo]"""
        for ch in node:
            if ch.tag == 'Resources' or '}Resources#' in ch.tag+'#':
                for ch2 in ch:
                    self.Resources.append(ActiveTopologyResourceInfo(ch2))

        self.Routes = []
        """:type : list[RouteInfo]"""
        for ch in node:
            if ch.tag == 'Routes' or '}Routes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Routes.append(RouteInfo(ch2))

        self.Connectors = []
        """:type : list[Connector]"""
        for ch in node:
            if ch.tag == 'Connectors' or '}Connectors#' in ch.tag+'#':
                for ch2 in ch:
                    self.Connectors.append(Connector(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'MachineName' in node.attrib:
            v = node.attrib['MachineName']
        else:
            v = ''
        self.MachineName = v
        """:type : str"""

        if 'Username' in node.attrib:
            v = node.attrib['Username']
        else:
            v = ''
        self.Username = v
        """:type : str"""

        if 'Topology' in node.attrib:
            v = node.attrib['Topology']
        else:
            v = ''
        self.Topology = v
        """:type : str"""


class TopologyListInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologyListInfo, self).__init__(node)
        self.Topologies = []
        """:type : list[str]"""
        for ch in node:
            if ch.tag == 'Topologies' or '}Topologies#' in ch.tag+'#':
                for ch2 in ch:
                    self.Topologies.append(ch2.text)


class AttributeValueInfo(ResponseInfo):
    def __init__(self, node):
        super(AttributeValueInfo, self).__init__(node)
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""


class ResourceShortInfo(ResponseInfo):
    def __init__(self, node):
        super(ResourceShortInfo, self).__init__(node)
        v = None
        for ch in node:
            if ch.tag == 'LockInfo' or '}LockInfo#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ResourceLockInfo(ch)
        self.LockInfo = v
        """:type : ResourceLockInfo"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'FolderFullPath' in node.attrib:
            v = node.attrib['FolderFullPath']
        else:
            v = ''
        self.FolderFullPath = v
        """:type : str"""

        if 'Address' in node.attrib:
            v = node.attrib['Address']
        else:
            v = ''
        self.Address = v
        """:type : str"""

        if 'FullAddress' in node.attrib:
            v = node.attrib['FullAddress']
        else:
            v = ''
        self.FullAddress = v
        """:type : str"""

        if 'RootAddress' in node.attrib:
            v = node.attrib['RootAddress']
        else:
            v = ''
        self.RootAddress = v
        """:type : str"""

        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""

        if 'Locked' in node.attrib:
            v = node.attrib['Locked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Locked = v
        """:type : boolean"""

        if 'Excluded' in node.attrib:
            v = node.attrib['Excluded']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Excluded = v
        """:type : boolean"""

        if 'Permission' in node.attrib:
            v = node.attrib['Permission']
        else:
            v = ''
        self.Permission = v
        """:type : str"""


class ResourceListInfo(ResponseInfo):
    def __init__(self, node):
        super(ResourceListInfo, self).__init__(node)
        self.Resources = []
        """:type : list[ResourceShortInfo]"""
        for ch in node:
            if ch.tag == 'Resources' or '}Resources#' in ch.tag+'#':
                for ch2 in ch:
                    self.Resources.append(ResourceShortInfo(ch2))


class ServiceInstance(ResponseInfo):
    def __init__(self, node):
        super(ServiceInstance, self).__init__(node)
        self.Attributes = []
        """:type : list[AttributeValueInfo]"""
        for ch in node:
            if ch.tag == 'Attributes' or '}Attributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Attributes.append(AttributeValueInfo(ch2))

        if 'ServiceName' in node.attrib:
            v = node.attrib['ServiceName']
        else:
            v = ''
        self.ServiceName = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""


class ServiceAttribute(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""

        if 'IsRequired' in node.attrib:
            v = node.attrib['IsRequired']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.IsRequired = v
        """:type : boolean"""

        if 'DefaultValue' in node.attrib:
            v = node.attrib['DefaultValue']
        else:
            v = ''
        self.DefaultValue = v
        """:type : str"""

        if 'PossibleValues' in node.attrib:
            v = node.attrib['PossibleValues']
        else:
            v = ''
        self.PossibleValues = v
        """:type : str"""


class ServiceInfo(ResponseInfo):
    def __init__(self, node):
        super(ServiceInfo, self).__init__(node)
        self.Attributes = []
        """:type : list[ServiceAttribute]"""
        for ch in node:
            if ch.tag == 'Attributes' or '}Attributes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Attributes.append(ServiceAttribute(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'CategoryFullPath' in node.attrib:
            v = node.attrib['CategoryFullPath']
        else:
            v = ''
        self.CategoryFullPath = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""


class ServicesListInfo(ResponseInfo):
    def __init__(self, node):
        super(ServicesListInfo, self).__init__(node)
        self.Services = []
        """:type : list[ServiceInfo]"""
        for ch in node:
            if ch.tag == 'Services' or '}Services#' in ch.tag+'#':
                for ch2 in ch:
                    self.Services.append(ServiceInfo(ch2))


class ContentShortInfo(ResponseInfo):
    def __init__(self, node):
        super(ContentShortInfo, self).__init__(node)
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""

        if 'Permission' in node.attrib:
            v = node.attrib['Permission']
        else:
            v = ''
        self.Permission = v
        """:type : str"""


class ContentListInfo(ResponseInfo):
    def __init__(self, node):
        super(ContentListInfo, self).__init__(node)
        self.ContentArray = []
        """:type : list[ContentShortInfo]"""
        for ch in node:
            if ch.tag == 'ContentArray' or '}ContentArray#' in ch.tag+'#':
                for ch2 in ch:
                    self.ContentArray.append(ContentShortInfo(ch2))


class ReservationListInfo(ResponseInfo):
    def __init__(self, node):
        super(ReservationListInfo, self).__init__(node)
        self.Reservations = []
        """:type : list[ReservationInfo]"""
        for ch in node:
            if ch.tag == 'Reservations' or '}Reservations#' in ch.tag+'#':
                for ch2 in ch:
                    self.Reservations.append(ReservationInfo(ch2))


class ReservationInfo(ResponseInfo):
    def __init__(self, node):
        super(ReservationInfo, self).__init__(node)
        self.LockedResources = []
        """:type : list[ResourceShortInfo]"""
        for ch in node:
            if ch.tag == 'LockedResources' or '}LockedResources#' in ch.tag+'#':
                for ch2 in ch:
                    self.LockedResources.append(ResourceShortInfo(ch2))

        if 'Id' in node.attrib:
            v = node.attrib['Id']
        else:
            v = ''
        self.Id = v
        """:type : str"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Owner' in node.attrib:
            v = node.attrib['Owner']
        else:
            v = ''
        self.Owner = v
        """:type : str"""

        if 'Created' in node.attrib:
            v = node.attrib['Created']
        else:
            v = ''
        self.Created = v
        """:type : str"""


class ResourceMappingsInfo(ResponseInfo):
    def __init__(self, node):
        super(ResourceMappingsInfo, self).__init__(node)
        self.Mapping = []
        """:type : list[Mapping]"""
        for ch in node:
            if ch.tag == 'Mapping' or '}Mapping#' in ch.tag+'#':
                self.Mapping.append(Mapping(ch))


class Mapping(object):
    def __init__(self, node):
        if 'Source' in node.attrib:
            v = node.attrib['Source']
        else:
            v = ''
        self.Source = v
        """:type : str"""

        if 'Target' in node.attrib:
            v = node.attrib['Target']
        else:
            v = ''
        self.Target = v
        """:type : str"""

        if 'RouteType' in node.attrib:
            v = node.attrib['RouteType']
        else:
            v = ''
        self.RouteType = v
        """:type : str"""


class CreateReservationResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(CreateReservationResponseInfo, self).__init__(node)
        v = None
        for ch in node:
            if ch.tag == 'Reservation' or '}Reservation#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ReservationShortInfo(ch)
        self.Reservation = v
        """:type : ReservationShortInfo"""


class GetReservationsInRangeResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(GetReservationsInRangeResponseInfo, self).__init__(node)
        self.Reservations = []
        """:type : list[ReservationShortInfo]"""
        for ch in node:
            if ch.tag == 'Reservations' or '}Reservations#' in ch.tag+'#':
                for ch2 in ch:
                    self.Reservations.append(ReservationShortInfo(ch2))


class ReservationShortInfo(object):
    def __init__(self, node):
        self.Topologies = []
        """:type : list[str]"""
        for ch in node:
            if ch.tag == 'Topologies' or '}Topologies#' in ch.tag+'#':
                for ch2 in ch:
                    self.Topologies.append(ch2.text)

        self.TopologiesInfo = []
        """:type : list[TopologyShortInfo]"""
        for ch in node:
            if ch.tag == 'TopologiesInfo' or '}TopologiesInfo#' in ch.tag+'#':
                for ch2 in ch:
                    self.TopologiesInfo.append(TopologyShortInfo(ch2))

        self.PermittedUsers = []
        """:type : list[str]"""
        for ch in node:
            if ch.tag == 'PermittedUsers' or '}PermittedUsers#' in ch.tag+'#':
                for ch2 in ch:
                    self.PermittedUsers.append(ch2.text)

        if 'Id' in node.attrib:
            v = node.attrib['Id']
        else:
            v = ''
        self.Id = v
        """:type : str"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'StartTime' in node.attrib:
            v = node.attrib['StartTime']
        else:
            v = ''
        self.StartTime = v
        """:type : str"""

        if 'EndTime' in node.attrib:
            v = node.attrib['EndTime']
        else:
            v = ''
        self.EndTime = v
        """:type : str"""

        if 'RecurrenceType' in node.attrib:
            v = node.attrib['RecurrenceType']
        else:
            v = ''
        self.RecurrenceType = v
        """:type : str"""

        if 'Owner' in node.attrib:
            v = node.attrib['Owner']
        else:
            v = ''
        self.Owner = v
        """:type : str"""

        if 'Booked' in node.attrib:
            v = node.attrib['Booked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Booked = v
        """:type : boolean"""

        if 'Status' in node.attrib:
            v = node.attrib['Status']
        else:
            v = ''
        self.Status = v
        """:type : str"""

        if 'ProvisioningStatus' in node.attrib:
            v = node.attrib['ProvisioningStatus']
        else:
            v = ''
        self.ProvisioningStatus = v
        """:type : str"""

        if 'ActualEndTime' in node.attrib:
            v = node.attrib['ActualEndTime']
        else:
            v = ''
        self.ActualEndTime = v
        """:type : str"""

        if 'CreateDate' in node.attrib:
            v = node.attrib['CreateDate']
        else:
            v = ''
        self.CreateDate = v
        """:type : str"""

        if 'ModificationDate' in node.attrib:
            v = node.attrib['ModificationDate']
        else:
            v = ''
        self.ModificationDate = v
        """:type : str"""

        if 'DomainName' in node.attrib:
            v = node.attrib['DomainName']
        else:
            v = ''
        self.DomainName = v
        """:type : str"""

        if 'ReservationLiveStatusName' in node.attrib:
            v = node.attrib['ReservationLiveStatusName']
        else:
            v = ''
        self.ReservationLiveStatusName = v
        """:type : str"""

        if 'ReservationLiveStatusDescription' in node.attrib:
            v = node.attrib['ReservationLiveStatusDescription']
        else:
            v = ''
        self.ReservationLiveStatusDescription = v
        """:type : str"""


class ReservationDiagramLayoutResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(ReservationDiagramLayoutResponseInfo, self).__init__(node)
        self.ResourceDiagramLayouts = []
        """:type : list[ResourceDiagramLayoutInfo]"""
        for ch in node:
            if ch.tag == 'ResourceDiagramLayouts' or '}ResourceDiagramLayouts#' in ch.tag+'#':
                for ch2 in ch:
                    self.ResourceDiagramLayouts.append(ResourceDiagramLayoutInfo(ch2))


class ResourceDiagramLayoutInfo(object):
    def __init__(self, node):
        if 'ResourceName' in node.attrib:
            v = node.attrib['ResourceName']
        else:
            v = ''
        self.ResourceName = v
        """:type : str"""

        if 'X' in node.attrib:
            v = node.attrib['X']
        else:
            v = ''
        if v == '':
            v = 0.0
        else:
            v = float(v)
        self.X = v
        """:type : double"""

        if 'Y' in node.attrib:
            v = node.attrib['Y']
        else:
            v = ''
        if v == '':
            v = 0.0
        else:
            v = float(v)
        self.Y = v
        """:type : double"""


class GetReservationDescriptionResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(GetReservationDescriptionResponseInfo, self).__init__(node)
        v = None
        for ch in node:
            if ch.tag == 'ReservationDescription' or '}ReservationDescription#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ReservationDescriptionInfo(ch)
        self.ReservationDescription = v
        """:type : ReservationDescriptionInfo"""


class ReservationDescriptionInfo(ReservationShortInfo):
    def __init__(self, node):
        super(ReservationDescriptionInfo, self).__init__(node)
        self.Resources = []
        """:type : list[ReservedResourceInfo]"""
        for ch in node:
            if ch.tag == 'Resources' or '}Resources#' in ch.tag+'#':
                for ch2 in ch:
                    self.Resources.append(ReservedResourceInfo(ch2))

        self.TopologiesReservedResources = []
        """:type : list[TopologyReservedResourceInfo]"""
        for ch in node:
            if ch.tag == 'TopologiesReservedResources' or '}TopologiesReservedResources#' in ch.tag+'#':
                for ch2 in ch:
                    self.TopologiesReservedResources.append(TopologyReservedResourceInfo(ch2))

        self.Conflicts = []
        """:type : list[ResourceConflictInfo]"""
        for ch in node:
            if ch.tag == 'Conflicts' or '}Conflicts#' in ch.tag+'#':
                for ch2 in ch:
                    self.Conflicts.append(ResourceConflictInfo(ch2))

        self.TopologiesRouteInfo = []
        """:type : list[TopologyRoutesInfo]"""
        for ch in node:
            if ch.tag == 'TopologiesRouteInfo' or '}TopologiesRouteInfo#' in ch.tag+'#':
                for ch2 in ch:
                    self.TopologiesRouteInfo.append(TopologyRoutesInfo(ch2))

        self.TopologiesResourcesAttributeInfo = []
        """:type : list[TopologiesResourcesAttributesInfo]"""
        for ch in node:
            if ch.tag == 'TopologiesResourcesAttributeInfo' or '}TopologiesResourcesAttributeInfo#' in ch.tag+'#':
                for ch2 in ch:
                    self.TopologiesResourcesAttributeInfo.append(TopologiesResourcesAttributesInfo(ch2))

        self.TopologiesInstructionsInfo = []
        """:type : list[TopologyInstructionsInfo]"""
        for ch in node:
            if ch.tag == 'TopologiesInstructionsInfo' or '}TopologiesInstructionsInfo#' in ch.tag+'#':
                for ch2 in ch:
                    self.TopologiesInstructionsInfo.append(TopologyInstructionsInfo(ch2))

        self.ActiveRoutesInfo = []
        """:type : list[RouteInfo]"""
        for ch in node:
            if ch.tag == 'ActiveRoutesInfo' or '}ActiveRoutesInfo#' in ch.tag+'#':
                for ch2 in ch:
                    self.ActiveRoutesInfo.append(RouteInfo(ch2))

        self.RequestedRoutesInfo = []
        """:type : list[RouteInfo]"""
        for ch in node:
            if ch.tag == 'RequestedRoutesInfo' or '}RequestedRoutesInfo#' in ch.tag+'#':
                for ch2 in ch:
                    self.RequestedRoutesInfo.append(RouteInfo(ch2))

        self.Connectors = []
        """:type : list[Connector]"""
        for ch in node:
            if ch.tag == 'Connectors' or '}Connectors#' in ch.tag+'#':
                for ch2 in ch:
                    self.Connectors.append(Connector(ch2))

        v = None
        for ch in node:
            if ch.tag == 'ReservationLiveStatus' or '}ReservationLiveStatus#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ReservationLiveStatus(ch)
        self.ReservationLiveStatus = v
        """:type : ReservationLiveStatus"""

        self.Services = []
        """:type : list[ServiceInstance]"""
        for ch in node:
            if ch.tag == 'Services' or '}Services#' in ch.tag+'#':
                for ch2 in ch:
                    self.Services.append(ServiceInstance(ch2))


class GetReservationInputsResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(GetReservationInputsResponseInfo, self).__init__(node)
        self.GlobalInputs = []
        """:type : list[ReservedTopologyGlobalInputsInfo]"""
        for ch in node:
            if ch.tag == 'GlobalInputs' or '}GlobalInputs#' in ch.tag+'#':
                self.GlobalInputs.append(ReservedTopologyGlobalInputsInfo(ch))

        self.RequiredInputs = []
        """:type : list[ReservedTopologyRequiredInputsInfo]"""
        for ch in node:
            if ch.tag == 'RequiredInputs' or '}RequiredInputs#' in ch.tag+'#':
                self.RequiredInputs.append(ReservedTopologyRequiredInputsInfo(ch))

        self.AdditionalInfoInputs = []
        """:type : list[ReservedTopologyAdditionalInfoInputsInfo]"""
        for ch in node:
            if ch.tag == 'AdditionalInfoInputs' or '}AdditionalInfoInputs#' in ch.tag+'#':
                self.AdditionalInfoInputs.append(ReservedTopologyAdditionalInfoInputsInfo(ch))


class ReservedTopologyInputsInfo(object):
    def __init__(self, node):
        if 'ParamName' in node.attrib:
            v = node.attrib['ParamName']
        else:
            v = ''
        self.ParamName = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""


class ReservedTopologyGlobalInputsInfo(ReservedTopologyInputsInfo):
    def __init__(self, node):
        super(ReservedTopologyGlobalInputsInfo, self).__init__(node)
        self.PossibleValues = []
        """:type : list[str]"""
        for ch in node:
            self.PossibleValues.append(ch.text)


class ReservedTopologyRequiredInputsInfo(ReservedTopologyInputsInfo):
    def __init__(self, node):
        super(ReservedTopologyRequiredInputsInfo, self).__init__(node)
        if 'ResourceName' in node.attrib:
            v = node.attrib['ResourceName']
        else:
            v = ''
        self.ResourceName = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""

        if 'LinkedToGlobal' in node.attrib:
            v = node.attrib['LinkedToGlobal']
        else:
            v = ''
        self.LinkedToGlobal = v
        """:type : str"""


class ReservedTopologyAdditionalInfoInputsInfo(ReservedTopologyInputsInfo):
    def __init__(self, node):
        super(ReservedTopologyAdditionalInfoInputsInfo, self).__init__(node)
        self.PossibleValues = []
        """:type : list[str]"""
        for ch in node:
            self.PossibleValues.append(ch.text)

        if 'ResourceName' in node.attrib:
            v = node.attrib['ResourceName']
        else:
            v = ''
        self.ResourceName = v
        """:type : str"""

        if 'LinkedToGlobal' in node.attrib:
            v = node.attrib['LinkedToGlobal']
        else:
            v = ''
        self.LinkedToGlobal = v
        """:type : str"""


class TopologiesResourcesAttributesInfo(object):
    def __init__(self, node):
        self.AttributeValue = []
        """:type : list[str]"""
        for ch in node:
            self.AttributeValue.append(ch.text)

        if 'TopologyName' in node.attrib:
            v = node.attrib['TopologyName']
        else:
            v = ''
        self.TopologyName = v
        """:type : str"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""

        if 'AttributeName' in node.attrib:
            v = node.attrib['AttributeName']
        else:
            v = ''
        self.AttributeName = v
        """:type : str"""

        if 'Usage' in node.attrib:
            v = node.attrib['Usage']
        else:
            v = ''
        self.Usage = v
        """:type : str"""


class ReservedResourceInfo(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'FolderFullPath' in node.attrib:
            v = node.attrib['FolderFullPath']
        else:
            v = ''
        self.FolderFullPath = v
        """:type : str"""

        if 'FullAddress' in node.attrib:
            v = node.attrib['FullAddress']
        else:
            v = ''
        self.FullAddress = v
        """:type : str"""

        if 'Shared' in node.attrib:
            v = node.attrib['Shared']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Shared = v
        """:type : boolean"""

        if 'Availability' in node.attrib:
            v = node.attrib['Availability']
        else:
            v = ''
        self.Availability = v
        """:type : str"""

        if 'Locked' in node.attrib:
            v = node.attrib['Locked']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Locked = v
        """:type : boolean"""

        if 'Released' in node.attrib:
            v = node.attrib['Released']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Released = v
        """:type : boolean"""

        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""


class TopologyRoutesInfo(object):
    def __init__(self, node):
        self.Routes = []
        """:type : list[RouteInfo]"""
        for ch in node:
            if ch.tag == 'Routes' or '}Routes#' in ch.tag+'#':
                for ch2 in ch:
                    self.Routes.append(RouteInfo(ch2))

        if 'TopologyName' in node.attrib:
            v = node.attrib['TopologyName']
        else:
            v = ''
        self.TopologyName = v
        """:type : str"""


class TopologyInstructionsInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologyInstructionsInfo, self).__init__(node)
        v = ''
        for ch in node:
            if ch.tag == 'Instructions' or '}Instructions#' in ch.tag+'#':
                v = ch.text
        self.Instructions = v
        """:type : str"""

        if 'TopologyName' in node.attrib:
            v = node.attrib['TopologyName']
        else:
            v = ''
        self.TopologyName = v
        """:type : str"""


class TopologyReservedResourceInfo(ReservedResourceInfo):
    def __init__(self, node):
        super(TopologyReservedResourceInfo, self).__init__(node)
        if 'TopologyName' in node.attrib:
            v = node.attrib['TopologyName']
        else:
            v = ''
        self.TopologyName = v
        """:type : str"""

        if 'Alias' in node.attrib:
            v = node.attrib['Alias']
        else:
            v = ''
        self.Alias = v
        """:type : str"""


class GetActiveReservationsResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(GetActiveReservationsResponseInfo, self).__init__(node)
        self.Reservations = []
        """:type : list[ReservationShortInfo]"""
        for ch in node:
            if ch.tag == 'Reservations' or '}Reservations#' in ch.tag+'#':
                for ch2 in ch:
                    self.Reservations.append(ReservationShortInfo(ch2))


class ResourceConflictInfo(object):
    def __init__(self, node):
        if 'ResourceName' in node.attrib:
            v = node.attrib['ResourceName']
        else:
            v = ''
        self.ResourceName = v
        """:type : str"""

        if 'ConflictType' in node.attrib:
            v = node.attrib['ConflictType']
        else:
            v = ''
        self.ConflictType = v
        """:type : str"""

        if 'Topology' in node.attrib:
            v = node.attrib['Topology']
        else:
            v = ''
        self.Topology = v
        """:type : str"""

        if 'ConflictWith' in node.attrib:
            v = node.attrib['ConflictWith']
        else:
            v = ''
        self.ConflictWith = v
        """:type : str"""

        if 'ConflictWithUser' in node.attrib:
            v = node.attrib['ConflictWithUser']
        else:
            v = ''
        self.ConflictWithUser = v
        """:type : str"""

        if 'ConflictStarted' in node.attrib:
            v = node.attrib['ConflictStarted']
        else:
            v = ''
        self.ConflictStarted = v
        """:type : str"""

        if 'ConflictPlannedEndTime' in node.attrib:
            v = node.attrib['ConflictPlannedEndTime']
        else:
            v = ''
        self.ConflictPlannedEndTime = v
        """:type : str"""


class ReserveResourcesResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(ReserveResourcesResponseInfo, self).__init__(node)
        self.Conflicts = []
        """:type : list[ResourceConflictInfo]"""
        for ch in node:
            if ch.tag == 'Conflicts' or '}Conflicts#' in ch.tag+'#':
                for ch2 in ch:
                    self.Conflicts.append(ResourceConflictInfo(ch2))


class ReserveTopologyResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(ReserveTopologyResponseInfo, self).__init__(node)
        self.Conflicts = []
        """:type : list[ResourceConflictInfo]"""
        for ch in node:
            if ch.tag == 'Conflicts' or '}Conflicts#' in ch.tag+'#':
                for ch2 in ch:
                    self.Conflicts.append(ResourceConflictInfo(ch2))


class CommandExecutionIdResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(CommandExecutionIdResponseInfo, self).__init__(node)
        if 'Id' in node.attrib:
            v = node.attrib['Id']
        else:
            v = ''
        self.Id = v
        """:type : str"""


class CommandExecutionResultInfo(ResponseInfo):
    def __init__(self, node):
        super(CommandExecutionResultInfo, self).__init__(node)
        pass

class CommandExecutionResultListInfo(ResponseInfo):
    def __init__(self, node):
        super(CommandExecutionResultListInfo, self).__init__(node)
        self.Results = []
        """:type : list[CommandExecutionResultInfo]"""
        for ch in node:
            if ch.tag == 'Results' or '}Results#' in ch.tag+'#':
                for ch2 in ch:
                    self.Results.append(CommandExecutionResultInfo(ch2))


class CommandExecutionCompletedResultInfo(CommandExecutionResultInfo):
    def __init__(self, node):
        super(CommandExecutionCompletedResultInfo, self).__init__(node)
        if 'Output' in node.attrib:
            v = node.attrib['Output']
        else:
            v = ''
        self.Output = v
        """:type : str"""


class CommandExecutionCancelledResultInfo(CommandExecutionResultInfo):
    def __init__(self, node):
        super(CommandExecutionCancelledResultInfo, self).__init__(node)
        if 'Message' in node.attrib:
            v = node.attrib['Message']
        else:
            v = ''
        self.Message = v
        """:type : str"""


class CommandExecutionFailedResultInfo(CommandExecutionResultInfo):
    def __init__(self, node):
        super(CommandExecutionFailedResultInfo, self).__init__(node)
        self.ErrorParameters = []
        """:type : list[ErrorParameter]"""
        for ch in node:
            if ch.tag == 'ErrorParameters' or '}ErrorParameters#' in ch.tag+'#':
                for ch2 in ch:
                    self.ErrorParameters.append(ErrorParameter(ch2))

        if 'ErrorName' in node.attrib:
            v = node.attrib['ErrorName']
        else:
            v = ''
        self.ErrorName = v
        """:type : str"""

        if 'ErrorDescription' in node.attrib:
            v = node.attrib['ErrorDescription']
        else:
            v = ''
        self.ErrorDescription = v
        """:type : str"""


class ErrorParameter(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Value' in node.attrib:
            v = node.attrib['Value']
        else:
            v = ''
        self.Value = v
        """:type : str"""


class LogonDomainInfo(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'DomainId' in node.attrib:
            v = node.attrib['DomainId']
        else:
            v = ''
        self.DomainId = v
        """:type : str"""


class LogonResponseInfo(ResponseInfo):
    def __init__(self, node):
        super(LogonResponseInfo, self).__init__(node)
        v = None
        for ch in node:
            if ch.tag == 'Domain' or '}Domain#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = LogonDomainInfo(ch)
        self.Domain = v
        """:type : LogonDomainInfo"""


class CommandParameter(object):
    def __init__(self, node):
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'Type' in node.attrib:
            v = node.attrib['Type']
        else:
            v = ''
        self.Type = v
        """:type : str"""

        if 'Mandatory' in node.attrib:
            v = node.attrib['Mandatory']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Mandatory = v
        """:type : boolean"""

        if 'DefaultValue' in node.attrib:
            v = node.attrib['DefaultValue']
        else:
            v = ''
        self.DefaultValue = v
        """:type : str"""

        if 'EnumValues' in node.attrib:
            v = node.attrib['EnumValues']
        else:
            v = ''
        self.EnumValues = v
        """:type : str"""


class ResourceCommandInfo(object):
    def __init__(self, node):
        self.Parameters = []
        """:type : list[CommandParameter]"""
        for ch in node:
            if ch.tag == 'Parameters' or '}Parameters#' in ch.tag+'#':
                for ch2 in ch:
                    self.Parameters.append(CommandParameter(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Tag' in node.attrib:
            v = node.attrib['Tag']
        else:
            v = ''
        self.Tag = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'DisplayName' in node.attrib:
            v = node.attrib['DisplayName']
        else:
            v = ''
        self.DisplayName = v
        """:type : str"""


class ResourceCommandListInfo(ResponseInfo):
    def __init__(self, node):
        super(ResourceCommandListInfo, self).__init__(node)
        self.Commands = []
        """:type : list[ResourceCommandInfo]"""
        for ch in node:
            if ch.tag == 'Commands' or '}Commands#' in ch.tag+'#':
                for ch2 in ch:
                    self.Commands.append(ResourceCommandInfo(ch2))


class TopologyCommandInfo(object):
    def __init__(self, node):
        self.Parameters = []
        """:type : list[CommandParameter]"""
        for ch in node:
            if ch.tag == 'Parameters' or '}Parameters#' in ch.tag+'#':
                for ch2 in ch:
                    self.Parameters.append(CommandParameter(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""


class TopologyCommandListInfo(ResponseInfo):
    def __init__(self, node):
        super(TopologyCommandListInfo, self).__init__(node)
        self.Commands = []
        """:type : list[TopologyCommandInfo]"""
        for ch in node:
            if ch.tag == 'Commands' or '}Commands#' in ch.tag+'#':
                for ch2 in ch:
                    self.Commands.append(TopologyCommandInfo(ch2))


class FindResourceReservationInfo(object):
    def __init__(self, node):
        if 'ReservationId' in node.attrib:
            v = node.attrib['ReservationId']
        else:
            v = ''
        self.ReservationId = v
        """:type : str"""

        if 'ResourceFullName' in node.attrib:
            v = node.attrib['ResourceFullName']
        else:
            v = ''
        self.ResourceFullName = v
        """:type : str"""

        if 'ReservationName' in node.attrib:
            v = node.attrib['ReservationName']
        else:
            v = ''
        self.ReservationName = v
        """:type : str"""

        if 'Owner' in node.attrib:
            v = node.attrib['Owner']
        else:
            v = ''
        self.Owner = v
        """:type : str"""

        if 'StartTime' in node.attrib:
            v = node.attrib['StartTime']
        else:
            v = ''
        self.StartTime = v
        """:type : str"""

        if 'EndTime' in node.attrib:
            v = node.attrib['EndTime']
        else:
            v = ''
        self.EndTime = v
        """:type : str"""

        if 'Shared' in node.attrib:
            v = node.attrib['Shared']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Shared = v
        """:type : boolean"""


class ResourcesUsageSummaryInfo(object):
    def __init__(self, node):
        if 'ResourceFullName' in node.attrib:
            v = node.attrib['ResourceFullName']
        else:
            v = ''
        self.ResourceFullName = v
        """:type : str"""

        if 'NumOfNotInReservation' in node.attrib:
            v = node.attrib['NumOfNotInReservation']
        else:
            v = ''
        if v == '':
            v = 0
        else:
            v = int(v)
        self.NumOfNotInReservation = v
        """:type : int"""

        if 'NumOfReserved' in node.attrib:
            v = node.attrib['NumOfReserved']
        else:
            v = ''
        if v == '':
            v = 0
        else:
            v = int(v)
        self.NumOfReserved = v
        """:type : int"""

        if 'NumOfShared' in node.attrib:
            v = node.attrib['NumOfShared']
        else:
            v = ''
        if v == '':
            v = 0
        else:
            v = int(v)
        self.NumOfShared = v
        """:type : int"""


class FindResourceInfo(object):
    def __init__(self, node):
        self.Reservations = []
        """:type : list[FindResourceReservationInfo]"""
        for ch in node:
            if ch.tag == 'Reservations' or '}Reservations#' in ch.tag+'#':
                for ch2 in ch:
                    self.Reservations.append(FindResourceReservationInfo(ch2))

        v = None
        for ch in node:
            if ch.tag == 'UsageSummary' or '}UsageSummary#' in ch.tag+'#':
                if '{http://www.w3.org/2001/XMLSchema-instance}type' in ch.attrib:
                    v = (globals()[ch.attrib['{http://www.w3.org/2001/XMLSchema-instance}type']])(ch)
                else:
                    v = ResourcesUsageSummaryInfo(ch)
        self.UsageSummary = v
        """:type : ResourcesUsageSummaryInfo"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'Address' in node.attrib:
            v = node.attrib['Address']
        else:
            v = ''
        self.Address = v
        """:type : str"""

        if 'FullName' in node.attrib:
            v = node.attrib['FullName']
        else:
            v = ''
        self.FullName = v
        """:type : str"""

        if 'FullPath' in node.attrib:
            v = node.attrib['FullPath']
        else:
            v = ''
        self.FullPath = v
        """:type : str"""

        if 'FullAddress' in node.attrib:
            v = node.attrib['FullAddress']
        else:
            v = ''
        self.FullAddress = v
        """:type : str"""

        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""

        if 'ReservedStatus' in node.attrib:
            v = node.attrib['ReservedStatus']
        else:
            v = ''
        self.ReservedStatus = v
        """:type : str"""

        if 'Excluded' in node.attrib:
            v = node.attrib['Excluded']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Excluded = v
        """:type : boolean"""

        if 'Permission' in node.attrib:
            v = node.attrib['Permission']
        else:
            v = ''
        self.Permission = v
        """:type : str"""

        if 'ConnectedTo' in node.attrib:
            v = node.attrib['ConnectedTo']
        else:
            v = ''
        self.ConnectedTo = v
        """:type : str"""


class FindResourceListInfo(ResponseInfo):
    def __init__(self, node):
        super(FindResourceListInfo, self).__init__(node)
        self.Resources = []
        """:type : list[FindResourceInfo]"""
        for ch in node:
            if ch.tag == 'Resources' or '}Resources#' in ch.tag+'#':
                for ch2 in ch:
                    self.Resources.append(FindResourceInfo(ch2))


class GetReservationRemainingTimeInfo(ResponseInfo):
    def __init__(self, node):
        super(GetReservationRemainingTimeInfo, self).__init__(node)
        if 'RemainingTimeInMinutes' in node.attrib:
            v = node.attrib['RemainingTimeInMinutes']
        else:
            v = ''
        if v == '':
            v = 0.0
        else:
            v = float(v)
        self.RemainingTimeInMinutes = v
        """:type : double"""


class UsersInfo(ResponseInfo):
    def __init__(self, node):
        super(UsersInfo, self).__init__(node)
        self.Users = []
        """:type : list[UserInfo]"""
        for ch in node:
            if ch.tag == 'Users' or '}Users#' in ch.tag+'#':
                for ch2 in ch:
                    self.Users.append(UserInfo(ch2))


class UserInfo(ResponseInfo):
    def __init__(self, node):
        super(UserInfo, self).__init__(node)
        self.Groups = []
        """:type : list[GroupInfo]"""
        for ch in node:
            if ch.tag == 'Groups' or '}Groups#' in ch.tag+'#':
                for ch2 in ch:
                    self.Groups.append(GroupInfo(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'IsAdmin' in node.attrib:
            v = node.attrib['IsAdmin']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.IsAdmin = v
        """:type : boolean"""

        if 'IsActive' in node.attrib:
            v = node.attrib['IsActive']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.IsActive = v
        """:type : boolean"""

        if 'DomainName' in node.attrib:
            v = node.attrib['DomainName']
        else:
            v = ''
        self.DomainName = v
        """:type : str"""

        if 'IsDomainAdmin' in node.attrib:
            v = node.attrib['IsDomainAdmin']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.IsDomainAdmin = v
        """:type : boolean"""

        if 'Email' in node.attrib:
            v = node.attrib['Email']
        else:
            v = ''
        self.Email = v
        """:type : str"""


class GroupsInfo(ResponseInfo):
    def __init__(self, node):
        super(GroupsInfo, self).__init__(node)
        self.Groups = []
        """:type : list[GroupInfo]"""
        for ch in node:
            if ch.tag == 'Groups' or '}Groups#' in ch.tag+'#':
                for ch2 in ch:
                    self.Groups.append(GroupInfo(ch2))


class TestShellDomainInfo(ResponseInfo):
    def __init__(self, node):
        super(TestShellDomainInfo, self).__init__(node)
        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'Id' in node.attrib:
            v = node.attrib['Id']
        else:
            v = ''
        self.Id = v
        """:type : str"""


class GroupInfo(ResponseInfo):
    def __init__(self, node):
        super(GroupInfo, self).__init__(node)
        self.TestShellDomains = []
        """:type : list[TestShellDomainInfo]"""
        for ch in node:
            if ch.tag == 'TestShellDomains' or '}TestShellDomains#' in ch.tag+'#':
                for ch2 in ch:
                    self.TestShellDomains.append(TestShellDomainInfo(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'GroupRole' in node.attrib:
            v = node.attrib['GroupRole']
        else:
            v = ''
        self.GroupRole = v
        """:type : str"""


class UtilizationReport(ResponseInfo):
    def __init__(self, node):
        super(UtilizationReport, self).__init__(node)
        self.UtilizationReportRows = []
        """:type : list[UtilizationReportRow]"""
        for ch in node:
            if ch.tag == 'UtilizationReportRows' or '}UtilizationReportRows#' in ch.tag+'#':
                for ch2 in ch:
                    self.UtilizationReportRows.append(UtilizationReportRow(ch2))


class UtilizationReportRow(ResponseInfo):
    def __init__(self, node):
        super(UtilizationReportRow, self).__init__(node)
        self.Children = []
        """:type : list[UtilizationReportRow]"""
        for ch in node:
            if ch.tag == 'Children' or '}Children#' in ch.tag+'#':
                for ch2 in ch:
                    self.Children.append(UtilizationReportRow(ch2))

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Family' in node.attrib:
            v = node.attrib['Family']
        else:
            v = ''
        self.Family = v
        """:type : str"""

        if 'Model' in node.attrib:
            v = node.attrib['Model']
        else:
            v = ''
        self.Model = v
        """:type : str"""

        if 'Utilization' in node.attrib:
            v = node.attrib['Utilization']
        else:
            v = ''
        if v == '':
            v = 0.0
        else:
            v = float(v)
        self.Utilization = v
        """:type : double"""

        if 'ParentId' in node.attrib:
            v = node.attrib['ParentId']
        else:
            v = ''
        self.ParentId = v
        """:type : str"""


class ServerTimeInfo(ResponseInfo):
    def __init__(self, node):
        super(ServerTimeInfo, self).__init__(node)
        if 'ServerDateTime' in node.attrib:
            v = node.attrib['ServerDateTime']
        else:
            v = ''
        self.ServerDateTime = v
        """:type : str"""


class ExportConfigurationInfo(ResponseInfo):
    def __init__(self, node):
        super(ExportConfigurationInfo, self).__init__(node)
        v = ''
        for ch in node:
            if ch.tag == 'Configuration' or '}Configuration#' in ch.tag+'#':
                v = ch.text
        self.Configuration = v
        """:type : str"""


class GetServerTimeZonesResponse(ResponseInfo):
    def __init__(self, node):
        super(GetServerTimeZonesResponse, self).__init__(node)
        self.TimeZones = []
        """:type : list[TimeZoneDefinition]"""
        for ch in node:
            if ch.tag == 'TimeZones' or '}TimeZones#' in ch.tag+'#':
                for ch2 in ch:
                    self.TimeZones.append(TimeZoneDefinition(ch2))


class TimeZoneDefinition(object):
    def __init__(self, node):
        if 'Id' in node.attrib:
            v = node.attrib['Id']
        else:
            v = ''
        self.Id = v
        """:type : str"""

        if 'DisplayName' in node.attrib:
            v = node.attrib['DisplayName']
        else:
            v = ''
        self.DisplayName = v
        """:type : str"""


class AbstractTemplateShortInfoList(ResponseInfo):
    def __init__(self, node):
        super(AbstractTemplateShortInfoList, self).__init__(node)
        self.AbstractTemplates = []
        """:type : list[AbstractTemplateShortInfo]"""
        for ch in node:
            if ch.tag == 'AbstractTemplates' or '}AbstractTemplates#' in ch.tag+'#':
                for ch2 in ch:
                    self.AbstractTemplates.append(AbstractTemplateShortInfo(ch2))


class AbstractTemplateShortInfo(ResponseInfo):
    def __init__(self, node):
        super(AbstractTemplateShortInfo, self).__init__(node)
        if 'ResourceFamilyName' in node.attrib:
            v = node.attrib['ResourceFamilyName']
        else:
            v = ''
        self.ResourceFamilyName = v
        """:type : str"""

        if 'ResourceModelName' in node.attrib:
            v = node.attrib['ResourceModelName']
        else:
            v = ''
        self.ResourceModelName = v
        """:type : str"""

        if 'Name' in node.attrib:
            v = node.attrib['Name']
        else:
            v = ''
        self.Name = v
        """:type : str"""

        if 'Description' in node.attrib:
            v = node.attrib['Description']
        else:
            v = ''
        self.Description = v
        """:type : str"""

        if 'Owner' in node.attrib:
            v = node.attrib['Owner']
        else:
            v = ''
        self.Owner = v
        """:type : str"""

        if 'DomainName' in node.attrib:
            v = node.attrib['DomainName']
        else:
            v = ''
        self.DomainName = v
        """:type : str"""

        if 'CreateDate' in node.attrib:
            v = node.attrib['CreateDate']
        else:
            v = ''
        self.CreateDate = v
        """:type : str"""

        if 'Valid' in node.attrib:
            v = node.attrib['Valid']
        else:
            v = ''
        v = (v in ['true', 'True', 'TRUE', 'yes', 'Yes', 'YES', 'on', 'On', 'ON'])
        self.Valid = v
        """:type : boolean"""


class AttributeNameValue:
    def __init__(self, Name, Value    ):
        """
            :param str Name:  constructor parameter
            :param str Value:  constructor parameter
        """
        self.Name=Name
        self.Value=Value
class UpdateTopologyGlobalInputsRequest:
    def __init__(self, ParamName, Value    ):
        """
            :param str ParamName:  constructor parameter
            :param str Value:  constructor parameter
        """
        self.ParamName=ParamName
        self.Value=Value
class UpdateTopologyRequirementsInputsRequest:
    def __init__(self, ResourceName, ParamName, Value, Type    ):
        """
            :param str ResourceName:  constructor parameter
            :param str ParamName:  constructor parameter
            :param str Value:  constructor parameter
            :param str Type:  constructor parameter
        """
        self.ResourceName=ResourceName
        self.ParamName=ParamName
        self.Value=Value
        self.Type=Type
class UpdateTopologyAdditionalInfoInputsRequest:
    def __init__(self, ResourceName, ParamName, Value    ):
        """
            :param str ResourceName:  constructor parameter
            :param str ParamName:  constructor parameter
            :param str Value:  constructor parameter
        """
        self.ResourceName=ResourceName
        self.ParamName=ParamName
        self.Value=Value
class ResourceInfoDto:
    def __init__(self, Family, Model, FullName, Address, FolderFullpath, ParentFullName, Description    ):
        """
            :param str Family:  constructor parameter
            :param str Model:  constructor parameter
            :param str FullName:  constructor parameter
            :param str Address:  constructor parameter
            :param str FolderFullpath:  constructor parameter
            :param str ParentFullName:  constructor parameter
            :param str Description:  constructor parameter
        """
        self.Family=Family
        self.Model=Model
        self.FullName=FullName
        self.Address=Address
        self.FolderFullpath=FolderFullpath
        self.ParentFullName=ParentFullName
        self.Description=Description
class InputNameValue:
    def __init__(self, Name, Value    ):
        """
            :param str Name:  constructor parameter
            :param str Value:  constructor parameter
        """
        self.Name=Name
        self.Value=Value
class ResourceAttributesUpdateRequest:
    def __init__(self, ResourceFullName, AttributeNamesValues    ):
        """
            :param str ResourceFullName:  constructor parameter
            :param list[AttributeNameValue] AttributeNamesValues:  constructor parameter
        """
        self.ResourceFullName=ResourceFullName
        self.AttributeNamesValues=AttributeNamesValues
class SetConnectorRequest:
    def __init__(self, SourceResourceFullName, TargetResourceFullName, Direction, Alias    ):
        """
            :param str SourceResourceFullName:  constructor parameter
            :param str TargetResourceFullName:  constructor parameter
            :param str Direction:  constructor parameter
            :param str Alias:  constructor parameter
        """
        self.SourceResourceFullName=SourceResourceFullName
        self.TargetResourceFullName=TargetResourceFullName
        self.Direction=Direction
        self.Alias=Alias
class PhysicalConnectionUpdateRequest:
    def __init__(self, ResourceAFullName, ResourceBFullName, ConnectionWeight    ):
        """
            :param str ResourceAFullName:  constructor parameter
            :param str ResourceBFullName:  constructor parameter
            :param str ConnectionWeight:  constructor parameter
        """
        self.ResourceAFullName=ResourceAFullName
        self.ResourceBFullName=ResourceBFullName
        self.ConnectionWeight=ConnectionWeight
class UpdateRouteAliasRequest:
    def __init__(self, SourceResourceName, TargetResourceName, Alias    ):
        """
            :param str SourceResourceName:  constructor parameter
            :param str TargetResourceName:  constructor parameter
            :param str Alias:  constructor parameter
        """
        self.SourceResourceName=SourceResourceName
        self.TargetResourceName=TargetResourceName
        self.Alias=Alias
class UserUpdateRequest:
    def __init__(self, Username, MaxConcurrentReservations, MaxReservationDuration    ):
        """
            :param str Username:  constructor parameter
            :param str MaxConcurrentReservations:  constructor parameter
            :param str MaxReservationDuration:  constructor parameter
        """
        self.Username=Username
        self.MaxConcurrentReservations=MaxConcurrentReservations
        self.MaxReservationDuration=MaxReservationDuration
import sys
import xml.etree.ElementTree as ET

#if (sys.version_info > (3, 0)):
#    from typing import Dict, List
#    from urllib import request as URLLIB23
#else:
#    import urllib2 as URLLIB23

import urllib2 as URLLIB23
import socket

def unicode(s, charset):
    return s
def nonnull(s):
    if s is None:
        return ''
    else:
        s = str(s)
        if s=='True':
            return 'true'
        else:
            if s=='False':
                return 'false'
            else:
                return '''<![CDATA['''+s+''']]>'''

import os

def debug(s):
    # with open(os.environ['PROGRAMDATA'].replace('\\\\', '/')+'/QualiSystems/python_cloudshell_api_debug.log', 'a') as f:
    #     f.write(s)

    #print('DEBUG: '+s)
    pass

class CloudShellAPIError(Exception):
    def __init__(self, code, message, rawxml):
        self.code = code
        self.message = message
        self.rawxml = rawxml
    def __str__(self):
        return 'CloudShell API error '+str(self.code)+': '+self.message # +'\n\nRaw XML result: '+self.rawxml
    def __repr__(self):
        return 'CloudShell API error '+str(self.code)+': '+self.message # +'\n\nRaw XML result: '+self.rawxml

class CloudShellAPISession:
  def __init__(self, host, user, password, domain, timezone = 'UTC', datetimeformat = 'MM/dd/yyyy HH:mm'):
    self.host = host
    self.url = 'http://'+host+':8029/ResourceManagerApiService/'
    self.user = user
    self.password = password
    self.domain = domain
    self.hostname = socket.gethostname() + ':8029'
    self.headers = {'Content-Type': 'text/xml','Accept': '*/*','ClientTimeZoneId': timezone,'DateTimeFormat': datetimeformat}
    self.domain = self.Logon(user, password, domain).Domain.DomainId

  def __send_request(self, message, user,domain,operation):
    request_headers = self.headers.copy()
    request_headers['Content-Length'] = len(message)
    request_headers['Host'] = self.host+':8029'
    request_headers['Authorization'] = 'Username='+user+';MachineName='+self.hostname+';LoggedInDomainId='+domain
    debug('Sending: ' + message)
    debug('Headers: '+str(request_headers))
    operation_url = self.url + operation
    request_object = URLLIB23.Request(operation_url, message.encode('utf-8'),request_headers)
    response = URLLIB23.urlopen(request_object)
    result = response.read()
    debug('Result: ' + result.decode('utf-8'))
    return result
      

  def ActivateTopology(self , reservationId , topologyFullPath ) :
    """
    Activates a specified topology.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str topologyFullPath:  Topology Full Path - Specify the full topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: ActiveTopologyInfo
    """
    sb=''
    sb+='<ActivateTopology>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='</ActivateTopology>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ActivateTopology')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def AddGroupsToDomain(self , domainName , groupNames , readOnly = False) :
    """
    Add groups to a domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param list[str] groupNames:  Groups Names - Specify an array of one or more groups.
    :param bool readOnly:  View Only - Specify if the array of group should be added with view only permissions.
    :rtype: str
    """
    sb=''
    sb+='<AddGroupsToDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <groupNames>\n'
    if groupNames is not None:
      for x in groupNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </groupNames>\n'
    if readOnly is None:
      readOnly=False
    sb+='    <readOnly>'+nonnull(readOnly)+'</readOnly>\n'
    sb+='</AddGroupsToDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddGroupsToDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def AddNewDomain(self , domainName , description = "") :
    """
    Adds a new domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param str description:  Description - Specify the description of the domain.
    :rtype: str
    """
    sb=''
    sb+='<AddNewDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <description>'+nonnull(description)+'</description>\n'
    sb+='</AddNewDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddNewDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def AddNewGroup(self , groupName , description = "", groupRole = "") :
    """
    Adds a new users group
    :param str groupName:  Group Name - Specify the name of the group.
    :param str description:  Description - Provide a short description of the group.
    :param AddRoleOptions groupRole:  Group Role - Specify the role of the group, possible values: External, Regular, DomainAdmin.
    :rtype: GroupInfo
    """
    sb=''
    sb+='<AddNewGroup>\n'
    sb+='    <groupName>'+nonnull(groupName)+'</groupName>\n'
    sb+='    <description>'+nonnull(description)+'</description>\n'
    sb+='    <groupRole>'+nonnull(groupRole)+'</groupRole>\n'
    sb+='</AddNewGroup>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddNewGroup')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def AddNewUser(self , username , password , isActive , isAdmin , email = "") :
    """
    Configures user login details and permissions. Use AddUsersToGroup to specify the user’s domain access.
    :param str username:  Username - Specify the name of the user.
    :param str password:  Password - Specify the user’s login password.
    :param bool isActive:  Is Active - Grant or deny active access to the application.
    :param bool isAdmin:  Is Admin - Add the user to the System Administrators group.
    :param str email:  Email - Specify the user’s email address.
    :rtype: UserInfo
    """
    sb=''
    sb+='<AddNewUser>\n'
    sb+='    <username>'+nonnull(username)+'</username>\n'
    sb+='    <password>'+nonnull(password)+'</password>\n'
    sb+='    <email>'+nonnull(email)+'</email>\n'
    sb+='    <isActive>'+nonnull(isActive)+'</isActive>\n'
    sb+='    <isAdmin>'+nonnull(isAdmin)+'</isAdmin>\n'
    sb+='</AddNewUser>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddNewUser')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def AddPermittedUsersToReservation(self , reservationId = "", usernames = []) :
    """
    Add one or more permitted users to the specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] usernames:  User Names - List of users to permit access to the reservation.
    :rtype: str
    """
    sb=''
    sb+='<AddPermittedUsersToReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <usernames>\n'
    if usernames is not None:
      for x in usernames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </usernames>\n'
    sb+='</AddPermittedUsersToReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddPermittedUsersToReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def AddResourcesToDomain(self , domainName , resourcesNames , includeDecendants = True) :
    """
    Add resources to a domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param list[str] resourcesNames:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param bool includeDecendants:  Include Child Resources - Specify whether to include child resources.
    :rtype: str
    """
    sb=''
    sb+='<AddResourcesToDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <resourcesNames>\n'
    if resourcesNames is not None:
      for x in resourcesNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesNames>\n'
    if includeDecendants is None:
      includeDecendants=True
    sb+='    <includeDecendants>'+nonnull(includeDecendants)+'</includeDecendants>\n'
    sb+='</AddResourcesToDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddResourcesToDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def AddResourcesToReservation(self , reservationId , resourcesFullPath , shared = False) :
    """
    Reserves resources to be locked.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param bool shared:  Shared - Specify whether all resources will be shared among other enviroments
    :rtype: ReserveResourcesResponseInfo
    """
    sb=''
    sb+='<AddResourcesToReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='    <shared>'+nonnull(shared)+'</shared>\n'
    sb+='</AddResourcesToReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddResourcesToReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def AddRoutesToReservation(self , reservationId , sourceResourcesFullPath , targetResourcesFullPath , mappingType , maxHops , isShared , routeAlias = "") :
    """
    Adds (but does not connect) routes between all pairs of source and target endpoints, adding additional connectivity ports when required. Use ConnectRoutesInReservation to connect the routes.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] sourceResourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param list[str] targetResourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param MappingType mappingType:  Mapping Type - Specify bidirectional or unidirectional as the mapping type.
    :param int maxHops:  Maximum Hops - Specify the maximum number or allowed hops.
    :param bool isShared:  Is Shared - Specify whether these routes are shared. Shared routes can be used in more than one reservation.
    :param str routeAlias:  Route Alias - Specify the route’s alias.
    :rtype: RouteInfo
    """
    sb=''
    sb+='<AddRoutesToReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <sourceResourcesFullPath>\n'
    if sourceResourcesFullPath is not None:
      for x in sourceResourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </sourceResourcesFullPath>\n'
    sb+='    <targetResourcesFullPath>\n'
    if targetResourcesFullPath is not None:
      for x in targetResourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </targetResourcesFullPath>\n'
    sb+='    <mappingType>'+nonnull(mappingType)+'</mappingType>\n'
    sb+='    <maxHops>'+nonnull(maxHops)+'</maxHops>\n'
    sb+='    <routeAlias>'+nonnull(routeAlias)+'</routeAlias>\n'
    sb+='    <isShared>'+nonnull(isShared)+'</isShared>\n'
    sb+='</AddRoutesToReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddRoutesToReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def AddServiceToReservation(self , reservationId , serviceName , alias , attributes = []) :
    """
    Add service resource to existing reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str serviceName:  Service Name - Specify the service name.
    :param str alias:  Service Alias - Specify the service alias.
    :param list[AttributeNameValue] attributes:  Service Attributes - Specify a matrix of attributes and associated attribute values.
    :rtype: str
    """
    sb=''
    sb+='<AddServiceToReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <serviceName>'+nonnull(serviceName)+'</serviceName>\n'
    sb+='    <alias>'+nonnull(alias)+'</alias>\n'
    sb+='    <attributes>\n'
    if attributes is not None:
        for x in attributes:
            sb+='        <AttributeNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </AttributeNameValue>\n'
    sb+='    </attributes>\n'
    sb+='</AddServiceToReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddServiceToReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def AddTopologiesToDomain(self , domainName , topologyNames ) :
    """
    Adds a list of one or more topologies to a domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param list[str] topologyNames:  Topologies Full Path - Specify a list of topology names. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: str
    """
    sb=''
    sb+='<AddTopologiesToDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <topologyNames>\n'
    if topologyNames is not None:
      for x in topologyNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </topologyNames>\n'
    sb+='</AddTopologiesToDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddTopologiesToDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def AddTopologyToReservation(self , reservationId , topologyFullPath , globalInputs = [], requirementsInputs = [], additionalInfoInputs = []) :
    """
    Reserves the specified topology.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str topologyFullPath:  Topology Full Path - Specify the full topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :param list[UpdateTopologyGlobalInputsRequest] globalInputs:  Global Inputs - Global inputs associated with the specified topology.
    :param list[UpdateTopologyRequirementsInputsRequest] requirementsInputs:  Requirements Inputs - Requirements inputs associated with the specified topology.
    :param list[UpdateTopologyAdditionalInfoInputsRequest] additionalInfoInputs:  Additional Info Inputs - Additional info inputs associated with the specified topology.
    :rtype: ReserveTopologyResponseInfo
    """
    sb=''
    sb+='<AddTopologyToReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='    <globalInputs>\n'
    if globalInputs is not None:
        for x in globalInputs:
            sb+='        <UpdateTopologyGlobalInputsRequest>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </UpdateTopologyGlobalInputsRequest>\n'
    sb+='    </globalInputs>\n'
    sb+='    <requirementsInputs>\n'
    if requirementsInputs is not None:
        for x in requirementsInputs:
            sb+='        <UpdateTopologyRequirementsInputsRequest>\n'
            sb+='            <ResourceName>'+nonnull(x.ResourceName)+'</ResourceName>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='            <Type>'+nonnull(x.Type)+'</Type>\n'
            sb+='        </UpdateTopologyRequirementsInputsRequest>\n'
    sb+='    </requirementsInputs>\n'
    sb+='    <additionalInfoInputs>\n'
    if additionalInfoInputs is not None:
        for x in additionalInfoInputs:
            sb+='        <UpdateTopologyAdditionalInfoInputsRequest>\n'
            sb+='            <ResourceName>'+nonnull(x.ResourceName)+'</ResourceName>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </UpdateTopologyAdditionalInfoInputsRequest>\n'
    sb+='    </additionalInfoInputs>\n'
    sb+='</AddTopologyToReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddTopologyToReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def AddUsersToGroup(self , usernames , groupName ) :
    """
    Adds a list of one or more users to the specified group.
    :param list[str] usernames:  Usernames - Specify an array of one or more users.
    :param str groupName:  Group Name - Specify the name of the group.
    :rtype: str
    """
    sb=''
    sb+='<AddUsersToGroup>\n'
    sb+='    <usernames>\n'
    if usernames is not None:
      for x in usernames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </usernames>\n'
    sb+='    <groupName>'+nonnull(groupName)+'</groupName>\n'
    sb+='</AddUsersToGroup>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AddUsersToGroup')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ArchiveDomain(self , domainName ) :
    """
    Archive a domain. All future reservation will be deleted.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :rtype: str
    """
    sb=''
    sb+='<ArchiveDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='</ArchiveDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ArchiveDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def AutoLoad(self , resourceFullPath ) :
    """
    Overrides the data of a specified L1 switch with current device settings and mappings.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<AutoLoad>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</AutoLoad>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'AutoLoad')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ClearAndResetConsole(self , reservationId , resourceFullPath , consolePortsFullPath , baudRate ) :
    """
    Clears and resets specified resource console ports.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param list[str] consolePortsFullPath:  Console Ports - Specify a list of console ports according to their location in the Resource Explorer. Include the full path from the root to each console port, separated by slashes. For example: Console/Ports/PortName.
    :param int baudRate:  Baud Rate - Specify the baud rate to apply to the ports.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ClearAndResetConsole>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <consolePortsFullPath>\n'
    if consolePortsFullPath is not None:
      for x in consolePortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </consolePortsFullPath>\n'
    sb+='    <baudRate>'+nonnull(baudRate)+'</baudRate>\n'
    sb+='</ClearAndResetConsole>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ClearAndResetConsole')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def ConnectRoutesInReservation(self , reservationId , endpoints , mappingType ) :
    """
    Connects requested routes. It locks the resources and adds route mappings. The routes must already exist in the reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] endpoints:  Endpoints - The routes’ endpoints to connect.
    :param MappingType mappingType:  Mapping Type - Specify bidirectional or unidirectional as the mapping type.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<ConnectRoutesInReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <endpoints>\n'
    if endpoints is not None:
      for x in endpoints:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </endpoints>\n'
    sb+='    <mappingType>'+nonnull(mappingType)+'</mappingType>\n'
    sb+='</ConnectRoutesInReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ConnectRoutesInReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def CopyDomainsResources(self , domainNameSources , domainNameDestination ) :
    """
    Copy resources from a list of source domains to a target domain.
    :param list[str] domainNameSources:  Source Domains - Specify the names of the source domains.
    :param str domainNameDestination:  Target Domain - Specify the name of the target domain.
    :rtype: str
    """
    sb=''
    sb+='<CopyDomainsResources>\n'
    sb+='    <domainNameSources>\n'
    if domainNameSources is not None:
      for x in domainNameSources:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </domainNameSources>\n'
    sb+='    <domainNameDestination>'+nonnull(domainNameDestination)+'</domainNameDestination>\n'
    sb+='</CopyDomainsResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CopyDomainsResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def CreateFolder(self , folderFullPath ) :
    """
    Adds a new folder to the specified path.
    :param str folderFullPath:  Folder Full Path - Specify the full folder name. Include the full path from the root to a specific folder, separated by slashes. For example: ResourceFamilyFolder/ResourceModelFolder.
    :rtype: str
    """
    sb=''
    sb+='<CreateFolder>\n'
    sb+='    <folderFullPath>'+nonnull(folderFullPath)+'</folderFullPath>\n'
    sb+='</CreateFolder>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateFolder')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def CreateImmediateReservation(self , reservationName , owner , durationInMinutes , notifyOnStart = False, notifyOnEnd = False, notificationMinutesBeforeEnd = 0) :
    """
    Defines a reservation to be started immediately.
    :param str reservationName:  Reservation Name - Specify the name of the reservation.
    :param str owner:  Reservation Owner - Specify the user name of the reservation owner.
    :param int durationInMinutes:  Duration - Specify the length of the reservation. (in minutes)
    :param bool notifyOnStart:  Notify On Start - Indicate whether to notify the reservation owner when the reservation starts.
    :param bool notifyOnEnd:  Notify On End - Indicate whether to notify the reservation owner when the reservation ends.
    :param int notificationMinutesBeforeEnd:  Notification Minutes Before End - Indicate the number of minutes before the end of the reservation to send out a Notify On End alert to the reservation owner. (0 = disabled)
    :rtype: CreateReservationResponseInfo
    """
    sb=''
    sb+='<CreateImmediateReservation>\n'
    sb+='    <reservationName>'+nonnull(reservationName)+'</reservationName>\n'
    sb+='    <owner>'+nonnull(owner)+'</owner>\n'
    sb+='    <durationInMinutes>'+nonnull(durationInMinutes)+'</durationInMinutes>\n'
    if notifyOnStart is None:
      notifyOnStart=False
    sb+='    <notifyOnStart>'+nonnull(notifyOnStart)+'</notifyOnStart>\n'
    if notifyOnEnd is None:
      notifyOnEnd=False
    sb+='    <notifyOnEnd>'+nonnull(notifyOnEnd)+'</notifyOnEnd>\n'
    if notificationMinutesBeforeEnd is None:
      notificationMinutesBeforeEnd=0
    sb+='    <notificationMinutesBeforeEnd>'+nonnull(notificationMinutesBeforeEnd)+'</notificationMinutesBeforeEnd>\n'
    sb+='</CreateImmediateReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateImmediateReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def CreateImmediateTopologyReservation(self , reservationName , owner , durationInMinutes , notifyOnStart = False, notifyOnEnd = False, notificationMinutesBeforeEnd = 0, topologyFullPath = "", globalInputs = [], requirementsInputs = [], additionalInfoInputs = []) :
    """
    Defines a reservation to be started immediately.
    :param str reservationName:  Reservation Name - Specify the name of the reservation.
    :param str owner:  Reservation Owner - Specify the user name of the reservation owner.
    :param int durationInMinutes:  Duration - Specify the length of the reservation. (in minutes)
    :param bool notifyOnStart:  Notify On Start - Indicate whether to notify the reservation owner when the reservation starts.
    :param bool notifyOnEnd:  Notify On End - Indicate whether to notify the reservation owner when the reservation ends.
    :param int notificationMinutesBeforeEnd:  Notification Minutes Before End - Indicate the number of minutes before the end of the reservation to send out a Notify On End alert to the reservation owner. (0 = disabled)
    :param str topologyFullPath:  Topology Full Path - Specify the full topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :param list[UpdateTopologyGlobalInputsRequest] globalInputs:  Global Inputs - Global inputs associated with the specified topology.
    :param list[UpdateTopologyRequirementsInputsRequest] requirementsInputs:  Requirements Inputs - Requirements inputs associated with the specified topology.
    :param list[UpdateTopologyAdditionalInfoInputsRequest] additionalInfoInputs:  Additional Info Inputs - Additional info inputs associated with the specified topology.
    :rtype: CreateReservationResponseInfo
    """
    sb=''
    sb+='<CreateImmediateReservation>\n'
    sb+='    <reservationName>'+nonnull(reservationName)+'</reservationName>\n'
    sb+='    <owner>'+nonnull(owner)+'</owner>\n'
    sb+='    <durationInMinutes>'+nonnull(durationInMinutes)+'</durationInMinutes>\n'
    if notifyOnStart is None:
      notifyOnStart=False
    sb+='    <notifyOnStart>'+nonnull(notifyOnStart)+'</notifyOnStart>\n'
    if notifyOnEnd is None:
      notifyOnEnd=False
    sb+='    <notifyOnEnd>'+nonnull(notifyOnEnd)+'</notifyOnEnd>\n'
    if notificationMinutesBeforeEnd is None:
      notificationMinutesBeforeEnd=0
    sb+='    <notificationMinutesBeforeEnd>'+nonnull(notificationMinutesBeforeEnd)+'</notificationMinutesBeforeEnd>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='    <globalInputs>\n'
    if globalInputs is not None:
        for x in globalInputs:
            sb+='        <UpdateTopologyGlobalInputsRequest>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </UpdateTopologyGlobalInputsRequest>\n'
    sb+='    </globalInputs>\n'
    sb+='    <requirementsInputs>\n'
    if requirementsInputs is not None:
        for x in requirementsInputs:
            sb+='        <UpdateTopologyRequirementsInputsRequest>\n'
            sb+='            <ResourceName>'+nonnull(x.ResourceName)+'</ResourceName>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='            <Type>'+nonnull(x.Type)+'</Type>\n'
            sb+='        </UpdateTopologyRequirementsInputsRequest>\n'
    sb+='    </requirementsInputs>\n'
    sb+='    <additionalInfoInputs>\n'
    if additionalInfoInputs is not None:
        for x in additionalInfoInputs:
            sb+='        <UpdateTopologyAdditionalInfoInputsRequest>\n'
            sb+='            <ResourceName>'+nonnull(x.ResourceName)+'</ResourceName>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </UpdateTopologyAdditionalInfoInputsRequest>\n'
    sb+='    </additionalInfoInputs>\n'
    sb+='</CreateImmediateReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateImmediateTopologyReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def CreateReservation(self , reservationName , owner , startTime , endTime , notifyOnStart = False, notifyOnEnd = False, notificationMinutesBeforeEnd = 0) :
    """
    Defines a new reservation.
    :param str reservationName:  Reservation Name - Specify the name of the reservation.
    :param str owner:  Reservation Owner - Specify the user name of the reservation owner.
    :param Date startTime:  Start Time - The start time of the reservation.
    :param Date endTime:  End Time - The end time of the reservation.
    :param bool notifyOnStart:  Notify On Start - Indicate whether to notify the reservation owner when the reservation starts.
    :param bool notifyOnEnd:  Notify On End - Indicate whether to notify the reservation owner when the reservation ends.
    :param int notificationMinutesBeforeEnd:  Notification Minutes Before End - Indicate the number of minutes before the end of the reservation to send out a Notify On End alert to the reservation owner. (0 = disabled)
    :rtype: CreateReservationResponseInfo
    """
    sb=''
    sb+='<CreateReservation>\n'
    sb+='    <reservationName>'+nonnull(reservationName)+'</reservationName>\n'
    sb+='    <owner>'+nonnull(owner)+'</owner>\n'
    sb+='    <startTime>'+nonnull(startTime)+'</startTime>\n'
    sb+='    <endTime>'+nonnull(endTime)+'</endTime>\n'
    if notifyOnStart is None:
      notifyOnStart=False
    sb+='    <notifyOnStart>'+nonnull(notifyOnStart)+'</notifyOnStart>\n'
    if notifyOnEnd is None:
      notifyOnEnd=False
    sb+='    <notifyOnEnd>'+nonnull(notifyOnEnd)+'</notifyOnEnd>\n'
    if notificationMinutesBeforeEnd is None:
      notificationMinutesBeforeEnd=0
    sb+='    <notificationMinutesBeforeEnd>'+nonnull(notificationMinutesBeforeEnd)+'</notificationMinutesBeforeEnd>\n'
    sb+='</CreateReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def CreateResource(self , resourceFamily , resourceModel , resourceName , resourceAddress , folderFullPath = "", parentResourceFullPath = "", resourceDescription = "") :
    """
    Adds a new resource.
    :param str resourceFamily:  Resource Family - Specify the name of the resource family.
    :param str resourceModel:  Resource Model - Specify the resource model.
    :param str resourceName:  Resource Name - Specify the resource name.
    :param str resourceAddress:  Resource Address - Specify the resource address.
    :param str folderFullPath:  Folder Full Path - Specify the full folder name. Include the full path from the root to a specific folder, separated by slashes. For example: ResourceFamilyFolder/ResourceModelFolder.
    :param str parentResourceFullPath:  Parent Resource Full Path - Specify the full path from the root to a parent resource, separated by slashes. For example: Traffic Generators/Generic.
    :param str resourceDescription:  Resource Description - Provide a short description to help identify the resource.
    :rtype: ResourceInfo
    """
    sb=''
    sb+='<CreateResource>\n'
    sb+='    <resourceFamily>'+nonnull(resourceFamily)+'</resourceFamily>\n'
    sb+='    <resourceModel>'+nonnull(resourceModel)+'</resourceModel>\n'
    sb+='    <resourceName>'+nonnull(resourceName)+'</resourceName>\n'
    sb+='    <resourceAddress>'+nonnull(resourceAddress)+'</resourceAddress>\n'
    sb+='    <folderFullPath>'+nonnull(folderFullPath)+'</folderFullPath>\n'
    sb+='    <parentResourceFullPath>'+nonnull(parentResourceFullPath)+'</parentResourceFullPath>\n'
    sb+='    <resourceDescription>'+nonnull(resourceDescription)+'</resourceDescription>\n'
    sb+='</CreateResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateResource')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def CreateResources(self , resourceInfoDtos ) :
    """
    Adds new resources.
    :param list[ResourceInfoDto] resourceInfoDtos:  Resources - Specify a matrix of resources to add. For example: {['Resource Family','Resource Model','Resource Name','Resource Address','Folder Full Path','Parent Resource Full Path','Resource Description';]}
    :rtype: str
    """
    sb=''
    sb+='<CreateResources>\n'
    sb+='    <resourceInfoDtos>\n'
    if resourceInfoDtos is not None:
        for x in resourceInfoDtos:
            sb+='        <ResourceInfoDto>\n'
            sb+='            <Family>'+nonnull(x.Family)+'</Family>\n'
            sb+='            <Model>'+nonnull(x.Model)+'</Model>\n'
            sb+='            <FullName>'+nonnull(x.FullName)+'</FullName>\n'
            sb+='            <Address>'+nonnull(x.Address)+'</Address>\n'
            sb+='            <FolderFullpath>'+nonnull(x.FolderFullpath)+'</FolderFullpath>\n'
            sb+='            <ParentFullName>'+nonnull(x.ParentFullName)+'</ParentFullName>\n'
            sb+='            <Description>'+nonnull(x.Description)+'</Description>\n'
            sb+='        </ResourceInfoDto>\n'
    sb+='    </resourceInfoDtos>\n'
    sb+='</CreateResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def CreateRouteInReservation(self , reservationId , sourceResourceFullPath , targetResourceFullPath , overrideActiveRoutes , mappingType , maxHops , isShared , routeAlias = "") :
    """
    Creates a route between the specified source and target resources.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str sourceResourceFullPath:  Source Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str targetResourceFullPath:  Target Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param bool overrideActiveRoutes:  Override Active Routes - Specify whether the new route can override existing routes.
    :param MappingType mappingType:  Mapping Type - Specify bidirectional or unidirectional as the mapping type.
    :param int maxHops:  Maximum Hops - Specify the maximum number or allowed hops.
    :param bool isShared:  Is Shared - Specify whether this route is shared. Shared routes can be used in more than one reservation.
    :param str routeAlias:  Route Alias - Specify the route’s alias.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<CreateRouteInReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <sourceResourceFullPath>'+nonnull(sourceResourceFullPath)+'</sourceResourceFullPath>\n'
    sb+='    <targetResourceFullPath>'+nonnull(targetResourceFullPath)+'</targetResourceFullPath>\n'
    sb+='    <overrideActiveRoutes>'+nonnull(overrideActiveRoutes)+'</overrideActiveRoutes>\n'
    sb+='    <mappingType>'+nonnull(mappingType)+'</mappingType>\n'
    sb+='    <maxHops>'+nonnull(maxHops)+'</maxHops>\n'
    sb+='    <routeAlias>'+nonnull(routeAlias)+'</routeAlias>\n'
    sb+='    <isShared>'+nonnull(isShared)+'</isShared>\n'
    sb+='</CreateRouteInReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateRouteInReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def CreateRoutesInReservation(self , reservationId , sourceResourcesFullPath , targetResourcesFullPath , overrideActiveRoutes , mappingType , maxHops , isShared , routeAlias = "") :
    """
    Create routes between the listed source and target resources. Routes will be created for each pair of source and target resources.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] sourceResourcesFullPath:  Source Resources - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param list[str] targetResourcesFullPath:  Target Resources - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param bool overrideActiveRoutes:  Override Active Routes - Specify whether the new route can override existing routes.
    :param MappingType mappingType:  Mapping Type - Specify bidirectional or unidirectional as the mapping type.
    :param int maxHops:  Maximum Hops - Specify the maximum number or allowed hops.
    :param bool isShared:  Is Shared - Specify whether these routes are shared. Shared routes can be used in more than one reservation.
    :param str routeAlias:  Route Alias - Specify the route’s alias.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<CreateRoutesInReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <sourceResourcesFullPath>\n'
    if sourceResourcesFullPath is not None:
      for x in sourceResourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </sourceResourcesFullPath>\n'
    sb+='    <targetResourcesFullPath>\n'
    if targetResourcesFullPath is not None:
      for x in targetResourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </targetResourcesFullPath>\n'
    sb+='    <overrideActiveRoutes>'+nonnull(overrideActiveRoutes)+'</overrideActiveRoutes>\n'
    sb+='    <mappingType>'+nonnull(mappingType)+'</mappingType>\n'
    sb+='    <maxHops>'+nonnull(maxHops)+'</maxHops>\n'
    sb+='    <routeAlias>'+nonnull(routeAlias)+'</routeAlias>\n'
    sb+='    <isShared>'+nonnull(isShared)+'</isShared>\n'
    sb+='</CreateRoutesInReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateRoutesInReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def CreateTopologyReservation(self , reservationName , owner , startTime , endTime , notifyOnStart = False, notifyOnEnd = False, notificationMinutesBeforeEnd = 0, topologyFullPath = "", globalInputs = [], requirementsInputs = [], additionalInfoInputs = []) :
    """
    Defines a new reservation.
    :param str reservationName:  Reservation Name - Specify the name of the reservation.
    :param str owner:  Reservation Owner - Specify the user name of the reservation owner.
    :param Date startTime:  Start Time - The start time of the reservation.
    :param Date endTime:  End Time - The end time of the reservation.
    :param bool notifyOnStart:  Notify On Start - Indicate whether to notify the reservation owner when the reservation starts.
    :param bool notifyOnEnd:  Notify On End - Indicate whether to notify the reservation owner when the reservation ends.
    :param int notificationMinutesBeforeEnd:  Notification Minutes Before End - Indicate the number of minutes before the end of the reservation to send out a Notify On End alert to the reservation owner. (0 = disabled)
    :param str topologyFullPath:  Topology Full Path - Specify the full topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :param list[UpdateTopologyGlobalInputsRequest] globalInputs:  Global Inputs - Global inputs associated with the specified topology.
    :param list[UpdateTopologyRequirementsInputsRequest] requirementsInputs:  Requirements Inputs - Requirements inputs associated with the specified topology.
    :param list[UpdateTopologyAdditionalInfoInputsRequest] additionalInfoInputs:  Additional Info Inputs - Additional info inputs associated with the specified topology.
    :rtype: CreateReservationResponseInfo
    """
    sb=''
    sb+='<CreateReservation>\n'
    sb+='    <reservationName>'+nonnull(reservationName)+'</reservationName>\n'
    sb+='    <owner>'+nonnull(owner)+'</owner>\n'
    sb+='    <startTime>'+nonnull(startTime)+'</startTime>\n'
    sb+='    <endTime>'+nonnull(endTime)+'</endTime>\n'
    if notifyOnStart is None:
      notifyOnStart=False
    sb+='    <notifyOnStart>'+nonnull(notifyOnStart)+'</notifyOnStart>\n'
    if notifyOnEnd is None:
      notifyOnEnd=False
    sb+='    <notifyOnEnd>'+nonnull(notifyOnEnd)+'</notifyOnEnd>\n'
    if notificationMinutesBeforeEnd is None:
      notificationMinutesBeforeEnd=0
    sb+='    <notificationMinutesBeforeEnd>'+nonnull(notificationMinutesBeforeEnd)+'</notificationMinutesBeforeEnd>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='    <globalInputs>\n'
    if globalInputs is not None:
        for x in globalInputs:
            sb+='        <UpdateTopologyGlobalInputsRequest>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </UpdateTopologyGlobalInputsRequest>\n'
    sb+='    </globalInputs>\n'
    sb+='    <requirementsInputs>\n'
    if requirementsInputs is not None:
        for x in requirementsInputs:
            sb+='        <UpdateTopologyRequirementsInputsRequest>\n'
            sb+='            <ResourceName>'+nonnull(x.ResourceName)+'</ResourceName>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='            <Type>'+nonnull(x.Type)+'</Type>\n'
            sb+='        </UpdateTopologyRequirementsInputsRequest>\n'
    sb+='    </requirementsInputs>\n'
    sb+='    <additionalInfoInputs>\n'
    if additionalInfoInputs is not None:
        for x in additionalInfoInputs:
            sb+='        <UpdateTopologyAdditionalInfoInputsRequest>\n'
            sb+='            <ResourceName>'+nonnull(x.ResourceName)+'</ResourceName>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </UpdateTopologyAdditionalInfoInputsRequest>\n'
    sb+='    </additionalInfoInputs>\n'
    sb+='</CreateReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'CreateTopologyReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def DecryptPassword(self , encryptedString ) :
    """
    Decrypt a password.
    :param str encryptedString:  Encrypted string - The encrypted string for decryption.
    :rtype: AttributeValueInfo
    """
    sb=''
    sb+='<DecryptPassword>\n'
    sb+='    <encryptedString>'+nonnull(encryptedString)+'</encryptedString>\n'
    sb+='</DecryptPassword>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DecryptPassword')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def DeleteDomain(self , domainName ) :
    """
    Deletes a domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :rtype: str
    """
    sb=''
    sb+='<DeleteDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='</DeleteDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DeleteFolder(self , folderFullPath ) :
    """
    Deletes the specified folder.
    :param str folderFullPath:  Folder Full Path - Specify the full folder name. Include the full path from the root to a specific folder, separated by slashes. For example: ResourceFamilyFolder/ResourceModelFolder.
    :rtype: str
    """
    sb=''
    sb+='<DeleteFolder>\n'
    sb+='    <folderFullPath>'+nonnull(folderFullPath)+'</folderFullPath>\n'
    sb+='</DeleteFolder>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteFolder')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DeleteGroup(self , groupName ) :
    """
    Deletes the specified group.
    :param str groupName:  Group Name - Specify the name of the group.
    :rtype: str
    """
    sb=''
    sb+='<DeleteGroup>\n'
    sb+='    <groupName>'+nonnull(groupName)+'</groupName>\n'
    sb+='</DeleteGroup>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteGroup')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DeleteReservation(self , reservationId , unmap ) :
    """
    Deletes the specified reservation and optionally, releases all reservation resources.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param bool unmap:  Unmap Resources - Specify whether to keep mappings or release mapped resources when deleting the reservation.
    :rtype: str
    """
    sb=''
    sb+='<DeleteReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <unmap>'+nonnull(unmap)+'</unmap>\n'
    sb+='</DeleteReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DeleteResource(self , resourceFullPath ) :
    """
    Deletes the specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<DeleteResource>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</DeleteResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteResource')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DeleteResources(self , resourcesFullPath ) :
    """
    Deletes the specified resources.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :rtype: str
    """
    sb=''
    sb+='<DeleteResources>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='</DeleteResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DeleteTopology(self , topologyFullPath ) :
    """
    Deletes the specified topology.
    :param str topologyFullPath:  Topology Full Path - Specify the topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: str
    """
    sb=''
    sb+='<DeleteTopology>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='</DeleteTopology>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteTopology')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DeleteUser(self , username ) :
    """
    Deletes the specified user.
    :param str username:  Username - Specify the name of the user.
    :rtype: str
    """
    sb=''
    sb+='<DeleteUser>\n'
    sb+='    <username>'+nonnull(username)+'</username>\n'
    sb+='</DeleteUser>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DeleteUser')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def DisconnectRoutesInReservation(self , reservationId , endpoints ) :
    """
    Disconnects requested routes. It unlocks the resources (if locked), and removes route mappings, but does not remove the route resources from the reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] endpoints:  Endpoints - The routes endpoints to disconnect.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<DisconnectRoutesInReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <endpoints>\n'
    if endpoints is not None:
      for x in endpoints:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </endpoints>\n'
    sb+='</DisconnectRoutesInReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'DisconnectRoutesInReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def EndReservation(self , reservationId , unmap ) :
    """
    Ends the specified reservation and optionally, unlocks and releases all reservation resources.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param bool unmap:  Unmap resources - Specify whether to keep mappings or release mapped resources when deleting the reservation.
    :rtype: str
    """
    sb=''
    sb+='<EndReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <unmap>'+nonnull(unmap)+'</unmap>\n'
    sb+='</EndReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'EndReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def EnqueueCommand(self , reservationId , targetName , targetType , commandName , commandInputs = [], printOutput = False) :
    """
    Enqueues a command to be executed for the specified target.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str targetName:  Target Name - Specify the name of the target according to the target type: for resources - specify the resouce's name, for services - the service's alias.
    :param CommandTargetType targetType:  Target Type - Specify the target type for command execution.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[InputNameValue] commandInputs:  Command Inputs - Specify a matrix of input names and values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: str
    """
    sb=''
    sb+='<EnqueueCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <targetName>'+nonnull(targetName)+'</targetName>\n'
    sb+='    <targetType>'+nonnull(targetType)+'</targetType>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <commandInputs>\n'
    if commandInputs is not None:
        for x in commandInputs:
            sb+='        <InputNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </InputNameValue>\n'
    sb+='    </commandInputs>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</EnqueueCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'EnqueueCommand')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def EnqueueEnvironmentCommand(self , reservationId , commandName , commandInputs = [], printOutput = False) :
    """
    Enqueues a command to be executed for the specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[InputNameValue] commandInputs:  Command Inputs - Specify a matrix of input names and values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: str
    """
    sb=''
    sb+='<EnqueueEnvironmentCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <commandInputs>\n'
    if commandInputs is not None:
        for x in commandInputs:
            sb+='        <InputNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </InputNameValue>\n'
    sb+='    </commandInputs>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</EnqueueEnvironmentCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'EnqueueEnvironmentCommand')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def EnqueueResourceCommand(self , reservationId , resourceFullPath , commandName , parameterValues = [], printOutput = False) :
    """
    Enqueues a command to be executed for the specified driver.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[str] parameterValues:  Command Parameters - Specify the list of parameters values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: str
    """
    sb=''
    sb+='<EnqueueResourceCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <parameterValues>\n'
    if parameterValues is not None:
      for x in parameterValues:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </parameterValues>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</EnqueueResourceCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'EnqueueResourceCommand')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def EnqueueServiceCommand(self , reservationId , serviceAlias , commandName , parameterValues = [], printOutput = False) :
    """
    Enqueues a command to be executed for the specified driver.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str serviceAlias:  Service Alias - Specify the alias of the service. The service alias is its identifier in the environment context. It can be retrieved via the environment details API and is displayed visually on the diagram.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[str] parameterValues:  Command Parameters - Specify the list of parameters values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: str
    """
    sb=''
    sb+='<EnqueueServiceCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <serviceAlias>'+nonnull(serviceAlias)+'</serviceAlias>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <parameterValues>\n'
    if parameterValues is not None:
      for x in parameterValues:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </parameterValues>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</EnqueueServiceCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'EnqueueServiceCommand')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def EnqueueTopologyCommand(self , reservationId , commandName , parameterValues = [], printOutput = False) :
    """
    Enqueues a command to be executed for the specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[str] parameterValues:  Command Parameters - Specify the list of parameters values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: str
    """
    sb=''
    sb+='<EnqueueTopologyCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <parameterValues>\n'
    if parameterValues is not None:
      for x in parameterValues:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </parameterValues>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</EnqueueTopologyCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'EnqueueTopologyCommand')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ExcludeResource(self , resourceFullPath ) :
    """
    Excludes a specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<ExcludeResource>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</ExcludeResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExcludeResource')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ExcludeResources(self , resourcesFullPath ) :
    """
    Excludes the specified resources.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :rtype: str
    """
    sb=''
    sb+='<ExcludeResources>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='</ExcludeResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExcludeResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ExecuteCommand(self , reservationId , targetName , targetType , commandName , commandInputs = [], printOutput = False) :
    """
    Executes a command for the specified target.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str targetName:  Target Name - Specify the name of the target according to the target type: for resources - specify the resouce's name, for services - the service's alias.
    :param CommandTargetType targetType:  Target Type - Specify the target type for command execution.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[InputNameValue] commandInputs:  Command Inputs - Specify a matrix of input names and values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ExecuteCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <targetName>'+nonnull(targetName)+'</targetName>\n'
    sb+='    <targetType>'+nonnull(targetType)+'</targetType>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <commandInputs>\n'
    if commandInputs is not None:
        for x in commandInputs:
            sb+='        <InputNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </InputNameValue>\n'
    sb+='    </commandInputs>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</ExecuteCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExecuteCommand')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def ExecuteEnvironmentCommand(self , reservationId , commandName , commandInputs = [], printOutput = False) :
    """
    Executes a command for the specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[InputNameValue] commandInputs:  Command Inputs - Specify a matrix of input names and values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ExecuteEnvironmentCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <commandInputs>\n'
    if commandInputs is not None:
        for x in commandInputs:
            sb+='        <InputNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </InputNameValue>\n'
    sb+='    </commandInputs>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</ExecuteEnvironmentCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExecuteEnvironmentCommand')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def ExecuteResourceCommand(self , reservationId , resourceFullPath , commandName , parameterValues = [], printOutput = False) :
    """
    Executes a command for the specified driver.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[str] parameterValues:  Command Parameters - Specify the list of parameters values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ExecuteResourceCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <parameterValues>\n'
    if parameterValues is not None:
      for x in parameterValues:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </parameterValues>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</ExecuteResourceCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExecuteResourceCommand')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def ExecuteResourceConnectedCommand(self , reservationId , resourceFullPath , commandName , commandTag , parameterValues = [], connectedPortsFullPath = [], printOutput = False) :
    """
    Executes a command for the specified driver.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Name - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: RouterA/Port1.
    :param str commandName:  Command Name - Specify the name of the command.
    :param str commandTag:  Command Tag - Specify the command tag. Connected command tags are used to define categories of functionality (e.g 'virtualization').
    :param list[str] parameterValues:  Command Parameters - Specify the list of parameters values required for executing the command.
    :param list[str] connectedPortsFullPath:  Connected Ports - Specify the list of connected ports to use in this operation. Include the full path from the root resource to each port, separated by slashes. For example: Switch20/Blade5/PowerPort1. Leave blank to perform the connected operation on all of the specified resource’s connected ports.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ExecuteResourceConnectedCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <commandTag>'+nonnull(commandTag)+'</commandTag>\n'
    sb+='    <parameterValues>\n'
    if parameterValues is not None:
      for x in parameterValues:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </parameterValues>\n'
    sb+='    <connectedPortsFullPath>\n'
    if connectedPortsFullPath is not None:
      for x in connectedPortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </connectedPortsFullPath>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</ExecuteResourceConnectedCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExecuteResourceConnectedCommand')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def ExecuteServiceCommand(self , reservationId , serviceAlias , commandName , parameterValues = [], printOutput = False) :
    """
    Executes a command for the specified service driver.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str serviceAlias:  Service Alias - Specify the alias of the service.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[str] parameterValues:  Command Parameters - Specify the list of parameters values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ExecuteServiceCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <serviceAlias>'+nonnull(serviceAlias)+'</serviceAlias>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <parameterValues>\n'
    if parameterValues is not None:
      for x in parameterValues:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </parameterValues>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</ExecuteServiceCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExecuteServiceCommand')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def ExecuteTopologyCommand(self , reservationId , commandName , parameterValues = [], printOutput = False) :
    """
    Executes a command for the specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str commandName:  Command Name - Specify the name of the command.
    :param list[str] parameterValues:  Command Parameters - Specify the list of parameters values required for executing the command.
    :param bool printOutput:  Print Output - Defines whether to print the command output in the reservation command output window.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ExecuteTopologyCommand>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <commandName>'+nonnull(commandName)+'</commandName>\n'
    sb+='    <parameterValues>\n'
    if parameterValues is not None:
      for x in parameterValues:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </parameterValues>\n'
    if printOutput is None:
      printOutput=False
    sb+='    <printOutput>'+nonnull(printOutput)+'</printOutput>\n'
    sb+='</ExecuteTopologyCommand>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExecuteTopologyCommand')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def ExportFamiliesAndModels(self ) :
    """
    Exports the resource families, models, attributes and structure configuration.
    :rtype: str
    """
    sb=''
    sb+='<ExportFamiliesAndModels>\n'
    sb+='</ExportFamiliesAndModels>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExportFamiliesAndModels')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ExtendReservation(self , reservationId , minutesToAdd ) :
    """
    Extends the duration of the specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param int minutesToAdd:  Minutes To Add - Specify the number of minutes to add to the specified reservation.
    :rtype: str
    """
    sb=''
    sb+='<ExtendReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <minutesToAdd>'+nonnull(minutesToAdd)+'</minutesToAdd>\n'
    sb+='</ExtendReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ExtendReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def FindResources(self , resourceFamily , resourceModel = "", attributeValues = [], showAllDomains = False, resourceFullName = "", exactName = True, includeSubResources = True, resourceAddress = "", resourceUniqueIdentifier = "", maxResults = 500) :
    """
    Retrieves resources that match all the specified search parameters, and all reservations associated with the search results.
    :param str resourceFamily:  Resource Family - Specify the name of the resource family.
    :param str resourceModel:  Resource Model - Specify the resource model.
    :param list[AttributeNameValue] attributeValues:  Attribute Values - Specify an array of one or more attributes and attribute values.
    :param bool showAllDomains:  Show All Domains - Show all domains associated with the logged in user.
    :param str resourceFullName:  Resource Full Name - Specify part of or the full name of the resource.
    :param bool exactName:  Exact Name - Specify whether to search the exact given name or not.
    :param bool includeSubResources:  Include Sub Resources - Specify whether to retrieve the sub resources once the parent matches the name.
    :param str resourceAddress:  Resource Address - Specify the resource address. Can be partial (e.g. '192.168.').
    :param str resourceUniqueIdentifier:  Resource Unique Identifier - Specify the resource unique identifier.
    :param int maxResults:  Max Results - Specify the maximum number of resources to return.
    :rtype: FindResourceListInfo
    """
    sb=''
    sb+='<FindResources>\n'
    sb+='    <resourceFamily>'+nonnull(resourceFamily)+'</resourceFamily>\n'
    sb+='    <resourceModel>'+nonnull(resourceModel)+'</resourceModel>\n'
    sb+='    <attributeValues>\n'
    if attributeValues is not None:
        for x in attributeValues:
            sb+='        <AttributeNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </AttributeNameValue>\n'
    sb+='    </attributeValues>\n'
    if showAllDomains is None:
      showAllDomains=False
    sb+='    <showAllDomains>'+nonnull(showAllDomains)+'</showAllDomains>\n'
    sb+='    <resourceFullName>'+nonnull(resourceFullName)+'</resourceFullName>\n'
    if exactName is None:
      exactName=True
    sb+='    <exactName>'+nonnull(exactName)+'</exactName>\n'
    if includeSubResources is None:
      includeSubResources=True
    sb+='    <includeSubResources>'+nonnull(includeSubResources)+'</includeSubResources>\n'
    sb+='    <resourceAddress>'+nonnull(resourceAddress)+'</resourceAddress>\n'
    sb+='    <resourceUniqueIdentifier>'+nonnull(resourceUniqueIdentifier)+'</resourceUniqueIdentifier>\n'
    if maxResults is None:
      maxResults=500
    sb+='    <maxResults>'+nonnull(maxResults)+'</maxResults>\n'
    sb+='</FindResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'FindResources')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def FindResourcesInTimeRange(self , resourceFamily , fromTime , untilTime , resourceModel = "", attributeValues = [], showAllDomains = False, resourceFullName = "", exactName = True, includeSubResources = True, resourceAddress = "", resourceUniqueIdentifier = "", maxResults = 500) :
    """
    Retrieves resources that match all the specified search parameters, and all reservations in the specified time range associated with the search results.
    :param str resourceFamily:  Resource Family - Specify the name of the resource family.
    :param Date fromTime:  From Date Time - Specify from which time and date to check the resource's availability.
    :param Date untilTime:  Until Date Time - Specify until which time and date to check the resource's availability.
    :param str resourceModel:  Resource Model - Specify the resource model.
    :param list[AttributeNameValue] attributeValues:  Attribute Values - Specify an array of one or more attributes and attribute values.
    :param bool showAllDomains:  Show All Domains - Show all domains associated with the logged in user.
    :param str resourceFullName:  Resource Full Name - Specify part of or the full name of the resource.
    :param bool exactName:  Exact Name - Specify whether to search the exact given name or not.
    :param bool includeSubResources:  Include Sub Resources - Specify whether to retrieve the sub resources once the parent matches the name.
    :param str resourceAddress:  Resource Address - Specify the resource address. Can be partial (e.g. '192.168.').
    :param str resourceUniqueIdentifier:  Resource Unique Identifier - Specify the resource unique identifier.
    :param int maxResults:  Max Results - Specify the maximum number of resources to return.
    :rtype: FindResourceListInfo
    """
    sb=''
    sb+='<FindResourcesInTimeRange>\n'
    sb+='    <resourceFamily>'+nonnull(resourceFamily)+'</resourceFamily>\n'
    sb+='    <resourceModel>'+nonnull(resourceModel)+'</resourceModel>\n'
    sb+='    <fromTime>'+nonnull(fromTime)+'</fromTime>\n'
    sb+='    <untilTime>'+nonnull(untilTime)+'</untilTime>\n'
    sb+='    <attributeValues>\n'
    if attributeValues is not None:
        for x in attributeValues:
            sb+='        <AttributeNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </AttributeNameValue>\n'
    sb+='    </attributeValues>\n'
    if showAllDomains is None:
      showAllDomains=False
    sb+='    <showAllDomains>'+nonnull(showAllDomains)+'</showAllDomains>\n'
    sb+='    <resourceFullName>'+nonnull(resourceFullName)+'</resourceFullName>\n'
    if exactName is None:
      exactName=True
    sb+='    <exactName>'+nonnull(exactName)+'</exactName>\n'
    if includeSubResources is None:
      includeSubResources=True
    sb+='    <includeSubResources>'+nonnull(includeSubResources)+'</includeSubResources>\n'
    sb+='    <resourceAddress>'+nonnull(resourceAddress)+'</resourceAddress>\n'
    sb+='    <resourceUniqueIdentifier>'+nonnull(resourceUniqueIdentifier)+'</resourceUniqueIdentifier>\n'
    if maxResults is None:
      maxResults=500
    sb+='    <maxResults>'+nonnull(maxResults)+'</maxResults>\n'
    sb+='</FindResourcesInTimeRange>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'FindResourcesInTimeRange')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GenerateUtilizationReport(self , resourceFamilyName , fromDate = "", toDate = "", resourceFullName = "", resourceModelName = "", includeChildResources = False, groupBy = "", utilizationReportType = "") :
    """
    Generates a utilization report for the specified resources. To generate a report for all resources, leave the resourceFullName and resourceModel parameters blank.
    :param str resourceFamilyName:  Resource Family - Specify the name of the resource family.
    :param Date fromDate:  From Date - Specify the start time and date.
    :param Date toDate:  To Date - Specify the end time and date.
    :param str resourceFullName:  Resource Full Name - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName.
    :param str resourceModelName:  Resource Model - Specify the resource model.
    :param bool includeChildResources:  Include Child Resources - Specify whether to include child resources utilization.
    :param UtilizationReportGroupByOption groupBy:  Group By - Specify how to group the utilization results: Resource, User, or Machine
    :param UtilizationReportTypeOption utilizationReportType:  Report Type - Specify the report type: Lock or Mapping.
    :rtype: str
    """
    sb=''
    sb+='<GenerateUtilizationReport>\n'
    sb+='    <resourceFamilyName>'+nonnull(resourceFamilyName)+'</resourceFamilyName>\n'
    sb+='    <fromDate>'+nonnull(fromDate)+'</fromDate>\n'
    sb+='    <toDate>'+nonnull(toDate)+'</toDate>\n'
    sb+='    <resourceFullName>'+nonnull(resourceFullName)+'</resourceFullName>\n'
    sb+='    <resourceModelName>'+nonnull(resourceModelName)+'</resourceModelName>\n'
    sb+='    <includeChildResources>'+nonnull(includeChildResources)+'</includeChildResources>\n'
    sb+='    <groupBy>'+nonnull(groupBy)+'</groupBy>\n'
    sb+='    <utilizationReportType>'+nonnull(utilizationReportType)+'</utilizationReportType>\n'
    sb+='</GenerateUtilizationReport>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GenerateUtilizationReport')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def GetAbstractTemplateList(self ) :
    """
    Retrieve a list of abstract templates.
    :rtype: AbstractTemplateShortInfoList
    """
    sb=''
    sb+='<GetAbstractTemplateList>\n'
    sb+='</GetAbstractTemplateList>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetAbstractTemplateList')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetActiveTopologyNames(self ) :
    """
    Retrieves all active reserved topologies for the current (logged in) user.
    :rtype: TopologyListInfo
    """
    sb=''
    sb+='<GetActiveTopologyNames>\n'
    sb+='</GetActiveTopologyNames>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetActiveTopologyNames')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetAllUsersDetails(self ) :
    """
    Retrieves all users and their settings.
    :rtype: UsersInfo
    """
    sb=''
    sb+='<GetAllUsersDetails>\n'
    sb+='</GetAllUsersDetails>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetAllUsersDetails')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetAttributeValue(self , resourceFullPath , attributeName ) :
    """
    Retrieves the value of the specified attribute
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str attributeName:  Attribute Name - Specify the attribute name.
    :rtype: AttributeValueInfo
    """
    sb=''
    sb+='<GetAttributeValue>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <attributeName>'+nonnull(attributeName)+'</attributeName>\n'
    sb+='</GetAttributeValue>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetAttributeValue')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetCategoriesOfTopology(self , topologyPath ) :
    """
    Retrieves all categories of given topology.
    :param str topologyPath:  Topology Full Path - Specify the topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: CategoriesOfTopologyInfo
    """
    sb=''
    sb+='<GetCategoriesOfTopology>\n'
    sb+='    <topologyPath>'+nonnull(topologyPath)+'</topologyPath>\n'
    sb+='</GetCategoriesOfTopology>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetCategoriesOfTopology')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetCurrentReservations(self , reservationOwner = "") :
    """
    Retrieves current reservations for the specified owner. If an owner is not provided, this method retrieves all current reservations.
    :param str reservationOwner:  Reservation Owner - Specify the user name of the reservation owner.
    :rtype: GetActiveReservationsResponseInfo
    """
    sb=''
    sb+='<GetCurrentReservations>\n'
    sb+='    <reservationOwner>'+nonnull(reservationOwner)+'</reservationOwner>\n'
    sb+='</GetCurrentReservations>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetCurrentReservations')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetDomainDetails(self , domainName ) :
    """
    Retrieves a domain's details including groups, topologies and resources associated with the specified domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :rtype: DomainInfo
    """
    sb=''
    sb+='<GetDomainDetails>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='</GetDomainDetails>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetDomainDetails')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetFolderContent(self , fullPath = "", showAllDomains = False) :
    """
    Retrieves content for the specified path.
    :param str fullPath:  Folder Full Path - Specify the full folder name. Include the full path from the root to a specific folder, separated by slashes. For example: ResourceFamilyFolder/ResourceModelFolder.
    :param bool showAllDomains:  Show All Domains - Show all domains associated with the logged in user.
    :rtype: ContentListInfo
    """
    sb=''
    sb+='<GetFolderContent>\n'
    sb+='    <fullPath>'+nonnull(fullPath)+'</fullPath>\n'
    if showAllDomains is None:
      showAllDomains=False
    sb+='    <showAllDomains>'+nonnull(showAllDomains)+'</showAllDomains>\n'
    sb+='</GetFolderContent>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetFolderContent')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetGroupDomains(self , groupName ) :
    """
    Retrieves all domains associated with a group.
    :param str groupName:  Group Name - Specify the name of the group.
    :rtype: GroupInfo
    """
    sb=''
    sb+='<GetGroupDomains>\n'
    sb+='    <groupName>'+nonnull(groupName)+'</groupName>\n'
    sb+='</GetGroupDomains>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetGroupDomains')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetGroupsDetails(self ) :
    """
    Retrieves all groups, including members, roles and associated domains for each group.
    :rtype: GroupsInfo
    """
    sb=''
    sb+='<GetGroupsDetails>\n'
    sb+='</GetGroupsDetails>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetGroupsDetails')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetLockedResources(self , user = "", machine = "", folderFullPath = "") :
    """
    Retrieves locked resources for a specific user, a specific computer, or a specific folder. If none of these are specified, this method retrieves the list of locked resources for all users, on all machines, in all folders.
    :param str user:  Username - Specify a user name to retrieve locked resources for that user.
    :param str machine:  Machine Name - Specify a machine name to retrieve locked resources for that computer.
    :param str folderFullPath:  Folder Full Path - Specify the full folder name. Include the full path from the root to a specific folder, separated by slashes. For example: ResourceFamilyFolder/ResourceModelFolder.
    :rtype: ReservationInfo
    """
    sb=''
    sb+='<GetLockedResources>\n'
    sb+='    <user>'+nonnull(user)+'</user>\n'
    sb+='    <machine>'+nonnull(machine)+'</machine>\n'
    sb+='    <folderFullPath>'+nonnull(folderFullPath)+'</folderFullPath>\n'
    sb+='</GetLockedResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetLockedResources')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetReservationDetails(self , reservationId ) :
    """
    Retrieves all details and parameters for a specified reservation, including its resources, routes and route segments, topologies, and reservation conflicts.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: GetReservationDescriptionResponseInfo
    """
    sb=''
    sb+='<GetReservationDetails>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</GetReservationDetails>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetReservationDetails')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetReservationInputs(self , reservationId ) :
    """
    Retrieves all topology inputs for a specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: GetReservationInputsResponseInfo
    """
    sb=''
    sb+='<GetReservationInputs>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</GetReservationInputs>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetReservationInputs')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetReservationRemainingTime(self , reservationId ) :
    """
    Retrieves the number of minutes remaining until the end of a specified reservation. If the reservation is running overtime, the remaining time will be reported as -1 minutes.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: GetReservationRemainingTimeInfo
    """
    sb=''
    sb+='<GetReservationRemainingTime>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</GetReservationRemainingTime>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetReservationRemainingTime')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetReservationResourcesPositions(self , reservationId ) :
    """
    Retrieves the x/y coordinates for all resources in the reservation's diagram.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: ReservationDiagramLayoutResponseInfo
    """
    sb=''
    sb+='<GetReservationResourcesPositions>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</GetReservationResourcesPositions>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetReservationResourcesPositions')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetReservationServicesPositions(self , reservationId ) :
    """
    Retrieves the x/y coordinates for all services in the reservation's diagram.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: ReservationDiagramLayoutResponseInfo
    """
    sb=''
    sb+='<GetReservationServicesPositions>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</GetReservationServicesPositions>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetReservationServicesPositions')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetReservationsLiveStatus(self , reservationsId = []) :
    """
    Gets the live status of the reservations.
    :param list[str] reservationsId:  Reservations IDs - Specifies the string that represents the reservation’s unique identifier.
    :rtype: ReservationLiveStatusInfo
    """
    sb=''
    sb+='<GetReservationsLiveStatus>\n'
    sb+='    <reservationsId>\n'
    if reservationsId is not None:
      for x in reservationsId:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </reservationsId>\n'
    sb+='</GetReservationsLiveStatus>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetReservationsLiveStatus')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceAvailability(self , resourcesNames , showAllDomains = False) :
    """
    Get resource availability for the resources.
    :param list[str] resourcesNames:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param bool showAllDomains:  Show All Domains - Show all domains associated with the logged in user.
    :rtype: FindResourceListInfo
    """
    sb=''
    sb+='<GetResourceAvailability>\n'
    sb+='    <resourcesNames>\n'
    if resourcesNames is not None:
      for x in resourcesNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesNames>\n'
    if showAllDomains is None:
      showAllDomains=False
    sb+='    <showAllDomains>'+nonnull(showAllDomains)+'</showAllDomains>\n'
    sb+='</GetResourceAvailability>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceAvailability')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceAvailabilityInTimeRange(self , resourcesNames , startTime , endTime , showAllDomains = False) :
    """
    Get resource availability for the resources in the specified time range.
    :param list[str] resourcesNames:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param Date startTime:  Start Time - The start time of the reservation.
    :param Date endTime:  End Time - The end time of the reservation.
    :param bool showAllDomains:  Show All Domains - Show all domains associated with the logged in user.
    :rtype: FindResourceListInfo
    """
    sb=''
    sb+='<GetResourceAvailabilityInTimeRange>\n'
    sb+='    <resourcesNames>\n'
    if resourcesNames is not None:
      for x in resourcesNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesNames>\n'
    sb+='    <startTime>'+nonnull(startTime)+'</startTime>\n'
    sb+='    <endTime>'+nonnull(endTime)+'</endTime>\n'
    if showAllDomains is None:
      showAllDomains=False
    sb+='    <showAllDomains>'+nonnull(showAllDomains)+'</showAllDomains>\n'
    sb+='</GetResourceAvailabilityInTimeRange>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceAvailabilityInTimeRange')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceCommands(self , resourceFullPath ) :
    """
    Retrieves driver commands and parameters for a specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: ResourceCommandListInfo
    """
    sb=''
    sb+='<GetResourceCommands>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</GetResourceCommands>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceCommands')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceConnectedCommands(self , resourceFullPath ) :
    """
    Gets commands which are added to the resource from connected resources such as power or virtualization.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: ResourceCommandListInfo
    """
    sb=''
    sb+='<GetResourceConnectedCommands>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</GetResourceConnectedCommands>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceConnectedCommands')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceDetails(self , resourceFullPath , showAllDomains = False) :
    """
    Retrieves resource descriptions for the specified resource, and a matrix of all its associated attributes and attribute values.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param bool showAllDomains:  Show All Domains - Show all domains associated with the logged in user.
    :rtype: ResourceInfo
    """
    sb=''
    sb+='<GetResourceDetails>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    if showAllDomains is None:
      showAllDomains=False
    sb+='    <showAllDomains>'+nonnull(showAllDomains)+'</showAllDomains>\n'
    sb+='</GetResourceDetails>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceDetails')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceList(self , folderFullPath = "") :
    """
    Retrieves resources and resource values for the specified folder path.
    :param str folderFullPath:  Folder Full Path - Specify the full folder name. Include the full path from the root to a specific folder, separated by slashes. For example: ResourceFamilyFolder/ResourceModelFolder.
    :rtype: ResourceListInfo
    """
    sb=''
    sb+='<GetResourceList>\n'
    sb+='    <folderFullPath>'+nonnull(folderFullPath)+'</folderFullPath>\n'
    sb+='</GetResourceList>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceList')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceLiveStatus(self , resourceFullPath ) :
    """
    Gets the live status of the resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA.
    :rtype: ResourceLiveStatusInfo
    """
    sb=''
    sb+='<GetResourceLiveStatus>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</GetResourceLiveStatus>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceLiveStatus')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetResourceMappings(self , resources ) :
    """
    Retrieves mappings for a list of one or more resources.
    :param list[str] resources:  Resource Names - Specify a list of resources.
    :rtype: ResourceMappingsInfo
    """
    sb=''
    sb+='<GetResourceMappings>\n'
    sb+='    <resources>\n'
    if resources is not None:
      for x in resources:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resources>\n'
    sb+='</GetResourceMappings>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetResourceMappings')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetRouteSegments(self , resource ) :
    """
    Retrieves all the ports on the route from the selected endpoint to the target endpoint.
    :param str resource:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<GetRouteSegments>\n'
    sb+='    <resource>'+nonnull(resource)+'</resource>\n'
    sb+='</GetRouteSegments>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetRouteSegments')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetRoutesSolution(self , reservationId , sourceResourcesFullPath , targetResourcesFullPath , mappingType , maxHops , isShared ) :
    """
    Calculates possible routes between the supplied endpoints and returns their details, without saving, connecting or modifying the reservation in any way.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] sourceResourcesFullPath:  Resources Full Name - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: RootResourceName/ResourceName
    :param list[str] targetResourcesFullPath:  Resources Full Name - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: RootResourceName/ResourceName
    :param MappingType mappingType:  Mapping Type - Specify bidirectional or unidirectional as the mapping type.
    :param int maxHops:  Maximum Hops - Specify the maximum number or allowed hops.
    :param bool isShared:  Is Shared - Specify whether these routes are shared. Shared routes can be used in more than one reservation.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<GetRoutesSolution>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <sourceResourcesFullPath>\n'
    if sourceResourcesFullPath is not None:
      for x in sourceResourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </sourceResourcesFullPath>\n'
    sb+='    <targetResourcesFullPath>\n'
    if targetResourcesFullPath is not None:
      for x in targetResourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </targetResourcesFullPath>\n'
    sb+='    <mappingType>'+nonnull(mappingType)+'</mappingType>\n'
    sb+='    <maxHops>'+nonnull(maxHops)+'</maxHops>\n'
    sb+='    <isShared>'+nonnull(isShared)+'</isShared>\n'
    sb+='</GetRoutesSolution>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetRoutesSolution')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetScheduledReservations(self , fromTime , untilTime ) :
    """
    Retrieves all reservations scheduled between the specified start and end times.
    :param Date fromTime:  From Date Time - Specify from which time and date to search.
    :param Date untilTime:  Until Date Time - Specify until which time and date to search.
    :rtype: GetReservationsInRangeResponseInfo
    """
    sb=''
    sb+='<GetScheduledReservations>\n'
    sb+='    <fromTime>'+nonnull(fromTime)+'</fromTime>\n'
    sb+='    <untilTime>'+nonnull(untilTime)+'</untilTime>\n'
    sb+='</GetScheduledReservations>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetScheduledReservations')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetServerDateAndTime(self ) :
    """
    Retrieves the server’s UTC date and time.
    :rtype: ServerTimeInfo
    """
    sb=''
    sb+='<GetServerDateAndTime>\n'
    sb+='</GetServerDateAndTime>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetServerDateAndTime')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetServiceCommands(self , serviceName ) :
    """
    Retrieves driver commands and parameters for a specified service.
    :param str serviceName:  Service Name - Specify the service name. 
    :rtype: ResourceCommandListInfo
    """
    sb=''
    sb+='<GetServiceCommands>\n'
    sb+='    <serviceName>'+nonnull(serviceName)+'</serviceName>\n'
    sb+='</GetServiceCommands>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetServiceCommands')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetServices(self , categoryName = "", serviceName = "") :
    """
    Retrieve a list of services and their attributes.
    :param str categoryName:  Category Name - The name of the category of the services you want to receive.
    :param str serviceName:  Service Name - The name of the service you want to receive.
    :rtype: ServicesListInfo
    """
    sb=''
    sb+='<GetServices>\n'
    sb+='    <categoryName>'+nonnull(categoryName)+'</categoryName>\n'
    sb+='    <serviceName>'+nonnull(serviceName)+'</serviceName>\n'
    sb+='</GetServices>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetServices')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetTopologiesByCategory(self , categoryName , categoryValue = "") :
    """
    Retrives full topology path for each topology that contains given category name (and value if entered).
    :param str categoryName:  Category Name - Specify the category's name
    :param str categoryValue:  Category Value - Specify the category's value/sub category
    :rtype: TopologiesByCategoryInfo
    """
    sb=''
    sb+='<GetTopologiesByCategory>\n'
    sb+='    <categoryName>'+nonnull(categoryName)+'</categoryName>\n'
    sb+='    <categoryValue>'+nonnull(categoryValue)+'</categoryValue>\n'
    sb+='</GetTopologiesByCategory>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetTopologiesByCategory')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetTopologyCategories(self ) :
    """
    Retrieves all root categories from 'Environment' catalog.
    :rtype: CategoryListInfo
    """
    sb=''
    sb+='<GetTopologyCategories>\n'
    sb+='</GetTopologyCategories>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetTopologyCategories')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetTopologyCommands(self , reservationId ) :
    """
    Retrieves driver commands and parameters for a specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: TopologyCommandListInfo
    """
    sb=''
    sb+='<GetTopologyCommands>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</GetTopologyCommands>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetTopologyCommands')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetTopologyDetails(self , topologyFullPath ) :
    """
    Retrieves all resources and attributes associated with the specified topology.
    :param str topologyFullPath:  Topology Full Path - Specify the full topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: TopologyInfo
    """
    sb=''
    sb+='<GetTopologyDetails>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='</GetTopologyDetails>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetTopologyDetails')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def GetUserDetails(self , username ) :
    """
    Retrieves the specified user's configuration settings and associated domains.
    :param str username:  Username - Specify the name of the user.
    :rtype: UserInfo
    """
    sb=''
    sb+='<GetUserDetails>\n'
    sb+='    <username>'+nonnull(username)+'</username>\n'
    sb+='</GetUserDetails>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'GetUserDetails')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def IncludeResource(self , resourceFullPath ) :
    """
    Includes a specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<IncludeResource>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</IncludeResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'IncludeResource')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def IncludeResources(self , resourcesFullPath ) :
    """
    Includes the specified resources.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :rtype: str
    """
    sb=''
    sb+='<IncludeResources>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='</IncludeResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'IncludeResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def LockResource(self , reservationId , resourceFullPath ) :
    """
    Locks a specified resource.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<LockResource>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</LockResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'LockResource')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def LockResources(self , reservationId , resourcesFullPath ) :
    """
    Locks multiple resources.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :rtype: str
    """
    sb=''
    sb+='<LockResources>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='</LockResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'LockResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def Logoff(self ) :
    """
    Logs out the current user.
    :rtype: str
    """
    sb=''
    sb+='<Logoff>\n'
    sb+='</Logoff>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'Logoff')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def Logon(self , username = "", password = "", domainName = "Global") :
    """
    Logs in a user. If no user is specified, this method logs in the current user. If no domain is specified, this method logs the user in to the global (default) domain.
    :param str username:  Username - Username to logon with.
    :param str password:  Password - Specify the user’s login password.
    :param str domainName:  Domain Name - Specify the name of the domain. If no domain is specified, it logs the user in to the global (default) domain.
    :rtype: LogonResponseInfo
    """
    sb=''
    sb+='<Logon>\n'
    sb+='    <username>'+nonnull(username)+'</username>\n'
    sb+='    <password>'+nonnull(password)+'</password>\n'
    if domainName is None:
      domainName="Global"
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='</Logon>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'Logon')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def LogoutTNSession(self , reservationId , resourceFullPath , consolePortsFullPath , baudRate ) :
    """
    Logs the user out from a console port TN session.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param list[str] consolePortsFullPath:  Console Ports - Specify a list of console ports according to their location in the Resource Explorer. Include the full path from the root to each console port, separated by slashes. For example: Console/Ports/PortName.
    :param int baudRate:  Baud Rate - Specify the baud rate to apply to the ports.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<LogoutTNSession>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <consolePortsFullPath>\n'
    if consolePortsFullPath is not None:
      for x in consolePortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </consolePortsFullPath>\n'
    sb+='    <baudRate>'+nonnull(baudRate)+'</baudRate>\n'
    sb+='</LogoutTNSession>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'LogoutTNSession')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def MapPorts(self , sourcePort , destinationPort , mappingType ) :
    """
    Maps a pair of ports on a physical (L1) switch.
    :param str sourcePort:  Source Port - Specify the source port.
    :param str destinationPort:  Destination Port - Specify the destination port.
    :param MappingType mappingType:  Mapping Type - Specify bidirectional or unidirectional as the mapping type.
    :rtype: str
    """
    sb=''
    sb+='<MapPorts>\n'
    sb+='    <sourcePort>'+nonnull(sourcePort)+'</sourcePort>\n'
    sb+='    <destinationPort>'+nonnull(destinationPort)+'</destinationPort>\n'
    sb+='    <mappingType>'+nonnull(mappingType)+'</mappingType>\n'
    sb+='</MapPorts>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'MapPorts')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def PowerCycleResource(self , resourceFullPath , delay , reservationId = "", powerPortsFullPath = []) :
    """
    Cycles the power options for resource power ports.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param double delay:  Delay - Specify the number of seconds to delay between each power cycle.
    :param str reservationId:  Reservation ID - Specify the reservation’s unique identifier. Admin users may leave this parameter blank to perform power operations on excluded resources.
    :param list[str] powerPortsFullPath:  Power Ports - Specify the list of power ports to use in this operation. Include the full path from the root resource to each power port, separated by slashes. For example: Switch20/Blade5/PowerPort1. Leave blank to perform the power operation on all of the specified resource’s power ports.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<PowerCycleResource>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <powerPortsFullPath>\n'
    if powerPortsFullPath is not None:
      for x in powerPortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </powerPortsFullPath>\n'
    sb+='    <delay>'+nonnull(delay)+'</delay>\n'
    sb+='</PowerCycleResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'PowerCycleResource')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def PowerOffResource(self , resourceFullPath , reservationId = "", powerPortsFullPath = []) :
    """
    Powers off specified power ports.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str reservationId:  Reservation ID - Specify the reservation’s unique identifier. Admin users may leave this parameter blank to perform power operations on excluded resources.
    :param list[str] powerPortsFullPath:  Power Ports - Specify the list of power ports to use in this operation. Include the full path from the root resource to each power port, separated by slashes. For example: Switch20/Blade5/PowerPort1. Leave blank to perform the power operation on all of the specified resource’s power ports.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<PowerOffResource>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <powerPortsFullPath>\n'
    if powerPortsFullPath is not None:
      for x in powerPortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </powerPortsFullPath>\n'
    sb+='</PowerOffResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'PowerOffResource')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def PowerOnResource(self , resourceFullPath , reservationId = "", powerPortsFullPath = []) :
    """
    Powers on resource power ports.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str reservationId:  Reservation ID - Specify the reservation’s unique identifier. Admin users may leave this parameter blank to perform power operations on excluded resources.
    :param list[str] powerPortsFullPath:  Power Ports - Specify the list of power ports to use in this operation. Include the full path from the root resource to each power port, separated by slashes. For example: Switch20/Blade5/PowerPort1. Leave blank to perform the power operation on all of the specified resource’s power ports.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<PowerOnResource>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <powerPortsFullPath>\n'
    if powerPortsFullPath is not None:
      for x in powerPortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </powerPortsFullPath>\n'
    sb+='</PowerOnResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'PowerOnResource')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def RecheckConflicts(self , reservationId ) :
    """
    Updates the list of available resources for a reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: str
    """
    sb=''
    sb+='<RecheckConflicts>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</RecheckConflicts>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RecheckConflicts')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ReleaseResourcesFromReservation(self , reservationId , resourcesFullPath ) :
    """
    Releases occupied testing resources that would not otherwise be available until the end of the current reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<ReleaseResourcesFromReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='</ReleaseResourcesFromReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ReleaseResourcesFromReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ReleaseTopologyResources(self , reservationId , topologyFullPath ) :
    """
    Releases resources used in topology. A reservation will not end until all used resources are released.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str topologyFullPath:  Topology Full Path - Specify the full topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: str
    """
    sb=''
    sb+='<ReleaseTopologyResources>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='</ReleaseTopologyResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ReleaseTopologyResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ReloadTopology(self , reservationId , topologyFullPath ) :
    """
    Removes and adds the specified topology back to the reservation, after re-evaluating it and all its resources.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str topologyFullPath:  Topology Full Path - Specify the full topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: ReserveTopologyResponseInfo
    """
    sb=''
    sb+='<ReloadTopology>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='</ReloadTopology>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ReloadTopology')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def RemoveConnectorsFromReservation(self , reservationId , endpoints ) :
    """
    Removes the mapped connector between given end points.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] endpoints:  Endpoints - The list of removed endpoints.
    :rtype: str
    """
    sb=''
    sb+='<RemoveConnectorsFromReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <endpoints>\n'
    if endpoints is not None:
      for x in endpoints:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </endpoints>\n'
    sb+='</RemoveConnectorsFromReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveConnectorsFromReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RemoveGroupsFromDomain(self , domainName , groupNames ) :
    """
    Remove groups from a domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param list[str] groupNames:  Groups Names - Specify an array of one or more groups.
    :rtype: str
    """
    sb=''
    sb+='<RemoveGroupsFromDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <groupNames>\n'
    if groupNames is not None:
      for x in groupNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </groupNames>\n'
    sb+='</RemoveGroupsFromDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveGroupsFromDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RemovePermittedUsersFromReservation(self , reservationId = "", usernames = []) :
    """
    Remove one or more permitted users from the specified reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] usernames:  User Names - List of permitted users to remove from the reservation.
    :rtype: str
    """
    sb=''
    sb+='<RemovePermittedUsersFromReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <usernames>\n'
    if usernames is not None:
      for x in usernames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </usernames>\n'
    sb+='</RemovePermittedUsersFromReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemovePermittedUsersFromReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RemoveResourcesFromDomain(self , domainName , resourcesNames ) :
    """
    Remove resources from a domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param list[str] resourcesNames:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :rtype: str
    """
    sb=''
    sb+='<RemoveResourcesFromDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <resourcesNames>\n'
    if resourcesNames is not None:
      for x in resourcesNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesNames>\n'
    sb+='</RemoveResourcesFromDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveResourcesFromDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RemoveResourcesFromReservation(self , reservationId , resourcesFullPath ) :
    """
    Unlocks and removes resources from a reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :rtype: ReserveResourcesResponseInfo
    """
    sb=''
    sb+='<RemoveResourcesFromReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='</RemoveResourcesFromReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveResourcesFromReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def RemoveRoutesFromReservation(self , reservationId , endpoints , mappingType ) :
    """
    Disconnects a list of endpoints and removes the mapped route between them. Will only disconnect endpoints using resources reserved to the logged-in user .
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] endpoints:  Endpoints - The list of removed endpoints.
    :param MappingType mappingType:  Mapping Type - Specify bidirectional or unidirectional as the mapping type.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<RemoveRoutesFromReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <endpoints>\n'
    if endpoints is not None:
      for x in endpoints:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </endpoints>\n'
    sb+='    <mappingType>'+nonnull(mappingType)+'</mappingType>\n'
    sb+='</RemoveRoutesFromReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveRoutesFromReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def RemoveServicesFromReservation(self , reservationId , services ) :
    """
    Remove services and apps from existing reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] services:  List of aliases - List of aliases. This list should contain the aliases for both the services and apps that should be removed.
    :rtype: str
    """
    sb=''
    sb+='<RemoveServicesFromReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <services>\n'
    if services is not None:
      for x in services:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </services>\n'
    sb+='</RemoveServicesFromReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveServicesFromReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RemoveTopologiesFromDomain(self , domainName , topologyNames ) :
    """
    Removes a list of one or more topologies from a domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param list[str] topologyNames:  Topologies Full Path - Specify a list of topology names. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: str
    """
    sb=''
    sb+='<RemoveTopologiesFromDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <topologyNames>\n'
    if topologyNames is not None:
      for x in topologyNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </topologyNames>\n'
    sb+='</RemoveTopologiesFromDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveTopologiesFromDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RemoveTopologyCategory(self , topologyFullPath , categoryName ) :
    """
    Removes a category from given topology.
    :param str topologyFullPath:  Topology Full Path - Specify the topology we want to remove the given category from.
    :param str categoryName:  Category Name - Specify the category's name which we want to remove.
    :rtype: str
    """
    sb=''
    sb+='<RemoveTopologyCategory>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='    <categoryName>'+nonnull(categoryName)+'</categoryName>\n'
    sb+='</RemoveTopologyCategory>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveTopologyCategory')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RemoveUsersFromGroup(self , usernames , groupName ) :
    """
    Removes a list of one or more users from the specified group.
    :param list[str] usernames:  Usernames - Specify an array of one or more users.
    :param str groupName:  Group Name - Specify the name of the group.
    :rtype: str
    """
    sb=''
    sb+='<RemoveUsersFromGroup>\n'
    sb+='    <usernames>\n'
    if usernames is not None:
      for x in usernames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </usernames>\n'
    sb+='    <groupName>'+nonnull(groupName)+'</groupName>\n'
    sb+='</RemoveUsersFromGroup>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RemoveUsersFromGroup')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def RenameResource(self , resourceFullPath , resourceName ) :
    """
    Renames the specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str resourceName:  Resource Name - Specify a new resource name.
    :rtype: str
    """
    sb=''
    sb+='<RenameResource>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <resourceName>'+nonnull(resourceName)+'</resourceName>\n'
    sb+='</RenameResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'RenameResource')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def ResetResourceDriver(self , reservationId , resourceFullPath ) :
    """
    Cancel the currently executing command, remove all pending command executions and reset the driver to its initial state.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<ResetResourceDriver>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</ResetResourceDriver>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'ResetResourceDriver')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def SaveReservationAsTopology(self , reservationId , topologyName , includeInactiveRoutes , folderFullPath = "") :
    """
    Creates a topology from an existing reservation. Leave the folder path blank to save the topology directly under the root.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str topologyName:  Topology Name - Specify the new name for the new topology.
    :param bool includeInactiveRoutes:  Include Inactive Routes - Include disconnected routes in the created topology
    :param str folderFullPath:  Folder Full Path - Full container folder path where the new topology will be saved. leaving the folder path empty will try saving the topology under the root.  For example: FolderName/FolderNameA.
    :rtype: TopologyInfo
    """
    sb=''
    sb+='<SaveReservationAsTopology>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <folderFullPath>'+nonnull(folderFullPath)+'</folderFullPath>\n'
    sb+='    <topologyName>'+nonnull(topologyName)+'</topologyName>\n'
    sb+='    <includeInactiveRoutes>'+nonnull(includeInactiveRoutes)+'</includeInactiveRoutes>\n'
    sb+='</SaveReservationAsTopology>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SaveReservationAsTopology')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def SetAttributeValue(self , resourceFullPath , attributeName , attributeValue = "") :
    """
    Sets the value of the specified attribute.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str attributeName:  Attribute Name - Specify the attribute name.
    :param str attributeValue:  Attribute Value - Specify the attribute’s value.
    :rtype: str
    """
    sb=''
    sb+='<SetAttributeValue>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <attributeName>'+nonnull(attributeName)+'</attributeName>\n'
    sb+='    <attributeValue>'+nonnull(attributeValue)+'</attributeValue>\n'
    sb+='</SetAttributeValue>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetAttributeValue')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetAttributesValues(self , resourcesAttributesUpdateRequests ) :
    """
    Sets new attribute values for the specified resources.
    :param list[ResourceAttributesUpdateRequest] resourcesAttributesUpdateRequests:  Resources, Attributes, and Values - Specify a matrix of resources, attribute names, and new attribute values (up to 10000 rows). For example: {['ResourceFullName', 'AttributeName','AttributeValue';'ResourceFullName2', 'AttributeName2','AttributeValue2']}.
    :rtype: str
    """
    sb=''
    sb+='<SetAttributesValues>\n'
    sb+='    <resourcesAttributesUpdateRequests>\n'
    if resourcesAttributesUpdateRequests is not None:
        for x in resourcesAttributesUpdateRequests:
            sb+='        <ResourceAttributesUpdateRequest>\n'
            sb+='            <ResourceFullName>'+nonnull(x.ResourceFullName)+'</ResourceFullName>\n'
            sb+='            <AttributeNamesValues>\n'
            for y in x.AttributeNamesValues:
                sb+='            <AttributeNameValue>\n'
                sb+='                <Name>'+nonnull(y.Name)+'</Name>\n'
                sb+='                <Value>'+nonnull(y.Value)+'</Value>\n'
                sb+='            </AttributeNameValue>\n'
            sb+='            </AttributeNamesValues>\n'
            sb+='        </ResourceAttributesUpdateRequest>\n'
    sb+='    </resourcesAttributesUpdateRequests>\n'
    sb+='</SetAttributesValues>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetAttributesValues')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetBaudRate(self , reservationId , resourceFullPath , consolePortsFullPath , baudRate ) :
    """
    Sets the baud rate for one or more console ports.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param list[str] consolePortsFullPath:  Console Ports - Specify a list of console ports according to their location in the Resource Explorer. Include the full path from the root to each console port, separated by slashes. For example: Console/Ports/PortName.
    :param int baudRate:  Baud Rate - Specify the baud rate to apply to the ports.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<SetBaudRate>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <consolePortsFullPath>\n'
    if consolePortsFullPath is not None:
      for x in consolePortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </consolePortsFullPath>\n'
    sb+='    <baudRate>'+nonnull(baudRate)+'</baudRate>\n'
    sb+='</SetBaudRate>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetBaudRate')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def SetConnectorAttributes(self , reservationId , sourceResourceFullName , targetResourceFullName , attributeRequests ) :
    """
    Sets attributes and associated values for a specified connector.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str sourceResourceFullName:  Source Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str targetResourceFullName:  Target Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param list[AttributeNameValue] attributeRequests:  Attribute Requests - Specify a matrix of attributes and associated attribute values.
    :rtype: str
    """
    sb=''
    sb+='<SetConnectorAttributes>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <sourceResourceFullName>'+nonnull(sourceResourceFullName)+'</sourceResourceFullName>\n'
    sb+='    <targetResourceFullName>'+nonnull(targetResourceFullName)+'</targetResourceFullName>\n'
    sb+='    <attributeRequests>\n'
    if attributeRequests is not None:
        for x in attributeRequests:
            sb+='        <AttributeNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </AttributeNameValue>\n'
    sb+='    </attributeRequests>\n'
    sb+='</SetConnectorAttributes>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetConnectorAttributes')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetConnectorAttributesViaAlias(self , reservationId , connectorAlias , attributeRequests ) :
    """
    Sets attributes and associated values for a connector specified via its alias.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str connectorAlias:  Connector Alias - Specify the connector’s alias.
    :param list[AttributeNameValue] attributeRequests:  Attribute Requests - Specify a matrix of attributes and associated attribute values.
    :rtype: str
    """
    sb=''
    sb+='<SetConnectorAttributesViaAlias>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <connectorAlias>'+nonnull(connectorAlias)+'</connectorAlias>\n'
    sb+='    <attributeRequests>\n'
    if attributeRequests is not None:
        for x in attributeRequests:
            sb+='        <AttributeNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </AttributeNameValue>\n'
    sb+='    </attributeRequests>\n'
    sb+='</SetConnectorAttributesViaAlias>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetConnectorAttributesViaAlias')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetConnectorsInReservation(self , reservationId , connectors ) :
    """
    Adds connectors between source and target or update existing ones.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[SetConnectorRequest] connectors:  Connectors - List of connectors to set in the reservation. For example: {['SourceResourceFullPath', 'TargetResourceFullPath', 'Direction', 'Alias';]}.
    :rtype: str
    """
    sb=''
    sb+='<SetConnectorsInReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <connectors>\n'
    if connectors is not None:
        for x in connectors:
            sb+='        <SetConnectorRequest>\n'
            sb+='            <SourceResourceFullName>'+nonnull(x.SourceResourceFullName)+'</SourceResourceFullName>\n'
            sb+='            <TargetResourceFullName>'+nonnull(x.TargetResourceFullName)+'</TargetResourceFullName>\n'
            sb+='            <Direction>'+nonnull(x.Direction)+'</Direction>\n'
            sb+='            <Alias>'+nonnull(x.Alias)+'</Alias>\n'
            sb+='        </SetConnectorRequest>\n'
    sb+='    </connectors>\n'
    sb+='</SetConnectorsInReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetConnectorsInReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetConsoleForXModem(self , reservationId , resourceFullPath , consolePortsFullPath , baudRate ) :
    """
    Sets one or more consoles for Xmodem.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param list[str] consolePortsFullPath:  Console Ports - Specify a list of console ports according to their location in the Resource Explorer. Include the full path from the root to each console port, separated by slashes. For example: Console/Ports/PortName.
    :param int baudRate:  Baud Rate - Specify the baud rate to apply to the ports.
    :rtype: CommandExecutionCompletedResultInfo
    """
    sb=''
    sb+='<SetConsoleForXModem>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <consolePortsFullPath>\n'
    if consolePortsFullPath is not None:
      for x in consolePortsFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </consolePortsFullPath>\n'
    sb+='    <baudRate>'+nonnull(baudRate)+'</baudRate>\n'
    sb+='</SetConsoleForXModem>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetConsoleForXModem')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def SetGroupDomainPermissions(self , domainName , groupName , viewOnly = False) :
    """
    Set the permission level of a group in domain.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param str groupName:  Groups Name - Specify the group name.
    :param bool viewOnly:  View Only - Specify if the group should be have view only permissions.
    :rtype: str
    """
    sb=''
    sb+='<SetGroupDomainPermissions>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <groupName>'+nonnull(groupName)+'</groupName>\n'
    if viewOnly is None:
      viewOnly=False
    sb+='    <viewOnly>'+nonnull(viewOnly)+'</viewOnly>\n'
    sb+='</SetGroupDomainPermissions>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetGroupDomainPermissions')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetReservationLiveStatus(self , reservationId , liveStatusName , additionalInfo ) :
    """
    Sets the live status of the reservation
    :param str reservationId:  Reservation id  - Specifies the string that represents the reservation’s unique identifier.
    :param str liveStatusName:  Live Status Name - Reservation live status name
    :param str additionalInfo:  Additional Info - Reservation live status additional info
    :rtype: str
    """
    sb=''
    sb+='<SetReservationLiveStatus>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <liveStatusName>'+nonnull(liveStatusName)+'</liveStatusName>\n'
    sb+='    <additionalInfo>'+nonnull(additionalInfo)+'</additionalInfo>\n'
    sb+='</SetReservationLiveStatus>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetReservationLiveStatus')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetReservationResourcePosition(self , reservationId , resourceFullName = "", x = "", y = "") :
    """
    Sets the location of a specified resource in the reservation diagram.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullName:  Resource Full Name - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName.
    :param double x:  x - Specify the x coordinate of the resource's top left corner.
    :param double y:  y - Specify the y coordinate of the resource's top left corner.
    :rtype: str
    """
    sb=''
    sb+='<SetReservationResourcePosition>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullName>'+nonnull(resourceFullName)+'</resourceFullName>\n'
    sb+='    <x>'+nonnull(x)+'</x>\n'
    sb+='    <y>'+nonnull(y)+'</y>\n'
    sb+='</SetReservationResourcePosition>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetReservationResourcePosition')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetReservationServicePosition(self , reservationId , serviceAlias = "", x = "", y = "") :
    """
    Sets the location of a specified service in the reservation diagram.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str serviceAlias:  Service Alias - Specify the alias of the service.
    :param double x:  x - Specify the x coordinate of the resource's top left corner.
    :param double y:  y - Specify the y coordinate of the resource's top left corner.
    :rtype: str
    """
    sb=''
    sb+='<SetReservationServicePosition>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <serviceAlias>'+nonnull(serviceAlias)+'</serviceAlias>\n'
    sb+='    <x>'+nonnull(x)+'</x>\n'
    sb+='    <y>'+nonnull(y)+'</y>\n'
    sb+='</SetReservationServicePosition>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetReservationServicePosition')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetResourceLiveStatus(self , resourceFullName , liveStatusName = "", additionalInfo = "") :
    """
    Sets the live status of the resource
    :param str resourceFullName:  Resource Full Path  - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA.
    :param str liveStatusName:  Live Status Name - Resource live status name
    :param str additionalInfo:  Additional Info - Resource live status additional info
    :rtype: str
    """
    sb=''
    sb+='<SetResourceLiveStatus>\n'
    sb+='    <resourceFullName>'+nonnull(resourceFullName)+'</resourceFullName>\n'
    sb+='    <liveStatusName>'+nonnull(liveStatusName)+'</liveStatusName>\n'
    sb+='    <additionalInfo>'+nonnull(additionalInfo)+'</additionalInfo>\n'
    sb+='</SetResourceLiveStatus>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetResourceLiveStatus')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetResourceSharedState(self , reservationId , resourcesFullName , isShared ) :
    """
    Sets the resource sharing state.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] resourcesFullName:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :param bool isShared:  Is Shared - Specify whether to allow sharing of the resource.
    :rtype: str
    """
    sb=''
    sb+='<SetResourceSharedState>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourcesFullName>\n'
    if resourcesFullName is not None:
      for x in resourcesFullName:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullName>\n'
    sb+='    <isShared>'+nonnull(isShared)+'</isShared>\n'
    sb+='</SetResourceSharedState>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetResourceSharedState')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetRouteAttributes(self , reservationId , sourceResourceFullPath , targetResourceFullPath , applyChangesTo , attributeRequests ) :
    """
    Sets attributes and associated values for a specified route.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str sourceResourceFullPath:  Source Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str targetResourceFullPath:  Target Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param RouteAttributesChangeTarget applyChangesTo:  Apply Changes To - Specify on which resources to apply the attribute changes: Source/Target/All.Source refers to the resource connected to the source endpoint of the route. Target refers to the resource connected to the target endpoint of the route. All encompasses all route resources.
    :param list[str] attributeRequests:  Attribute Requests - Specify an array of attributes and associated attribute values.
    :rtype: str
    """
    sb=''
    sb+='<SetRouteAttributes>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <sourceResourceFullPath>'+nonnull(sourceResourceFullPath)+'</sourceResourceFullPath>\n'
    sb+='    <targetResourceFullPath>'+nonnull(targetResourceFullPath)+'</targetResourceFullPath>\n'
    sb+='    <applyChangesTo>'+nonnull(applyChangesTo)+'</applyChangesTo>\n'
    sb+='    <attributeRequests>\n'
    if attributeRequests is not None:
      for x in attributeRequests:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </attributeRequests>\n'
    sb+='</SetRouteAttributes>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetRouteAttributes')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetRouteAttributesViaAlias(self , reservationId , routeAlias , applyChangesTo , attributeRequests ) :
    """
    Sets attributes and associated values for a route specified via its alias.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str routeAlias:  Route Alias - Specify the route’s alias.
    :param RouteAttributesChangeTarget applyChangesTo:  Apply Changes To - Specify on which resources to apply the attribute changes: Source/Target/All.Source refers to the resource connected to the source endpoint of the route. Target refers to the resource connected to the target endpoint of the route. All encompasses all route resources.
    :param list[str] attributeRequests:  Attribute Requests - Specify an array of attributes and associated attribute values.
    :rtype: str
    """
    sb=''
    sb+='<SetRouteAttributesViaAlias>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <routeAlias>'+nonnull(routeAlias)+'</routeAlias>\n'
    sb+='    <applyChangesTo>'+nonnull(applyChangesTo)+'</applyChangesTo>\n'
    sb+='    <attributeRequests>\n'
    if attributeRequests is not None:
      for x in attributeRequests:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </attributeRequests>\n'
    sb+='</SetRouteAttributesViaAlias>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetRouteAttributesViaAlias')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetServiceAttributesValues(self , reservationId , serviceAlias , attributeRequests ) :
    """
    Sets attributes and associated values for a specified resource.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str serviceAlias:  Service Alias - Specify the service name.
    :param list[AttributeNameValue] attributeRequests:  Attribute Requests - Specify a matrix of attributes and associated attribute values.
    :rtype: str
    """
    sb=''
    sb+='<SetServiceAttributesValues>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <serviceAlias>'+nonnull(serviceAlias)+'</serviceAlias>\n'
    sb+='    <attributeRequests>\n'
    if attributeRequests is not None:
        for x in attributeRequests:
            sb+='        <AttributeNameValue>\n'
            sb+='            <Name>'+nonnull(x.Name)+'</Name>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </AttributeNameValue>\n'
    sb+='    </attributeRequests>\n'
    sb+='</SetServiceAttributesValues>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetServiceAttributesValues')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetServiceDriver(self , serviceName , driverName = "") :
    """
    Sets the driver for a specified service model, if empty, removes its driver.
    :param str serviceName:  Service Name - Specify the name of the service model.
    :param str driverName:  Driver Name - Specify the name of the driver.
    :rtype: str
    """
    sb=''
    sb+='<SetServiceDriver>\n'
    sb+='    <serviceName>'+nonnull(serviceName)+'</serviceName>\n'
    sb+='    <driverName>'+nonnull(driverName)+'</driverName>\n'
    sb+='</SetServiceDriver>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetServiceDriver')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetServiceLiveStatus(self , reservationId , serviceAlias , liveStatusName = "", additionalInfo = "") :
    """
    Sets the live status of a service
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation's unique identifier.
    :param str serviceAlias:  Service Alias - Specify the string that represents the service's alias.
    :param str liveStatusName:  Live Status Name - Resource live status name
    :param str additionalInfo:  Additional Info - Resource live status additional info
    :rtype: str
    """
    sb=''
    sb+='<SetServiceLiveStatus>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <serviceAlias>'+nonnull(serviceAlias)+'</serviceAlias>\n'
    sb+='    <liveStatusName>'+nonnull(liveStatusName)+'</liveStatusName>\n'
    sb+='    <additionalInfo>'+nonnull(additionalInfo)+'</additionalInfo>\n'
    sb+='</SetServiceLiveStatus>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetServiceLiveStatus')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SetTopologyCategory(self , topologyFullPath , categoryName , categoryValue ) :
    """
    Set a category to given topology
    :param str topologyFullPath:  Topology Full Path - Specify the topology we want to set the given category to
    :param str categoryName:  Category Name - Specify the category's name which we want to set
    :param str categoryValue:  Category Value - Specify the category's value
    :rtype: str
    """
    sb=''
    sb+='<SetTopologyCategory>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='    <categoryName>'+nonnull(categoryName)+'</categoryName>\n'
    sb+='    <categoryValue>'+nonnull(categoryValue)+'</categoryValue>\n'
    sb+='</SetTopologyCategory>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SetTopologyCategory')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SyncResourceFromDevice(self , resourceFullPath ) :
    """
    Synchronizes the specified resource with current device settings and mappings.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<SyncResourceFromDevice>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</SyncResourceFromDevice>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SyncResourceFromDevice')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def SyncResourceToDevice(self , resourceFullPath ) :
    """
    Updates device settings and mappings from the specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<SyncResourceToDevice>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</SyncResourceToDevice>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'SyncResourceToDevice')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def TerminateReservation(self , reservationId ) :
    """
    Terminates the specified reservation if the reservation is in a state of teardown.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :rtype: str
    """
    sb=''
    sb+='<TerminateReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='</TerminateReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'TerminateReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UnMapPorts(self , portA , portB ) :
    """
    Removes existing mapping between a pair of physical (L1) switch ports.
    :param str portA:  Port A - Specify the source port. (i.e. Folder1/Chassis1/Blade1/Port1).
    :param str portB:  Port B - Specify the destination port. (i.e. Folder1/Chassis1/Blade1/Port1).
    :rtype: str
    """
    sb=''
    sb+='<UnMapPorts>\n'
    sb+='    <portA>'+nonnull(portA)+'</portA>\n'
    sb+='    <portB>'+nonnull(portB)+'</portB>\n'
    sb+='</UnMapPorts>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UnMapPorts')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UnarchiveDomain(self , domainName ) :
    """
    Unarchive a domain. New reservation can be created.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :rtype: str
    """
    sb=''
    sb+='<UnarchiveDomain>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='</UnarchiveDomain>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UnarchiveDomain')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UnlockResource(self , reservationId , resourceFullPath ) :
    """
    Unlocks the specified resource.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :rtype: str
    """
    sb=''
    sb+='<UnlockResource>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='</UnlockResource>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UnlockResource')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UnlockResources(self , reservationId , resourcesFullPath ) :
    """
    Unlocks multiple resources.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param list[str] resourcesFullPath:  Resources Full Path - Specify a list of resource names. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/ResourceName
    :rtype: str
    """
    sb=''
    sb+='<UnlockResources>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <resourcesFullPath>\n'
    if resourcesFullPath is not None:
      for x in resourcesFullPath:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </resourcesFullPath>\n'
    sb+='</UnlockResources>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UnlockResources')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateConnectionWeight(self , resourceAFullPath , resourceBFullPath , weight ) :
    """
    Sets a weight score on a physical connection between two resources. Weights are used to optimize route resolution in physical switch scenarios.
    :param str resourceAFullPath:  Resource A Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str resourceBFullPath:  Resource B Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param int weight:  Physical Connection Weight - Specify a number to represent the connection weight between the specified resources.
    :rtype: str
    """
    sb=''
    sb+='<UpdateConnectionWeight>\n'
    sb+='    <resourceAFullPath>'+nonnull(resourceAFullPath)+'</resourceAFullPath>\n'
    sb+='    <resourceBFullPath>'+nonnull(resourceBFullPath)+'</resourceBFullPath>\n'
    sb+='    <weight>'+nonnull(weight)+'</weight>\n'
    sb+='</UpdateConnectionWeight>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateConnectionWeight')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateConnectorAliasInReservation(self , reservationId , sourceResourceFullName , targetResourceFullName , direction , alias ) :
    """
    Sets alias for a specified connector.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str sourceResourceFullName:  Source Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str targetResourceFullName:  Target Resource - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param MappingType direction:  Direction - Specify bidirectional or unidirectional as the connector direction.
    :param str alias:  Connector Alias - Specify the connector’s alias.
    :rtype: str
    """
    sb=''
    sb+='<UpdateConnectorAliasInReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <sourceResourceFullName>'+nonnull(sourceResourceFullName)+'</sourceResourceFullName>\n'
    sb+='    <targetResourceFullName>'+nonnull(targetResourceFullName)+'</targetResourceFullName>\n'
    sb+='    <direction>'+nonnull(direction)+'</direction>\n'
    sb+='    <alias>'+nonnull(alias)+'</alias>\n'
    sb+='</UpdateConnectorAliasInReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateConnectorAliasInReservation')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateDomainTopologiesFolder(self , domainName , topologiesFolder ) :
    """
    Update the domain’s topologies folder.
    :param str domainName:  Domain Name - Specify the name of the domain.
    :param str topologiesFolder:  Topology Full Path - Specify the topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :rtype: str
    """
    sb=''
    sb+='<UpdateDomainTopologiesFolder>\n'
    sb+='    <domainName>'+nonnull(domainName)+'</domainName>\n'
    sb+='    <topologiesFolder>'+nonnull(topologiesFolder)+'</topologiesFolder>\n'
    sb+='</UpdateDomainTopologiesFolder>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateDomainTopologiesFolder')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateGroup(self , groupName , newName , description = "", groupRole = "") :
    """
    Modifies the group name and description.
    :param str groupName:  Group Name - Specify the name of the group.
    :param str newName:  New Group Name - Specify the new group name.
    :param str description:  Description - Provide a short description of the group.
    :param UpdateRoleOptions groupRole:  Group Role - Specify the role of the group, possible values: External, Regular, DomainAdmin or Ignore (to keep the current role).
    :rtype: str
    """
    sb=''
    sb+='<UpdateGroup>\n'
    sb+='    <groupName>'+nonnull(groupName)+'</groupName>\n'
    sb+='    <newName>'+nonnull(newName)+'</newName>\n'
    sb+='    <description>'+nonnull(description)+'</description>\n'
    sb+='    <groupRole>'+nonnull(groupRole)+'</groupRole>\n'
    sb+='</UpdateGroup>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateGroup')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdatePhysicalConnection(self , resourceAFullPath , resourceBFullPath = "", overrideExistingConnections = True) :
    """
    Define a physical connection (cable link) between two resources.
    :param str resourceAFullPath:  Resource A Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str resourceBFullPath:  Resource B Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1. You may leave this parameter blank if you wish to disconnect the existing source resource connection.
    :param bool overrideExistingConnections:  Override existing - Overriding existing connections will automatically remove existing physical connection if they conflict with the requested new connections. If set to 'No', an error message will be displayed if any port is already connected and the operation will be cancelled.
    :rtype: str
    """
    sb=''
    sb+='<UpdatePhysicalConnection>\n'
    sb+='    <resourceAFullPath>'+nonnull(resourceAFullPath)+'</resourceAFullPath>\n'
    sb+='    <resourceBFullPath>'+nonnull(resourceBFullPath)+'</resourceBFullPath>\n'
    if overrideExistingConnections is None:
      overrideExistingConnections=True
    sb+='    <overrideExistingConnections>'+nonnull(overrideExistingConnections)+'</overrideExistingConnections>\n'
    sb+='</UpdatePhysicalConnection>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdatePhysicalConnection')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdatePhysicalConnections(self , physicalConnectionUpdateRequest , overrideExistingConnections = True) :
    """
    Define physical connections (cable links) between resources.
    :param list[PhysicalConnectionUpdateRequest] physicalConnectionUpdateRequest:  Physical Connections - Specify a matrix of physical connections to update. For example: {['ResourceA','ResourceB';'ResourceC',ResourceD']}
    :param bool overrideExistingConnections:  Override existing - Overriding existing connections will automatically remove existing physical connection if they conflict with the requested new connections. If set to 'No', an error message will be displayed if any port is already connected and the operation will be cancelled.
    :rtype: str
    """
    sb=''
    sb+='<UpdatePhysicalConnections>\n'
    sb+='    <physicalConnectionUpdateRequest>\n'
    if physicalConnectionUpdateRequest is not None:
        for x in physicalConnectionUpdateRequest:
            sb+='        <PhysicalConnectionUpdateRequest>\n'
            sb+='            <ResourceAFullName>'+nonnull(x.ResourceAFullName)+'</ResourceAFullName>\n'
            sb+='            <ResourceBFullName>'+nonnull(x.ResourceBFullName)+'</ResourceBFullName>\n'
            sb+='            <ConnectionWeight>'+nonnull(x.ConnectionWeight)+'</ConnectionWeight>\n'
            sb+='        </PhysicalConnectionUpdateRequest>\n'
    sb+='    </physicalConnectionUpdateRequest>\n'
    if overrideExistingConnections is None:
      overrideExistingConnections=True
    sb+='    <overrideExistingConnections>'+nonnull(overrideExistingConnections)+'</overrideExistingConnections>\n'
    sb+='</UpdatePhysicalConnections>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdatePhysicalConnections')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateReservationDescription(self , reservationId , description ) :
    """
    Modifies the description for a specified reservation.
    :param str reservationId:  Reservation ID - Specify the reservation ID.
    :param str description:  Description - Provide an updated description of the reservation. This text will replace the current description.
    :rtype: str
    """
    sb=''
    sb+='<UpdateReservationDescription>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <description>'+nonnull(description)+'</description>\n'
    sb+='</UpdateReservationDescription>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateReservationDescription')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateReservationGlobalInputs(self , reservationId , globalInputs ) :
    """
    Updates the unlinked global inputs in a specified reservation.
    :param str reservationId:  Reservation ID - Specify the reservation ID.
    :param list[UpdateTopologyGlobalInputsRequest] globalInputs:  Global Inputs - Global inputs associated with the specified reservation.
    :rtype: str
    """
    sb=''
    sb+='<UpdateReservationGlobalInputs>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <globalInputs>\n'
    if globalInputs is not None:
        for x in globalInputs:
            sb+='        <UpdateTopologyGlobalInputsRequest>\n'
            sb+='            <ParamName>'+nonnull(x.ParamName)+'</ParamName>\n'
            sb+='            <Value>'+nonnull(x.Value)+'</Value>\n'
            sb+='        </UpdateTopologyGlobalInputsRequest>\n'
    sb+='    </globalInputs>\n'
    sb+='</UpdateReservationGlobalInputs>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateReservationGlobalInputs')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateResourceAddress(self , resourceFullPath , resourceAddress ) :
    """
    Modifies the address for a specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str resourceAddress:  Resource Address - Specify the resource’s new address.
    :rtype: str
    """
    sb=''
    sb+='<UpdateResourceAddress>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <resourceAddress>'+nonnull(resourceAddress)+'</resourceAddress>\n'
    sb+='</UpdateResourceAddress>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateResourceAddress')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateResourceDescription(self , resourceFullPath , resourceDescription ) :
    """
    Modifies the description for a specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str resourceDescription:  Resource description - Provide an updated description of the resource. This text will replace the current description.
    :rtype: str
    """
    sb=''
    sb+='<UpdateResourceDescription>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <resourceDescription>'+nonnull(resourceDescription)+'</resourceDescription>\n'
    sb+='</UpdateResourceDescription>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateResourceDescription')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateResourceDriver(self , resourceFullPath , driverName ) :
    """
    Updates the driver for a specified resource.
    :param str resourceFullPath:  Resource Full Path - Specify the resource name. You can also include the full path from the root to the resource before the resource name, separated by slashes. For example: FolderName/RouterA/Port1.
    :param str driverName:  Driver Name - Specify the name of the driver.
    :rtype: str
    """
    sb=''
    sb+='<UpdateResourceDriver>\n'
    sb+='    <resourceFullPath>'+nonnull(resourceFullPath)+'</resourceFullPath>\n'
    sb+='    <driverName>'+nonnull(driverName)+'</driverName>\n'
    sb+='</UpdateResourceDriver>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateResourceDriver')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateRouteAliasesInReservation(self , reservationId , routeAliases ) :
    """
    Update route aliases in a reservation.
    :param str reservationId:  Reservation ID - Specifies the string that represents the reservation’s unique identifier.
    :param list[UpdateRouteAliasRequest] routeAliases:  Source Target Alias - Specify a matrix of route source, route target and alias. For example: {['SourceResourceFullName', 'TargetFullName','Alias';'SourceResourceFullName2', 'TargetFullName2','Alias2']}.
    :rtype: EndPointConnectionInfo
    """
    sb=''
    sb+='<UpdateRouteAliasesInReservation>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <routeAliases>\n'
    if routeAliases is not None:
        for x in routeAliases:
            sb+='        <UpdateRouteAliasRequest>\n'
            sb+='            <SourceResourceName>'+nonnull(x.SourceResourceName)+'</SourceResourceName>\n'
            sb+='            <TargetResourceName>'+nonnull(x.TargetResourceName)+'</TargetResourceName>\n'
            sb+='            <Alias>'+nonnull(x.Alias)+'</Alias>\n'
            sb+='        </UpdateRouteAliasRequest>\n'
    sb+='    </routeAliases>\n'
    sb+='</UpdateRouteAliasesInReservation>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateRouteAliasesInReservation')
    xmlres = str.replace(xmlres, 'xmlns="http://schemas.qualisystems.com/ResourceManagement/ApiCommandResult.xsd"', ' ').replace('&#x0;', '<NUL>')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xo.ResponseInfo

  def UpdateTopologyDriver(self , topologyFullPath , driverName ) :
    """
    Update the topology driver.
    :param str topologyFullPath:  Topology Full Path - Specify the topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :param str driverName:  Driver Name - Specify the name of the driver. Leave empty to remove associated driver.
    :rtype: str
    """
    sb=''
    sb+='<UpdateTopologyDriver>\n'
    sb+='    <topologyFullPath>'+nonnull(topologyFullPath)+'</topologyFullPath>\n'
    sb+='    <driverName>'+nonnull(driverName)+'</driverName>\n'
    sb+='</UpdateTopologyDriver>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateTopologyDriver')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateTopologyOwner(self , topologyName , ownerName ) :
    """
    Update the topology owner.
    :param str topologyName:  Topology Full Path - Specify the topology name. Include the full path from the root to the topology, separated by slashes. For example: FolderName/Topologies/TopologyName.
    :param str ownerName:  Topology Owner - Specify the topology owner.
    :rtype: str
    """
    sb=''
    sb+='<UpdateTopologyOwner>\n'
    sb+='    <topologyName>'+nonnull(topologyName)+'</topologyName>\n'
    sb+='    <ownerName>'+nonnull(ownerName)+'</ownerName>\n'
    sb+='</UpdateTopologyOwner>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateTopologyOwner')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateUser(self , username , isActive , email = "") :
    """
    Configures a user's email and activity settings.
    :param str username:  Username - The username of the user you want to update.
    :param bool isActive:  Is Active - Grant or deny active access to the application.
    :param str email:  Email - The new email address to update to.
    :rtype: str
    """
    sb=''
    sb+='<UpdateUser>\n'
    sb+='    <username>'+nonnull(username)+'</username>\n'
    sb+='    <email>'+nonnull(email)+'</email>\n'
    sb+='    <isActive>'+nonnull(isActive)+'</isActive>\n'
    sb+='</UpdateUser>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateUser')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateUserGroups(self , username , groupsNames ) :
    """
    Update an existing user's groups (replaces existing user's groups).
    :param str username:  Username - Specify the name of the user.
    :param list[str] groupsNames:  Groups Names - Use this method to update a user's group memberships. Activating this method will replace the user's memberships with the specified list of groups.
    :rtype: str
    """
    sb=''
    sb+='<UpdateUserGroups>\n'
    sb+='    <username>'+nonnull(username)+'</username>\n'
    sb+='    <groupsNames>\n'
    if groupsNames is not None:
      for x in groupsNames:
          sb+='        <string>'+nonnull(x)+'</string>\n'
    sb+='    </groupsNames>\n'
    sb+='</UpdateUserGroups>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateUserGroups')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateUserPassword(self , username , password ) :
    """
    Changes a user's password.
    :param str username:  Username - Specify the name of the user.
    :param str password:  Password - Specify the user's new login password.
    :rtype: str
    """
    sb=''
    sb+='<UpdateUserPassword>\n'
    sb+='    <username>'+nonnull(username)+'</username>\n'
    sb+='    <password>'+nonnull(password)+'</password>\n'
    sb+='</UpdateUserPassword>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateUserPassword')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def UpdateUsersLimitations(self , userUpdateRequests ) :
    """
    Update MaxConcurrentReservations and MaxReservationDuration.
    :param list[UserUpdateRequest] userUpdateRequests:  UserUpdateRequests - List of Username, MaxConcurrentReservations and MaxReservationDuration of the users you wish to update.  For example: {['Username1','1','1';'Username2','12','10']}
    :rtype: str
    """
    sb=''
    sb+='<UpdateUsersLimitations>\n'
    sb+='    <userUpdateRequests>\n'
    if userUpdateRequests is not None:
        for x in userUpdateRequests:
            sb+='        <UserUpdateRequest>\n'
            sb+='            <Username>'+nonnull(x.Username)+'</Username>\n'
            sb+='            <MaxConcurrentReservations>'+nonnull(x.MaxConcurrentReservations)+'</MaxConcurrentReservations>\n'
            sb+='            <MaxReservationDuration>'+nonnull(x.MaxReservationDuration)+'</MaxReservationDuration>\n'
            sb+='        </UserUpdateRequest>\n'
    sb+='    </userUpdateRequests>\n'
    sb+='</UpdateUsersLimitations>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'UpdateUsersLimitations')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

  def WriteMessageToReservationOutput(self , reservationId , message ) :
    """
    Allows sending output to the command output window in a reservation.
    :param str reservationId:  Reservation ID - Specify the string that represents the reservation’s unique identifier.
    :param str message:  Output message - Output message to the command output window.
    :rtype: str
    """
    sb=''
    sb+='<WriteMessageToReservationOutput>\n'
    sb+='    <reservationId>'+nonnull(reservationId)+'</reservationId>\n'
    sb+='    <message>'+nonnull(message)+'</message>\n'
    sb+='</WriteMessageToReservationOutput>\n'
    debug('IN:'+sb)
    xmlres=self.__send_request(sb, self.user, self.domain, 'WriteMessageToReservationOutput')
    debug('OUT:'+str(xmlres))
    node=ET.fromstring(xmlres)
    xo=ApiCommandResult(node)
    if not xo.Success:
        raise CloudShellAPIError(xo.ErrorCode, xo.Error, xmlres)
    return xmlres

