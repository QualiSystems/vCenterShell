class DriverResponse(object):
    def __init__(self):
        self.actionResults = []


class DriverResponseRoot(object):
    def __init__(self):
        self.driverResponse = None