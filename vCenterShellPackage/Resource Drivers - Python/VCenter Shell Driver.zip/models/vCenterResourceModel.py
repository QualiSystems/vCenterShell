class vCenterResourceModel(object):
    def __init__(self):
        self.user = ''
        self.password = ''
        self.default_dvswitch_name = ''
        self.default_dvswitch_path = ''
        self.default_port_group_path = ''
        self.default_network = ''
