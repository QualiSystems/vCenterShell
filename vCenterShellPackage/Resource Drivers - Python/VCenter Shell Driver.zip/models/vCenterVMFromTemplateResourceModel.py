class vCenterVMFromTemplateResourceModel(object):
    def __init__(self):
        self.cloud_provider = ''
        self.location = ''
        self.template = ''
        self.domain_selector = ''
        self.vcenter_template = ''
        self.access_mode = ''
        self.vm_cluster = ''
        self.vm_power_state = ''
        self.vm_storage = ''
