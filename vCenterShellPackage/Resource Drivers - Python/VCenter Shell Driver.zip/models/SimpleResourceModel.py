class SimpleResourceModel(object):
    pass