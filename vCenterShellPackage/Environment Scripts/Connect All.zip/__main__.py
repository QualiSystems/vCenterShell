from environment_scripts.connect_all import EnvironmentConnector


def main():
    environment_connector = EnvironmentConnector()
    environment_connector.connect_all()


if __name__ == "__main__":
    main()
