﻿class VMClusterModel(object):

    def __init__(self, cluster_name, resource_pool):
        self.cluster_name = resource_pool
        self.resource_pool = resource_pool


